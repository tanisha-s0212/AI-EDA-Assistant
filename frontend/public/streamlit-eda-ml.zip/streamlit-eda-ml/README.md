# AI-Assisted EDA & ML Platform

A production-grade, dataset-agnostic Streamlit application for automated Exploratory Data Analysis, data cleaning, ML model training, and predictions. Upload any tabular dataset and go from raw data to a deployed model without writing code.

---

## Features

### Universal Data Ingestion
- **CSV** with automatic encoding detection (UTF-8, Latin-1, CP1252, ISO-8859-1) and delimiter sniffing (comma, semicolon, tab, pipe)
- **Excel** (`.xlsx` / `.xls`) with multi-sheet support and automatic sheet detection
- **Parquet** for high-performance columnar data
- **ZIP archives** containing any combination of the above, with automatic extraction and per-file loading
- Automatic column name standardisation (whitespace, special characters, casing) and empty column removal
- File hash-based change detection to avoid reloading the same file on Streamlit re-renders

### Smart Data Cleaning
- Configurable pipeline with seven independent cleaning steps, all togglable by the user
- Duplicate row removal
- Summary row elimination (detects "Grand Total", "Subtotal", "Net Total", etc.)
- Date column parsing with 20+ format patterns and success-rate validation
- Numeric imputation (median) and categorical imputation (mode)
- Low-cardinality object-to-category conversion for memory efficiency
- Numeric downcasting to smallest compatible dtype (int8/16/32, float32)
- Full cleaning log and before/after summary (row counts, memory savings)

### Exploratory Data Analysis
- Numeric feature statistics table (count, mean, std, quartiles, skewness, kurtosis)
- Histogram + KDE distribution plots for numeric columns
- Box plots for outlier detection
- Categorical feature distribution bar charts
- Pearson correlation heatmap and matrix table
- Deterministic narrative generation summarising distributions, correlations, missing data, and data quality concerns
- Optional AI-enhanced EDA narrative via LongCat or Groq

### AI-Assisted ML
- Natural-language objective input (e.g., "Predict house prices based on features")
- AI-recommended strategy: target column selection, problem type detection, feature recommendations and exclusions, reasoning
- Automatic problem type detection (regression vs classification) based on target cardinality
- Three-model comparison suite:
  - **Regression:** Ridge, RandomForest, HistGradientBoosting
  - **Classification:** LogisticRegression, RandomForest, HistGradientBoosting
- Data leakage detection (identifier columns, suffix-based heuristics, target substring matching)
- Walk-forward backtesting with expanding-window support for time-series data
- Feature importance extraction from tree-based and linear models
- Data leakage warnings (R-squared > 0.99 or accuracy > 0.99)

### Predictions
- Auto-generated input form from model metadata (numeric sliders, categorical selectors)
- Single-row predictions with confidence scores (classification)
- Batch predictions on uploaded CSV files
- AI-powered prediction explanations identifying key feature contributions
- Downloadable model packages (`.pkl`) containing model, preprocessor, metadata, and feature importances

---

## Tech Stack

| Component | Technology |
|---|---|
| Frontend | Streamlit 1.40+ |
| Data Processing | pandas 2.1+, Polars 0.20+, NumPy |
| ML | scikit-learn 1.4+ (Ridge, RandomForest, HistGradientBoosting, LogisticRegression) |
| Visualisation | Matplotlib, Seaborn |
| AI Providers | LongCat API, Groq API (llama-3.3-70b-versatile) |
| HTTP Client | httpx |
| Persistence | joblib (model serialisation) |
| Configuration | python-dotenv |
| Containerisation | Docker (Python 3.12-slim), Docker Compose |

---

## Quick Start

### Prerequisites
- Python 3.11 or 3.12
- pip

### Local Setup

```bash
# 1. Clone the repository
git clone <repository-url>
cd streamlit-eda-ml

# 2. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate        # Linux / macOS
# venv\Scripts\activate         # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment variables (optional but recommended for AI features)
cp .env.example .env
# Edit .env with your API keys

# 5. Run the application
streamlit run app.py
```

The application will open at **http://localhost:8501**.

### Docker

```bash
# Build and run with Docker Compose
docker compose up --build

# Or build and run manually
docker build -t eda-ml-platform .
docker run -p 8501:8501 --env-file .env -v ./models:/app/models eda-ml-platform
```

The application will be available at **http://localhost:8501**.

---

## Environment Variables

All configuration is done via a `.env` file in the project root.

| Variable | Required | Default | Description |
|---|---|---|---|
| `GROQ_API_KEY` | No | — | Groq API key for AI-powered analysis |
| `LONGCAT_API_KEY` | No | — | LongCat API key (preferred when set) |
| `LONGCAT_MODEL` | No | `LongCat-Flash-Chat` | LongCat model identifier |

At least one AI provider key (`GROQ_API_KEY` or `LONGCAT_API_KEY`) should be configured to enable AI-assisted features. The platform works fully without AI keys — all deterministic features (profiling, cleaning, EDA visualisations, ML training, predictions) operate independently. AI features gracefully degrade when no provider is available.

---

## Project Structure

```
streamlit-eda-ml/
├── app.py                        # Main Streamlit application (UI, tabs, sidebar)
├── requirements.txt              # Python dependencies
├── Dockerfile                    # Container build configuration
├── docker-compose.yml            # Docker Compose service definition
├── models/                       # Saved model packages
│   └── test_roundtrip.pkl
├── documentation/
│   ├── architecture.md           # System architecture documentation
│   ├── setup_guide.md            # Detailed setup instructions
│   └── walkthrough.md            # Step-by-step sample walkthrough
└── modules/
    ├── __init__.py               # Package initialiser
    ├── session_manager.py        # Centralised session state management
    ├── file_loader.py            # Universal file ingestion (CSV, Excel, Parquet, ZIP)
    ├── data_understanding.py     # Dataset profiling and column role detection
    ├── data_cleanser.py          # Heuristic-driven cleaning pipeline
    ├── eda_engine.py             # EDA visualisations and statistical analysis
    ├── ai_assistant.py           # Multi-provider AI integration with fallback
    ├── ml_engine.py              # ML pipeline (feature prep, training, evaluation)
    ├── prediction_engine.py      # Prediction from saved model packages
    └── utils.py                  # Shared utilities (logging, hashing, date detection)
```

---

## Supported File Formats

| Format | Extension(s) | Notes |
|---|---|---|
| CSV | `.csv` | Auto-detects encoding and delimiter |
| Excel | `.xlsx`, `.xls` | All sheets loaded; multi-sheet handled via dataset switcher |
| Parquet | `.parquet` | Native pandas reader |
| ZIP | `.zip` | Extracts and loads all contained CSV/Excel/Parquet files |

---

## Key Design Principles

### Dataset-Agnostic
Every module operates on arbitrary tabular data without domain-specific assumptions. Column roles (identifier, numeric, categorical, boolean, datetime) are inferred from heuristics, not hard-coded mappings. Cleaning rules, ML strategies, and AI prompts are designed to reason from structure, not from pre-knowledge of the dataset.

### Deterministic-over-AI
All core functionality — profiling, cleaning, EDA statistics, model training, predictions — works without any AI provider. AI is an enhancement layer that provides natural-language explanations and strategy recommendations. When AI is unavailable, the platform falls back to its deterministic capabilities with clear status indicators in the sidebar.

### Graceful Degradation
- AI provider failures are caught, logged, and the next provider in the priority chain is tried automatically
- Failed providers are tracked per session to avoid repeated timeouts
- CSV loading tries multiple encoding/delimiter combinations before giving up
- Date parsing validates success rates and reverts columns that fail
- Model evaluation includes data leakage warnings for suspiciously high metrics
- Missing features in batch predictions are filled with safe defaults rather than raising errors
