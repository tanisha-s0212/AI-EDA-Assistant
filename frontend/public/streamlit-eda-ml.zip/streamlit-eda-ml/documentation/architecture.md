# Architecture

## System Overview

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         Streamlit Frontend (app.py)                      │
│                                                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐  │
│  │  Data     │ │ Cleaning │ │   EDA    │ │   ML     │ │  Prediction  │  │
│  │ Understand│ │  & Prep  │ │          │ │Assistant │ │              │  │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ └──────┬───────┘  │
│       │             │            │             │               │          │
│  ┌────┴─────────────┴────────────┴─────────────┴───────────────┴──────┐  │
│  │                   Session State (session_manager)                   │  │
│  │  raw_dataset | cleaned_dataset | ai_strategy | ml_results | ...    │  │
│  └────┬─────────────┬────────────┬─────────────┬──────────────┬───────┘  │
│       │             │            │             │               │          │
└───────┼─────────────┼────────────┼─────────────┼───────────────┼──────────┘
        │             │            │             │               │
┌───────▼─────┐ ┌─────▼──────┐ ┌──▼──────────┐ ┌▼───────────┐ ┌▼─────────┐
│ FileLoader  │ │DataCleanser│ │ EDAEngine   │ │ MLPipeline  │ │Predictn │
│             │ │            │ │             │ │             │ │  Engine  │
│ CSV Excel   │ │ Duplicates │ │ Distributions│ │ FeaturePrep │ │ Form    │
│ Parquet ZIP │ │ Imputation │ │ BoxPlots    │ │ TrainModels │ │ Single  │
│ Encodings   │ │ Dates      │ │ Correlation │ │ Evaluate    │ │ Batch   │
│ Delimiters  │ │ Downcast   │ │ Narrative   │ │ Backtest    │ │ Explain │
└─────────────┘ └────────────┘ └──────┬──────┘ └──────┬──────┘ └────┬────┘
                                              │             │            │
                                        ┌─────▼─────────────▼────────────▼────┐
                                        │           AIAssistant              │
                                        │   LongCat (primary, if configured) │
                                        │   Groq    (fallback)               │
                                        └───────────────────────────────────┘
                                                    │
                                              ┌─────▼─────┐
                                              │  utils.py  │
                                              │  Logging   │
                                              │  Hashing   │
                                              │  Roles     │
                                              │  Leakage   │
                                              │  Dates     │
                                              └───────────┘
```

---

## Module Responsibilities and Dependencies

### `app.py` — Application Entry Point
The main Streamlit script. Owns all UI rendering (sidebar, tabs, welcome screen), file upload handling, and orchestration of module calls. Reads and writes session state through `session_manager`. Contains custom CSS for the UI theme.

### `modules/session_manager.py` — Session State
Centralised interface for all `st.session_state` access. Defines every state key as a module-level constant. Provides `init_session_state()`, `reset_dataset_state()`, `reset_ml_state()`, `get_state()`, `set_state()`, and `has_state()`. Grouped key lists (`_DATASET_BOUND_KEYS`, `_ML_BOUND_KEYS`) control which state is cleared on dataset switches vs ML resets.

### `modules/file_loader.py` — File Ingestion
Handles loading of CSV, Excel, Parquet, and ZIP files into pandas DataFrames. CSV loading uses multi-encoding and multi-delimiter fallback chains with `csv.Sniffer` as a last resort. ZIP archives are recursively extracted. Also provides `prepare_dataset()` for column standardisation and empty column removal.

### `modules/data_understanding.py` — Data Profiling
The `DataProfiler` class computes shape, memory usage, duplicate counts, missing value summaries, dtype summaries, column role classification, date column detection, and identifier column detection. Generates human-readable profile summaries for downstream AI prompts.

### `modules/data_cleanser.py` — Data Cleaning Pipeline
The `DataCleanser` class implements a seven-step configurable pipeline:
1. Remove duplicate rows
2. Remove summary/aggregation rows (keyword matching)
3. Parse date columns
4. Impute missing numeric values (median, or "UNKNOWN" for identifier columns)
5. Impute missing categorical values (mode, or "missing" fallback)
6. Convert low-cardinality objects to category dtype
7. Downcast numeric dtypes

Each step is independently toggleable. Produces a detailed log and summary dictionary.

### `modules/eda_engine.py` — EDA Visualisations
The `EDAEngine` class generates distribution histograms, box plots, categorical bar charts, and correlation heatmaps. All plots are rendered to in-memory PNG buffers and returned as base64 strings for embedding in Streamlit HTML. Also provides `generate_eda_narrative()` for a deterministic text summary of EDA findings.

### `modules/ai_assistant.py` — AI Provider Integration
The `AIAssistant` class manages communication with LongCat and Groq APIs using the OpenAI-compatible chat completions format. Implements automatic provider fallback with per-session failure tracking. Provides high-level methods for data summarisation, cleaning recommendations, ML strategy suggestions, and prediction explanations. JSON extraction from AI responses handles fenced code blocks, bare JSON, and embedded JSON.

### `modules/ml_engine.py` — ML Pipeline
The `MLPipeline` class implements the full machine-learning workflow:
- **Feature preparation:** Column classification, identifier/leakage filtering, boolean-to-int conversion, date-to-ordinal conversion, ColumnTransformer with imputation + scaling + one-hot encoding
- **Data splitting:** Random split with optional stratification, or chronological time-based split
- **Model training:** Ridge/RandomForest/HistGradientBoosting (regression) or LogisticRegression/RandomForest/HistGradientBoosting (classification)
- **Evaluation:** R-squared/RMSE/MAE (regression) or Accuracy/F1 (classification), with data leakage warnings
- **Feature importance:** Extraction from `feature_importances_` (tree-based) or `coef_` (linear)
- **Backtesting:** Walk-forward expanding-window backtesting for time-series, or random holdout otherwise
- **Model persistence:** Save/load via joblib with full metadata package

### `modules/prediction_engine.py` — Prediction
The `PredictionEngine` class wraps a saved model package and provides:
- Dynamic input form schema generation from feature metadata
- Single-row prediction with type coercion and preprocessor application
- Batch prediction on DataFrames
- Confidence scores for classification models (via `predict_proba`)
- Model info summary

### `modules/utils.py` — Shared Utilities
Provides functions used across multiple modules:
- `setup_logging()` — Centralised logger configuration
- `compute_file_hash()` — SHA-256 file hashing for change detection
- `safe_standardize_columns()` — Column name normalisation with duplicate resolution
- `drop_empty_columns()` — Removal of all-NaN columns
- `detect_date_columns()` — Date column detection via regex and format parsing
- `detect_column_roles()` — Semantic column classification (identifier/numeric/categorical/boolean/datetime)
- `is_identifier_column()` — Identifier detection via cardinality and name heuristics
- `is_leakage_risk()` — Data leakage detection via substring matching and suffix heuristics
- `format_bytes()` — Human-readable byte formatting

---

## Data Flow: Upload to Prediction

```
  User uploads file
        │
        ▼
  ┌─────────────┐
  │ FileLoader  │  Compute file hash → compare with session state
  │             │  Route by extension: CSV / Excel / Parquet / ZIP
  └──────┬──────┘
         │
         ▼
  ┌─────────────┐
  │ prepare_    │  Standardise column names, drop empty columns
  │ dataset()   │  Store original columns list for tracking
  └──────┬──────┘
         │
         ▼
  Session State: raw_dataset, original_columns, file_hash
         │
         ▼
  ┌─────────────────┐
  │ DataProfiler     │  Compute shape, memory, duplicates, missing, dtypes,
  │ (Understanding)  │  column roles, date columns, identifier columns
  └──────┬──────────┘
         │
         ▼
  ┌─────────────────┐
  │ DataCleanser     │  Apply configurable pipeline steps
  │ (Cleaning)       │  Produce logs and summary
  └──────┬──────────┘
         │
         ▼
  Session State: cleaned_dataset, cleaning_logs, cleaning_summary
         │
         ▼
  ┌─────────────────┐
  │ EDAEngine        │  Statistics table, distributions, box plots,
  │ (EDA)            │  categorical charts, correlation heatmap
  └──────┬──────────┘
         │
         ▼
  ┌─────────────────┐
  │ MLPipeline       │  prepare_features → split_data → train_models
  │ (ML Assistant)   │  → evaluate_models → feature_importance
  │                  │  Optionally: backtest
  └──────┬──────────┘
         │
         ▼
  Session State: ml_results (models, metrics, feature importance)
         │
         ▼
  ┌─────────────────┐
  │ save_model_     │  Persist model + preprocessor + metadata to .pkl
  │ package()       │
  └──────┬──────────┘
         │
         ▼
  ┌─────────────────┐
  │ PredictionEngine │  Generate form schema → collect inputs → predict
  │ (Prediction)     │  Optionally: AI explanation
  └─────────────────┘
```

---

## Session State Management Design

### Key Groups

The session state is partitioned into three logical groups:

1. **Dataset-bound keys** — Reset when a new file is uploaded or the active dataset changes:
   - `raw_dataset`, `cleaned_dataset`, `cleaning_logs`, `cleaning_summary`
   - `ai_feature_strategy`, `selected_features`
   - `active_dataset_key`, `file_hash`, `original_columns`, `engineered_columns`

2. **ML-bound keys** — Reset when the user wants to restart the ML workflow (also reset on dataset change):
   - `ml_plan`, `ml_results`, `uploaded_model_package`, `prediction_history`

3. **Persistent keys** — Survive across dataset and ML resets:
   - `processing_log` — Cumulative log of all operations
   - `ai_assistant` — Singleton `AIAssistant` instance with provider state
   - `ai_failed_providers` — Tracks failed AI providers to avoid repeated calls

### State Lifecycle

```
  App Start
     │
     ▼
  init_session_state()  ←  Sets safe defaults for all keys (idempotent)
     │
     ▼
  File Upload
     │
     ├── Same file hash? → Skip (no-op)
     │
     └── New file? → reset_dataset_state(exclude=[processing_log, ai_assistant])
                       → Load file → prepare_dataset → Store in state
     │
     ▼
  Cleaning Run
     │
     └── Store cleaned_dataset, logs, summary
        → reset_ml_state()  ←  Invalidate any previous ML results
     │
     ▼
  ML Training
     │
     └── Store ml_results, model_package_path
     │
     ▼
  Prediction
     │
     └── Append to prediction_history
```

---

## AI Provider Fallback Strategy

```
  AI Request
     │
     ▼
  Check provider_priority list
     │
     ├── LongCat configured? → priority = [longcat, groq]
     └── Not configured     → priority = [groq, longcat]
     │
     ▼
  For each provider in priority:
     │
     ├── Is provider in _failed_providers? → Skip, try next
     │
     ├── Does provider have an API key?    → Skip, try next
     │
     ├── Call provider API (30s timeout)
     │     │
     │     ├── HTTP 200 + valid response → Return (response, provider_name)
     │     │
     │     └── Error or [Error] prefix   → Add to _failed_providers, try next
     │
     └── All providers exhausted → Return error message
```

Provider failure is tracked for the lifetime of the `AIAssistant` instance (which is stored in session state). A provider that fails once will not be retried in the same session, preventing repeated timeouts from degrading the user experience.

### AI Features That Degrade Gracefully

| Feature | Without AI | With AI |
|---|---|---|
| Data Understanding | Full profiling, role detection, missing summary | AI-generated dataset explanation |
| Cleaning | Full 7-step pipeline with deterministic rules | AI cleaning recommendations |
| EDA | Statistics, plots, narrative, heatmap | AI-enhanced narrative |
| ML Strategy | Manual target/feature selection | AI-recommended target, features, and reasoning |
| Predictions | Numeric/class predictions, confidence | AI-powered explanation of predictions |

---

## ML Pipeline Architecture

### Feature Preparation
```
  Selected Features
       │
       ├── Filter: remove exclusions, identifiers, leakage risks
       │
       ├── Classify: numeric / categorical / boolean / date
       │
       ├── Transform:
       │     Boolean  → int (0/1)
       │     Date     → ordinal numeric (Unix timestamp)
       │
       └── ColumnTransformer:
            ├── Numeric:  SimpleImputer(median) → StandardScaler
            └── Category: SimpleImputer(__missing__) → OneHotEncoder
```

### Model Training Suite

| Problem Type | Models |
|---|---|
| Regression | Ridge, RandomForest (100 trees), HistGradientBoosting |
| Classification | LogisticRegression (max_iter=1000), RandomForest (100 trees), HistGradientBoosting |

All models use `random_state=42` for reproducibility.

### Evaluation Metrics

| Problem Type | Primary Metric | Secondary Metrics |
|---|---|---|
| Regression | R-squared (higher is better) | RMSE, MAE |
| Classification | Accuracy (higher is better) | Weighted F1 |

### Data Leakage Detection
The pipeline automatically flags potential data leakage:
- Identifier columns are excluded from feature sets
- Columns with leakage-risk suffixes (`_calc`, `_pred`, `_score`, `_prob`, `_estimated`) are excluded when they reference the target
- Columns containing the target name as a substring are excluded
- Warnings are issued when R-squared > 0.99 (regression) or accuracy > 0.99 (classification)

---

## Model Package Format

Model packages are serialised with `joblib.dump()` (compression level 3) and contain a Python dictionary with the following keys:

```python
{
    "model": <fitted sklearn model>,
    "preprocessor": <fitted ColumnTransformer>,
    "feature_list": [str],           # Ordered feature names
    "target": str,                   # Target column name
    "problem_type": str,             # "regression" or "classification"
    "numeric_features": [str],       # Numeric feature names
    "categorical_features": [str],   # Categorical feature names
    "date_columns": [str],           # Date feature names
    "metrics": dict,                 # Evaluation metrics for best model
    "feature_importance": DataFrame, # Top-N feature importance table
}
```

This self-contained package includes everything needed to make predictions on new data: the model, the fitted preprocessor (with encoder categories and scaler parameters), and metadata describing the expected input schema. No original training data is stored in the package.
