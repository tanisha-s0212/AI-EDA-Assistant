# Setup Guide

## Prerequisites

| Requirement | Minimum Version | Recommended |
|---|---|---|
| Python | 3.11 | 3.12 |
| pip | Latest | Latest |
| Docker (optional) | 20.10+ | Latest |
| Docker Compose (optional) | 2.0+ | Latest |

### Python Version Notes
- Python 3.12 is used in the official Docker image and is the recommended version for local development.
- Python 3.11 is supported. Type hint syntax (`str | None`, `list[str]`) requires 3.10+.
- Python 3.13 is not yet tested and may have compatibility issues with some scikit-learn versions.

---

## Local Setup

### 1. Clone the Repository

```bash
git clone <repository-url>
cd streamlit-eda-ml
```

### 2. Create a Virtual Environment

```bash
# Create
python -m venv venv

# Activate (Linux / macOS)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

This installs all required packages including Streamlit, pandas, scikit-learn, matplotlib, seaborn, httpx, and python-dotenv.

### 4. Configure Environment Variables

Create a `.env` file in the project root:

```bash
touch .env
```

Add your API keys (at least one for AI features):

```env
# Groq API (https://console.groq.com)
GROQ_API_KEY=gsk_your_key_here

# LongCat API (alternative / preferred provider)
# LONGCAT_API_KEY=your_key_here
# LONGCAT_MODEL=LongCat-Flash-Chat
```

The platform runs fully without any API keys. All deterministic features (profiling, cleaning, EDA, ML training, predictions) work without AI. AI features (data summaries, cleaning recommendations, ML strategy suggestions, prediction explanations) require at least one configured provider.

### 5. Run the Application

```bash
streamlit run app.py
```

Open **http://localhost:8501** in your browser. The application uses a wide layout with an expanded sidebar by default.

### 6. Verify the Installation

After launching, check the following in the sidebar:

- **AI Provider Status** should show green badges for any configured providers
- **Upload Dataset** should accept CSV, Excel, Parquet, and ZIP files
- The welcome screen should display with four feature cards (Universal Ingestion, Smart Cleaning, EDA & ML, Predictions)

---

## Docker Setup

### Using Docker Compose (Recommended)

1. Create the `.env` file as described above.

2. Build and start the container:

```bash
docker compose up --build
```

3. Open **http://localhost:8501** in your browser.

4. To stop the container:

```bash
docker compose down
```

### Using Docker Directly

```bash
# Build the image
docker build -t eda-ml-platform .

# Run the container
docker run -d \
  --name eda-ml-platform \
  -p 8501:8501 \
  --env-file .env \
  -v ./models:/app/models \
  -v ./datasets:/app/datasets \
  eda-ml-platform
```

### Docker Volumes

| Host Path | Container Path | Purpose |
|---|---|---|
| `./models` | `/app/models` | Persisted model packages |
| `./datasets` | `/app/datasets` | Optional pre-loaded datasets |

### Health Check

The Dockerfile includes a health check that polls `http://localhost:8501/_stcore/health`. You can verify container health with:

```bash
docker inspect --format='{{.State.Health.Status}}' eda-ml-platform
```

---

## Environment Configuration Reference

### Complete `.env` Example

```env
# ─── AI Provider Configuration ───────────────────────────────────

# Groq (https://console.groq.com/keys)
# Required for Groq-powered AI features.
GROQ_API_KEY=gsk_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# LongCat (https://longcat.ai)
# Optional. When configured, LongCat is used as the primary AI provider.
LONGCAT_API_KEY=lc_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
LONGCAT_MODEL=LongCat-Flash-Chat
```

### Provider Priority

When both `LONGCAT_API_KEY` and `GROQ_API_KEY` are set, LongCat is tried first. If LongCat fails or times out, Groq is used automatically. If only one key is set, that provider is used exclusively.

| LONGCAT_API_KEY | GROQ_API_KEY | Priority |
|---|---|---|
| Set | Set | LongCat → Groq |
| Set | Not set | LongCat only |
| Not set | Set | Groq only |
| Not set | Not set | No AI features (deterministic mode) |

---

## AI Provider Setup

### Groq

1. Create an account at [console.groq.com](https://console.groq.com).
2. Navigate to **API Keys** and generate a new key.
3. Set `GROQ_API_KEY` in your `.env` file.
4. The default model is `llama-3.3-70b-versatile`. No additional configuration is needed.

### LongCat

1. Create an account at [longcat.ai](https://longcat.ai).
2. Obtain an API key from your account dashboard.
3. Set `LONGCAT_API_KEY` in your `.env` file.
4. Optionally set `LONGCAT_MODEL` to override the default (`LongCat-Flash-Chat`).

### Testing Your Configuration

After setting up API keys, start the application and check the sidebar under **AI Provider Status**. Each provider should display a green "configured" badge. To verify functionality:

1. Upload any dataset.
2. Navigate to the **Data Understanding** tab.
3. Expand **AI-Generated Data Explanation** and click **Generate AI Summary**.
4. If the response appears, your AI configuration is working correctly.

---

## Troubleshooting

### Application Won't Start

**Symptom:** `ModuleNotFoundError` or `ImportError` when running `streamlit run app.py`.

**Solution:**
```bash
# Ensure your virtual environment is activated
which python    # Should point to venv/bin/python

# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

**Symptom:** `Port 8501 is already in use`.

**Solution:**
```bash
# Find and kill the process using port 8501
lsof -ti:8501 | xargs kill -9

# Or run on a different port
streamlit run app.py --server.port 8502
```

### File Upload Issues

**Symptom:** "Unsupported file extension" error.

**Solution:** Verify the file has one of the supported extensions: `.csv`, `.xlsx`, `.xls`, `.parquet`, `.zip`. The file uploader in the sidebar only accepts these types.

**Symptom:** CSV file loads but data looks garbled or has a single column.

**Solution:** The loader tries multiple encodings (UTF-8, Latin-1, CP1252, ISO-8859-1) and delimiters (comma, semicolon, tab, pipe). If none work, try converting the file to UTF-8 with a known delimiter before uploading:
```bash
iconv -f ISO-8859-1 -t UTF-8 data.csv > data_utf8.csv
```

**Symptom:** ZIP archive shows "contained no loadable files".

**Solution:** Ensure the ZIP contains `.csv`, `.xlsx`, `.xls`, or `.parquet` files. Hidden files (e.g., `__MACOSX/`) are automatically skipped. The archive must contain at least one loadable file.

### AI Features Not Working

**Symptom:** "No AI provider configured" warning in the sidebar.

**Solution:** Add at least one API key to your `.env` file and restart the application.

**Symptom:** AI requests return `[Error] ... timed out`.

**Solution:** Check your network connection. The default timeout is 30 seconds. LongCat requests that time out are automatically retried with Groq (if configured).

**Symptom:** AI strategy returns JSON parsing error.

**Solution:** This is handled gracefully — the raw AI response is stored as the strategy reasoning, and you can manually configure the target and features. The issue may be caused by the AI provider returning non-JSON content.

### ML Training Issues

**Symptom:** "No features remaining after filtering" error.

**Solution:** This occurs when all selected features are classified as identifiers, leakage risks, or the target column itself. Deselect columns that are IDs, codes, or derived from the target, and ensure at least one non-excluded feature is selected.

**Symptom:** Model metrics show a leakage warning (R-squared > 0.99 or accuracy > 0.99).

**Solution:** This indicates possible data leakage — a feature that directly reveals the target may be included. Review the selected features and remove any that are derived from, correlated with, or functionally equivalent to the target. The leakage detection utility (`is_leakage_risk`) catches common cases automatically, but domain-specific leakage requires manual review.

### Docker Issues

**Symptom:** Container exits immediately.

**Solution:** Check logs for errors:
```bash
docker compose logs
```

**Symptom:** Health check fails.

**Solution:** Verify the container is running and Streamlit is ready (it may take a few seconds to start):
```bash
docker compose logs --tail 50
docker exec eda-ml-platform curl -f http://localhost:8501/_stcore/health
```

### Memory Issues with Large Datasets

**Symptom:** Application becomes slow or crashes with large files.

**Solution:** The platform is designed for datasets that fit in memory. For very large files:
- Use Parquet format (columnar, efficient)
- Run the cleaning pipeline to downcast dtypes and convert categories (reduces memory usage)
- The CSV loader reads all data into a single DataFrame; consider pre-filtering large files before upload
