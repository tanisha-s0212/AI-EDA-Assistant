# Sample Walkthrough

This walkthrough demonstrates the full workflow of the AI-Assisted EDA & ML Platform using a hypothetical e-commerce customer dataset. The dataset is a CSV file named `customers.csv` with approximately 5,000 rows and 12 columns.

---

## Sample Dataset

Create a file called `customers.csv` with the following structure (abbreviated for illustration):

```
CustomerID,Name,Email,SignupDate,Age,Gender,Country,AnnualIncome,TotalPurchases,LastPurchaseDate,Churn,MembershipTier
1001,Alice Johnson,alice@email.com,2021-03-15,34,Female,USA,65000,12,2024-01-10,No,Gold
1002,Bob Smith,bob@email.com,2020-07-22,45,Male,UK,82000,28,2024-02-05,No,Platinum
1003,Carol Williams,carol@email.com,2022-11-01,28,Female,Canada,43000,5,2023-08-20,Yes,Silver
...
```

**Column overview:**

| Column | Type | Description |
|---|---|---|
| CustomerID | Integer | Unique customer identifier |
| Name | String | Customer full name |
| Email | String | Email address |
| SignupDate | Date | Account creation date |
| Age | Integer | Customer age in years |
| Gender | Categorical | Male / Female |
| Country | Categorical | Customer country |
| AnnualIncome | Float | Annual income in USD |
| TotalPurchases | Integer | Number of purchases made |
| LastPurchaseDate | Date | Most recent purchase date |
| Churn | Categorical | No / Yes (target variable) |
| MembershipTier | Categorical | Silver / Gold / Platinum |

---

## Step 1: Upload the Dataset

**Action:** Click the file uploader in the sidebar and select `customers.csv`.

**What happens behind the scenes:**
1. The file bytes are read and a SHA-256 hash is computed.
2. The hash is compared with the stored hash in session state — since this is a new file, the dataset state is reset.
3. The CSV loader tries UTF-8 encoding with comma delimiter (success on first attempt).
4. Column names are standardised (no changes needed in this case).
5. Empty columns are checked and removed (none found).

**What you see:**
- The welcome screen disappears and five tabs appear at the top.
- The sidebar shows the processing log:
  ```
  ℹ️ New file detected: customers.csv (245,678 bytes)
  ✓ Loaded 1 dataset(s) from customers.csv
  ✓ Dataset 'customers.csv': 5,000 rows × 12 columns
  ```
- The AI Provider Status shows green badges for any configured providers.

---

## Step 2: Data Understanding

**Action:** You are automatically placed on the **Data Understanding** tab.

**What you see:**

### Key Metrics
Four metric cards at the top:

| Total Rows | Total Columns | Memory Usage | Duplicate Rows |
|---|---|---|---|
| 5,000 | 12 | 2.35 MB | 3 |

### Column Role Distribution
Columns are automatically classified into roles:

| Role | Count | Columns |
|---|---|---|
| Identifier | 3 | CustomerID, Name, Email |
| Numeric | 3 | Age, AnnualIncome, TotalPurchases |
| Categorical | 3 | Gender, Country, MembershipTier |
| Boolean | 1 | Churn |
| Datetime | 2 | SignupDate, LastPurchaseDate |

### Missing Values
A warning badge shows "2 columns affected":

| Column | Missing Count | Missing Percent | Dtype |
|---|---|---|---|
| Age | 45 | 0.90% | float64 |
| AnnualIncome | 12 | 0.24% | float64 |

### Column Types
A table showing each column's dtype, unique count, and sample values.

### DataFrame Info
Expandable section with the full `df.info()` output showing dtypes, non-null counts, and memory usage.

### AI-Generated Data Explanation (if AI is configured)
**Action:** Expand "AI-Generated Data Explanation" and click "Generate AI Summary".

**Expected output:**
> This appears to be an e-commerce customer dataset with 5,000 records and 12 columns. The dataset tracks customer demographics (Age, Gender, Country), purchasing behaviour (AnnualIncome, TotalPurchases), and account information (SignupDate, MembershipTier). The target variable appears to be Churn (No/Yes), suggesting this dataset is suitable for a customer churn classification task. Data quality is generally good with only minor missing values in Age (0.9%) and AnnualIncome (0.24%). Three columns are identifiers (CustomerID, Name, Email) and should be excluded from modelling.

### AI Cleaning Recommendations (if AI is configured)
**Action:** Expand "AI Cleaning Recommendations" and click "Get Cleaning Suggestions".

**Expected output:**
> The dataset has minimal missing data. For the 45 missing Age values, median imputation is appropriate since the distribution is likely approximately normal. For the 12 missing AnnualIncome values, median imputation is also recommended. No duplicate rows should be present beyond the 3 exact duplicates detected. The SignupDate and LastPurchaseDate columns should be parsed as datetime for potential feature engineering. Identifier columns (CustomerID, Name, Email) should be excluded from any modelling workflow.

---

## Step 3: Cleaning and Preprocessing

**Action:** Navigate to the **Cleaning & Preprocessing** tab.

**What you see:**
A two-column configuration panel with seven checkboxes, all enabled by default:

| Left Column | Right Column |
|---|---|
| [x] Remove Duplicate Rows | [x] Convert to Category dtype |
| [x] Remove Summary Rows | [x] Downcast Numeric Types |
| [x] Impute Missing Numeric Values (median) | [x] Parse Date Columns |
| [x] Impute Missing Categorical Values (mode) | |

**Action:** Accept the defaults and click "Run Cleaning Pipeline".

**What happens behind the scenes:**
1. Duplicate rows (3 found) are dropped.
2. No summary rows are detected.
3. SignupDate and LastPurchaseDate are parsed as datetime.
4. 45 missing Age values are filled with the median (36.0).
5. 12 missing AnnualIncome values are filled with the median (61,200.0).
6. Gender, Country, and MembershipTier are converted to `category` dtype (each has fewer than 50 unique values and a unique-to-total ratio below 0.5).
7. Numeric columns are downcast (e.g., `int64` → `int32`, `float64` → `float32`).

**What you see:**

### Cleaning Summary
| Rows Before | Rows After | Rows Removed | Memory Saved |
|---|---|---|---|
| 5,000 | 4,997 | 3 | 0.38 MB |

### Cleaning Log (expandable)
```
============================================================
Data Cleansing Pipeline — started at 2024-03-15T10:23:45
Input: 5000 rows × 12 columns
============================================================
[duplicates] Removed 3 duplicate row(s).
[summary-rows] No summary rows detected.
[parse-dates] Parsed 'signupdate' as datetime (success rate 100%).
[parse-dates] Parsed 'lastpurchasedate' as datetime (success rate 99%).
[impute-numeric] 'age' — filled 45 NaN(s) with median (36.0000).
[impute-numeric] 'annualincome' — filled 12 NaN(s) with median (61200.0000).
[convert-categories] Converted 3 column(s) to 'category': ['gender', 'country', 'membershiptier']
[downcast] Numeric downcast saved 380.25 KB.
============================================================
Pipeline complete.
Output: 4997 rows × 12 columns | Memory: 2.35 MB → 1.97 MB
============================================================
```

### Cleaned Dataset Preview
A table showing the first 100 rows of the cleaned dataset. All missing values are filled, dates are parsed, and categorical columns show the category dtype.

### Downloads
The sidebar now shows download buttons for the cleaned data in CSV and Parquet formats.

---

## Step 4: Exploratory Data Analysis

**Action:** Navigate to the **EDA** tab.

**What you see:**

### Numeric Feature Statistics
A table with statistics for Age, AnnualIncome, and TotalPurchases (CustomerID is automatically excluded as an identifier):

| Column | Count | Missing % | Mean | Std | Min | 25% | 50% | 75% | Max | Skewness | Kurtosis |
|---|---|---|---|---|---|---|---|---|---|---|---|
| age | 4997 | 0.00% | 37.2 | 12.4 | 18 | 27 | 36 | 47 | 72 | 0.32 | -0.41 |
| annualincome | 4997 | 0.00% | 61840 | 28450 | 12000 | 42000 | 59000 | 78000 | 210000 | 1.15 | 1.82 |
| totalpurchases | 4997 | 0.00% | 15.8 | 14.2 | 0 | 5 | 11 | 22 | 87 | 1.52 | 2.34 |

### Distribution Plots
Histograms with KDE overlays for Age (approximately symmetric), AnnualIncome (right-skewed), and TotalPurchases (right-skewed).

### Box Plots
Box plots showing the interquartile ranges and outliers for each numeric feature. AnnualIncome and TotalPurchases show several outliers on the upper end.

### Categorical Feature Distributions
Bar charts for Gender, Country, and MembershipTier showing the count distribution across categories.

### Correlation Heatmap
A triangular heatmap with annotated correlation values. Expected notable correlations:
- AnnualIncome and TotalPurchases: moderate positive (r ≈ 0.45)
- Age and TotalPurchases: weak positive (r ≈ 0.18)

### AI EDA Narrative (if AI is configured)
**Action:** Expand "AI EDA Narrative" and click "Generate AI EDA Summary".

**Expected output:**
> The dataset contains 4,997 rows after cleaning. Three numeric features were analysed. Age is approximately symmetric (skewness = 0.32) with a mean of 37.2 years. AnnualIncome shows moderate right-skew (skewness = 1.15), indicating a concentration of customers in lower income brackets with some high earners. TotalPurchases is also right-skewed (skewness = 1.52). AnnualIncome and TotalPurchases have a moderate positive correlation (r = 0.45), suggesting higher-income customers tend to purchase more. No strong multicollinearity was detected. Data quality is good after cleaning — no missing values remain. AnnualIncome and TotalPurchases may benefit from log transformation for linear modelling approaches.

---

## Step 5: ML Assistant — Training a Model

**Action:** Navigate to the **ML Assistant** tab.

### Step 1: Define Your Objective
**Action:** In the text input, type:
```
Predict whether a customer will churn based on their demographics and purchasing behaviour
```

### Step 2: Get AI-Recommended Strategy (if AI is configured)
**Action:** Click "Get AI-Recommended Strategy".

**Expected AI response:**
```json
{
  "target_column": "churn",
  "problem_type": "classification",
  "recommended_features": ["age", "annualincome", "totalpurchases", "gender", "country", "membershiptier"],
  "not_recommended_features": ["customerid", "name", "email", "signupdate", "lastpurchasedate"],
  "reasoning": "This is a binary classification task. The target is 'churn' with values No/Yes. Recommended features capture demographics (age, gender, country), financial capacity (annualincome), and engagement (totalpurchases, membershiptier). Identifier columns (customerid, name, email) should be excluded. Date columns can be converted to numeric features but may introduce noise."
}
```

**What you see:**
- The AI strategy is displayed in a highlighted box.
- The target column dropdown auto-selects "churn".
- The problem type dropdown auto-selects "classification".
- Feature tags show which features are recommended (green), excluded (red), or optional (yellow).

### Step 3: Configure Target and Features
The dropdowns are pre-populated from the AI strategy. You can override them manually:
- **Target Column:** `churn`
- **Problem Type:** `classification`
- **Features:** `age`, `annualincome`, `totalpurchases`, `gender`, `country`, `membershiptier` (pre-selected)

### Step 4: Train Models
**Action:** Click "Train Models".

**What happens behind the scenes:**
1. Features are prepared: numeric columns are imputed and scaled; categorical columns are imputed and one-hot encoded.
2. Data is split 80/20 with stratification (since this is classification with only 2 classes).
3. Three models are trained: LogisticRegression, RandomForest, HistGradientBoosting.
4. All models are evaluated on the test set.

**What you see:**

### Evaluation Metrics Table
| Model | Accuracy | F1 Weighted | Train Time (ms) |
|---|---|---|---|
| LogisticRegression | 0.8412 | 0.8256 | 12.4 |
| RandomForest | 0.8734 | 0.8612 | 245.8 |
| HistGradientBoosting | **0.8856** | **0.8754** | 89.3 |

The best model (HistGradientBoosting) is highlighted.

### Feature Importance Plot
A horizontal bar chart showing the top features by importance:

| Rank | Feature | Importance |
|---|---|---|
| 1 | totalpurchases | 0.2842 |
| 2 | annualincome | 0.2215 |
| 3 | membershiptier_Gold | 0.1432 |
| 4 | age | 0.1198 |
| 5 | membershiptier_Silver | 0.0891 |

### Backtesting Results (if enabled)
A fold-by-fold table showing performance consistency:
- Mean Accuracy: 0.8812 (std: 0.0098)
- Mean F1: 0.8690 (std: 0.0112)

### Save Model
The model package is automatically saved to `models/` and a download button appears in the sidebar.

---

## Step 6: Prediction

**Action:** Navigate to the **Prediction** tab.

### Model Summary
A card showing the loaded model's details:
- Target: `churn`
- Type: `classification`
- Best Model: `HistGradientBoosting`
- Accuracy: `0.8856`
- Features: 6

### Input Form
The platform automatically generates input fields based on the model's feature schema:

| Field | Type | Input |
|---|---|---|
| Age | Numeric slider | 35 |
| AnnualIncome | Numeric slider | 55,000 |
| TotalPurchases | Numeric slider | 8 |
| Gender | Dropdown | Female |
| Country | Dropdown | USA |
| MembershipTier | Dropdown | Gold |

**Action:** Fill in the form and click "Predict".

**What you see:**

### Prediction Result
A large result card displays:
- **Prediction:** No (the customer is not expected to churn)
- **Confidence:** 87.3%

### AI Explanation (if AI is configured)
**Action:** Click "Get AI Explanation".

**Expected output:**
> This customer has an 87.3% probability of not churning. The key protective factors are the Gold membership tier (which strongly correlates with retention) and the moderate purchase frequency of 8 orders. The annual income of $55,000 is above the median, which is also a positive signal. If this customer's purchase frequency were to decline or their membership tier were to change, the churn risk would increase significantly.

### Prediction History
A table accumulating all predictions made in the current session, showing the input values, prediction, and confidence for each.

---

## Tips for Best Results

### Data Preparation
- **Clean your headers first** — remove merged cells, multi-row headers, or special characters in column names before uploading. The platform standardises names, but extreme formatting may cause issues.
- **Use consistent encodings** — UTF-8 is preferred. If your CSV was exported from Excel on Windows, it may be CP1252. The loader handles this automatically, but pre-converting to UTF-8 avoids ambiguity.
- **Avoid summary rows** at the end of your data (e.g., "Grand Total", "Average"). The cleaning pipeline removes these, but large blocks of summary rows may confuse the initial profiler.

### Cleaning
- **Review the cleaning log** — every operation is logged with the number of affected rows. Check that the imputation values make sense for your domain.
- **Disable aggressive steps** — if your data has intentional duplicate rows, uncheck "Remove Duplicate Rows". If date parsing converts a column incorrectly, uncheck "Parse Date Columns" for that run.
- **Run cleaning before EDA** — the EDA tab uses the cleaned dataset when available, falling back to the raw dataset otherwise.

### ML Training
- **Use AI strategy as a starting point** — the AI recommendations are based on column names and types. Always review and adjust the feature selection based on your domain knowledge.
- **Check for leakage** — if the best model achieves > 99% accuracy or R-squared, a feature is likely leaking the target. Review the feature importance list for suspicious entries.
- **Try different feature combinations** — removing highly correlated features or adding engineered features (e.g., `tenure_days = last_purchase_date - signup_date`) can improve performance.
- **Consider the sample size** — with very small datasets (< 100 rows), model performance may be unreliable. With very large datasets (> 100,000 rows), training may take longer but results are more stable.

### Predictions
- **Provide realistic inputs** — the model was trained on a specific feature distribution. Inputs far outside the training range (e.g., Age = 200) will be processed but may produce unreliable predictions.
- **Use batch predictions for large volumes** — uploading a CSV with many rows is more efficient than entering values one at a time.
- **Review confidence scores** — for classification models, low confidence (close to 50%) indicates the model is uncertain. Treat these predictions with caution.

### General
- **The processing log tracks everything** — expand the "Processing Log" in the sidebar to see a timestamped history of all operations. This is useful for debugging unexpected results.
- **Download your work** — use the sidebar download buttons to export the cleaned dataset (CSV or Parquet) and the trained model package (PKL).
- **Switch datasets freely** — when uploading a ZIP with multiple files, use the "Switch Dataset" dropdown in the sidebar. ML state is automatically reset on dataset switches.
