"""
Tests for data_cleanser module — duplicate removal, summary row removal,
imputation strategies, logging, and cleaning summary accuracy.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.data_cleanser import DataCleanser


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def df_with_duplicates():
    """DataFrame containing exact duplicate rows."""
    np.random.seed(42)
    base = pd.DataFrame({
        "name": ["Alice", "Bob", "Carol"],
        "score": [85, 90, 78],
    })
    # Add duplicates
    dupes = base.iloc[[0, 1]].copy()
    return pd.concat([base, dupes], ignore_index=True)  # 5 rows, 2 duplicates


@pytest.fixture
def df_with_summary_rows():
    """DataFrame containing summary / aggregation rows among regular data."""
    return pd.DataFrame({
        "item": ["Widget A", "Widget B", "TOTAL", "Widget C", "Subtotal"],
        "revenue": [100, 200, 300, 150, 350],
    })


@pytest.fixture
def df_with_missing_numeric():
    """DataFrame with NaN values in numeric columns."""
    return pd.DataFrame({
        "age": [25, 30, np.nan, 40, np.nan, 35],
        "salary": [50000, np.nan, 60000, np.nan, 55000, 70000],
    })


@pytest.fixture
def df_with_missing_categorical():
    """DataFrame with NaN values in categorical columns."""
    return pd.DataFrame({
        "city": ["NYC", "LA", None, "NYC", None, "LA"],
        "status": [None, "active", "active", None, "active", "inactive"],
    })


# ---------------------------------------------------------------------------
# Tests: Duplicate row removal
# ---------------------------------------------------------------------------

class TestDuplicateRemoval:

    def test_duplicates_are_removed(self, df_with_duplicates):
        """Exact duplicate rows should be removed during cleaning."""
        cleanser = DataCleanser(df_with_duplicates)
        result = cleanser.clean(remove_summary_rows=False, impute_numeric=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        assert len(result) == 3  # original 3 unique rows

    def test_no_duplicates_no_rows_lost(self):
        """If no duplicates exist, row count should remain the same."""
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        cleanser = DataCleanser(df)
        result = cleanser.clean(remove_summary_rows=False, impute_numeric=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        assert len(result) == len(df)

    def test_duplicates_disabled(self, df_with_duplicates):
        """When remove_duplicates=False, all rows should remain."""
        cleanser = DataCleanser(df_with_duplicates)
        result = cleanser.clean(remove_duplicates=False, remove_summary_rows=False,
                                impute_numeric=False, impute_categorical=False,
                                convert_categories=False, downcast_numeric=False,
                                parse_dates=False)
        assert len(result) == len(df_with_duplicates)


# ---------------------------------------------------------------------------
# Tests: Summary row removal
# ---------------------------------------------------------------------------

class TestSummaryRowRemoval:

    def test_summary_rows_removed(self, df_with_summary_rows):
        """Rows containing 'TOTAL' or 'Subtotal' should be removed."""
        cleanser = DataCleanser(df_with_summary_rows)
        result = cleanser.clean(remove_duplicates=False, impute_numeric=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        # Only Widget A, Widget B, and Widget C should survive
        assert len(result) == 3
        for val in result["item"].values:
            assert val.lower() not in ("total", "subtotal")

    def test_summary_rows_case_insensitive(self):
        """Summary keywords should be detected case-insensitively."""
        df = pd.DataFrame({"label": ["Grand Total", "data row", "NET TOTAL"]})
        cleanser = DataCleanser(df)
        result = cleanser.clean(remove_duplicates=False, impute_numeric=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        assert len(result) == 1
        assert result.iloc[0]["label"] == "data row"


# ---------------------------------------------------------------------------
# Tests: Numeric imputation with median
# ---------------------------------------------------------------------------

class TestNumericImputation:

    def test_missing_numeric_imputed_with_median(self, df_with_missing_numeric):
        """NaN values in numeric columns should be filled with column median."""
        cleanser = DataCleanser(df_with_missing_numeric)
        result = cleanser.clean(remove_duplicates=False, remove_summary_rows=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        # After imputation there should be no NaN values
        assert result["age"].isna().sum() == 0
        assert result["salary"].isna().sum() == 0

    def test_median_value_used(self, df_with_missing_numeric):
        """The imputed value should equal the median of non-null values."""
        cleanser = DataCleanser(df_with_missing_numeric)
        result = cleanser.clean(remove_duplicates=False, remove_summary_rows=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        expected_age_median = df_with_missing_numeric["age"].median()
        # One of the previously-NaN rows should now hold the median
        assert expected_age_median in result["age"].values


# ---------------------------------------------------------------------------
# Tests: Categorical imputation with mode
# ---------------------------------------------------------------------------

class TestCategoricalImputation:

    def test_missing_categorical_imputed(self, df_with_missing_categorical):
        """NaN values in categorical columns should be filled."""
        cleanser = DataCleanser(df_with_missing_categorical)
        result = cleanser.clean(remove_duplicates=False, remove_summary_rows=False,
                                impute_numeric=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        assert result["city"].isna().sum() == 0
        assert result["status"].isna().sum() == 0

    def test_mode_used_for_categorical(self, df_with_missing_categorical):
        """The imputed value should be the mode of the column."""
        cleanser = DataCleanser(df_with_missing_categorical)
        result = cleanser.clean(remove_duplicates=False, remove_summary_rows=False,
                                impute_numeric=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        # Mode of city (non-null) is "NYC" or "LA" (both appear twice among non-nulls).
        # After imputation the previously-NaN cells should hold a valid value.
        for val in result["city"].values:
            assert val is not None and val != ""


# ---------------------------------------------------------------------------
# Tests: Cleaning logs
# ---------------------------------------------------------------------------

class TestCleaningLogs:

    def test_logs_generated(self, df_with_duplicates):
        """Cleaning should produce a non-empty list of log messages."""
        cleanser = DataCleanser(df_with_duplicates)
        cleanser.clean()
        logs = cleanser.get_logs()
        assert isinstance(logs, list)
        assert len(logs) > 0

    def test_log_contains_pipeline_header(self, simple_df):
        """Logs should contain a pipeline start header."""
        cleanser = DataCleanser(simple_df)
        cleanser.clean()
        logs = cleanser.get_logs()
        assert any("Data Cleansing Pipeline" in msg for msg in logs)

    def test_log_mentions_duplicates(self, df_with_duplicates):
        """When duplicates exist, logs should mention their removal."""
        cleanser = DataCleanser(df_with_duplicates)
        cleanser.clean()
        logs = cleanser.get_logs()
        assert any("duplicate" in msg.lower() for msg in logs)

    def test_log_mentions_summary_rows(self, df_with_summary_rows):
        """When summary rows exist, logs should mention their removal."""
        cleanser = DataCleanser(df_with_summary_rows)
        cleanser.clean()
        logs = cleanser.get_logs()
        assert any("summary" in msg.lower() for msg in logs)


# ---------------------------------------------------------------------------
# Tests: Cleaning summary accuracy
# ---------------------------------------------------------------------------

class TestCleaningSummary:

    def test_summary_row_counts(self, df_with_duplicates):
        """get_summary should report correct row counts and duplicate count."""
        cleanser = DataCleanser(df_with_duplicates)
        result = cleanser.clean(remove_summary_rows=False, impute_numeric=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        summary = cleanser.get_summary()
        assert summary["rows_before"] == 5
        assert summary["rows_after"] == 3
        assert summary["duplicates_removed"] == 2

    def test_summary_has_required_keys(self, simple_df):
        """The summary dict should contain all expected keys."""
        cleanser = DataCleanser(simple_df)
        cleanser.clean()
        summary = cleanser.get_summary()
        expected_keys = {
            "rows_before", "rows_after", "cols_before", "cols_after",
            "duplicates_removed", "summary_rows_removed", "columns_imputed",
            "memory_before_mb", "memory_after_mb",
        }
        assert expected_keys.issubset(set(summary.keys()))

    def test_summary_memory_fields_are_numeric(self, simple_df):
        """memory_before_mb and memory_after_mb should be numeric values."""
        cleanser = DataCleanser(simple_df)
        cleanser.clean()
        summary = cleanser.get_summary()
        assert isinstance(summary["memory_before_mb"], (int, float))
        assert isinstance(summary["memory_after_mb"], (int, float))
        assert summary["memory_before_mb"] >= 0
        assert summary["memory_after_mb"] >= 0

    def test_summary_columns_imputed(self, df_with_missing_numeric):
        """columns_imputed should reflect the number of columns that had NaNs."""
        cleanser = DataCleanser(df_with_missing_numeric)
        result = cleanser.clean(remove_duplicates=False, remove_summary_rows=False,
                                impute_categorical=False, convert_categories=False,
                                downcast_numeric=False, parse_dates=False)
        summary = cleanser.get_summary()
        assert summary["columns_imputed"] >= 1  # at least one column had NaNs


# ---------------------------------------------------------------------------
# Simple fixture used by some log tests above
# ---------------------------------------------------------------------------

@pytest.fixture
def simple_df():
    np.random.seed(42)
    return pd.DataFrame({
        "val": np.random.randn(20),
        "cat": np.random.choice(["x", "y", "z"], 20),
    })
