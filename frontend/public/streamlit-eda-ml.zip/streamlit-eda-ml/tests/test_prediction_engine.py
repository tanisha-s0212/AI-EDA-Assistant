"""
Tests for prediction_engine module — single prediction, input form schema
generation, batch predictions, and prediction with missing inputs.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.ml_engine import MLPipeline
from modules.prediction_engine import PredictionEngine


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def trained_regression_package(tmp_path):
    """Train a regression model and return a saved model package dict.

    Feature names avoid ID-related substrings (no, num, id, code, key)
    and values are rounded to keep cardinality moderate so the pipeline's
    identifier detector does not reject them.
    """
    np.random.seed(42)
    n = 300
    x1 = np.round(np.random.randn(n) * 5, 1)
    x2 = np.round(np.random.randn(n) * 5, 1)
    y = 3.0 * x1 + 5.0 * x2 + np.random.randn(n) * 0.5

    df = pd.DataFrame({
        "measurement_a": x1,
        "measurement_b": x2,
        "group": np.random.choice(["alpha", "beta", "gamma"], n),
        "target": y,
    })

    pipeline = MLPipeline(problem_type="regression", random_state=42)
    features = ["measurement_a", "measurement_b", "group"]
    result = pipeline.run_full_pipeline(
        df=df,
        target_column="target",
        selected_features=features,
        exclude_features=[],
        problem_type="regression",
    )

    # Use raw (pre-encoding) feature names so the PredictionEngine can
    # build DataFrames with the correct column names for the preprocessor.
    raw_features = result["numeric_features"] + result["categorical_features"]

    filepath = str(tmp_path / "regression_model.joblib")
    pipeline.save_model_package(
        model=result["best_model"],
        preprocessor=result["preprocessor"],
        feature_list=raw_features,
        target="target",
        problem_type="regression",
        numeric_features=result["numeric_features"],
        categorical_features=result["categorical_features"],
        date_columns=[],
        metrics=result["evaluation"][result["best_model_name"]],
        feature_importance=result["feature_importance"],
        filepath=filepath,
    )

    return MLPipeline.load_model_package(filepath)


@pytest.fixture
def trained_classification_package(tmp_path):
    """Train a classification model and return a saved model package dict."""
    np.random.seed(42)
    n = 300
    x1 = np.round(np.random.randn(n) * 5, 1)
    x2 = np.round(np.random.randn(n) * 5, 1)
    z = 2.0 * x1 - 1.5 * x2
    y = (z > 0).astype(int)

    df = pd.DataFrame({
        "measurement_a": x1,
        "measurement_b": x2,
        "group": np.random.choice(["red", "blue"], n),
        "target": y,
    })

    pipeline = MLPipeline(problem_type="classification", random_state=42)
    features = ["measurement_a", "measurement_b", "group"]
    result = pipeline.run_full_pipeline(
        df=df,
        target_column="target",
        selected_features=features,
        exclude_features=[],
        problem_type="classification",
    )

    # Use raw (pre-encoding) feature names
    raw_features = result["numeric_features"] + result["categorical_features"]

    filepath = str(tmp_path / "classification_model.joblib")
    pipeline.save_model_package(
        model=result["best_model"],
        preprocessor=result["preprocessor"],
        feature_list=raw_features,
        target="target",
        problem_type="classification",
        numeric_features=result["numeric_features"],
        categorical_features=result["categorical_features"],
        date_columns=[],
        metrics=result["evaluation"][result["best_model_name"]],
        feature_importance=result["feature_importance"],
        filepath=filepath,
    )

    return MLPipeline.load_model_package(filepath)


# ---------------------------------------------------------------------------
# Tests: Single prediction from saved model
# ---------------------------------------------------------------------------

class TestSinglePrediction:

    def test_regression_single_prediction(self, trained_regression_package):
        """A single prediction on a regression model should return a numeric result."""
        engine = PredictionEngine(trained_regression_package)
        inputs = {
            "measurement_a": 1.0,
            "measurement_b": 2.0,
            "group": "alpha",
        }
        result = engine.predict(inputs)
        assert result["success"] is True
        assert result["prediction"] is not None
        assert isinstance(result["prediction"], float)
        assert np.isfinite(result["prediction"])

    def test_classification_single_prediction(self, trained_classification_package):
        """A single prediction on a classification model should succeed."""
        engine = PredictionEngine(trained_classification_package)
        inputs = {
            "measurement_a": 0.5,
            "measurement_b": -0.5,
            "group": "red",
        }
        result = engine.predict(inputs)
        assert result["success"] is True
        assert result["prediction"] is not None

    def test_classification_prediction_has_label(self, trained_classification_package):
        """Classification prediction should include a prediction_label."""
        engine = PredictionEngine(trained_classification_package)
        inputs = {
            "measurement_a": 1.0,
            "measurement_b": -1.0,
            "group": "blue",
        }
        result = engine.predict(inputs)
        assert result["prediction_label"] is not None
        assert isinstance(result["prediction_label"], str)


# ---------------------------------------------------------------------------
# Tests: Input form schema generation
# ---------------------------------------------------------------------------

class TestInputFormSchema:

    def test_schema_generated(self, trained_regression_package):
        """generate_input_form_schema should return a list of dicts."""
        engine = PredictionEngine(trained_regression_package)
        schema = engine.generate_input_form_schema()
        assert isinstance(schema, list)
        assert len(schema) > 0

    def test_schema_has_required_fields(self, trained_regression_package):
        """Each schema entry should contain name, dtype, and role."""
        engine = PredictionEngine(trained_regression_package)
        schema = engine.generate_input_form_schema()
        for entry in schema:
            assert "name" in entry
            assert "dtype" in entry
            assert "role" in entry

    def test_schema_numeric_role(self, trained_regression_package):
        """Numeric features in the schema should have role='numeric' and dtype='float'."""
        engine = PredictionEngine(trained_regression_package)
        schema = engine.generate_input_form_schema()
        num_entries = [e for e in schema if e["role"] == "numeric"]
        assert len(num_entries) >= 1
        for entry in num_entries:
            assert entry["dtype"] == "float"

    def test_schema_categorical_role(self, trained_regression_package):
        """Categorical features in the schema should have role='categorical'."""
        engine = PredictionEngine(trained_regression_package)
        schema = engine.generate_input_form_schema()
        cat_entries = [e for e in schema if e["role"] == "categorical"]
        assert len(cat_entries) >= 1
        for entry in cat_entries:
            assert entry["dtype"] == "str"

    def test_schema_feature_count_matches(self, trained_regression_package):
        """The number of schema entries should match the feature list length."""
        engine = PredictionEngine(trained_regression_package)
        schema = engine.generate_input_form_schema()
        assert len(schema) == len(engine.feature_list)


# ---------------------------------------------------------------------------
# Tests: Batch predictions
# ---------------------------------------------------------------------------

class TestBatchPrediction:

    def test_batch_prediction_returns_dataframe(self, trained_regression_package):
        """predict_batch should return a DataFrame with a 'prediction' column."""
        engine = PredictionEngine(trained_regression_package)
        batch_df = pd.DataFrame({
            "measurement_a": [0.0, 1.0, -1.0],
            "measurement_b": [0.0, 1.0, -1.0],
            "group": ["alpha", "beta", "gamma"],
        })
        result = engine.predict_batch(batch_df)
        assert isinstance(result, pd.DataFrame)
        assert "prediction" in result.columns
        assert len(result) == 3

    def test_batch_predictions_are_finite(self, trained_regression_package):
        """All batch predictions should be finite numbers."""
        engine = PredictionEngine(trained_regression_package)
        batch_df = pd.DataFrame({
            "measurement_a": [0.5, -0.5, 2.0, -2.0],
            "measurement_b": [1.0, -1.0, 0.5, -0.5],
            "group": ["alpha", "beta", "alpha", "beta"],
        })
        result = engine.predict_batch(batch_df)
        for val in result["prediction"]:
            assert np.isfinite(val)

    def test_classification_batch_has_labels(self, trained_classification_package):
        """Classification batch predictions should include prediction labels."""
        engine = PredictionEngine(trained_classification_package)
        batch_df = pd.DataFrame({
            "measurement_a": [1.0, -1.0, 0.0],
            "measurement_b": [-1.0, 1.0, 0.0],
            "group": ["red", "blue", "red"],
        })
        result = engine.predict_batch(batch_df)
        # prediction_label may or may not exist depending on class_labels
        assert "prediction" in result.columns

    def test_batch_preserves_row_count(self, trained_regression_package):
        """The output row count should match the input row count."""
        engine = PredictionEngine(trained_regression_package)
        n = 10
        batch_df = pd.DataFrame({
            "measurement_a": np.round(np.random.randn(n), 1),
            "measurement_b": np.round(np.random.randn(n), 1),
            "group": np.random.choice(["alpha", "beta", "gamma"], n),
        })
        result = engine.predict_batch(batch_df)
        assert len(result) == n


# ---------------------------------------------------------------------------
# Tests: Prediction with missing inputs
# ---------------------------------------------------------------------------

class TestPredictionWithMissingInputs:

    def test_missing_numeric_defaults_to_zero(self, trained_regression_package):
        """When a numeric input is missing/None, it should be coerced to 0.0."""
        engine = PredictionEngine(trained_regression_package)
        inputs = {"measurement_a": None, "measurement_b": 1.0, "group": "alpha"}
        result = engine.predict(inputs)
        assert result["success"] is True

    def test_missing_categorical_defaults_to_missing(self, trained_regression_package):
        """When a categorical input is missing/None, it should be coerced to 'missing'."""
        engine = PredictionEngine(trained_regression_package)
        inputs = {"measurement_a": 1.0, "measurement_b": 0.0, "group": None}
        result = engine.predict(inputs)
        assert result["success"] is True

    def test_empty_string_numeric_handled(self, trained_regression_package):
        """An empty string for a numeric feature should not crash."""
        engine = PredictionEngine(trained_regression_package)
        inputs = {"measurement_a": "", "measurement_b": 0.5, "group": "alpha"}
        result = engine.predict(inputs)
        assert result["success"] is True

    def test_batch_missing_features_filled(self, trained_regression_package):
        """Batch prediction should fill missing feature columns with defaults."""
        engine = PredictionEngine(trained_regression_package)
        # Omit measurement_a on purpose
        batch_df = pd.DataFrame({
            "measurement_b": [0.0, 1.0],
            "group": ["alpha", "beta"],
        })
        result = engine.predict_batch(batch_df)
        assert isinstance(result, pd.DataFrame)
        assert "prediction" in result.columns
        assert len(result) == 2

    def test_get_model_info_returns_dict(self, trained_regression_package):
        """get_model_info should return a dictionary with model metadata."""
        engine = PredictionEngine(trained_regression_package)
        info = engine.get_model_info()
        assert isinstance(info, dict)
        assert info["problem_type"] == "regression"
        assert info["target"] == "target"
        assert info["feature_count"] > 0
