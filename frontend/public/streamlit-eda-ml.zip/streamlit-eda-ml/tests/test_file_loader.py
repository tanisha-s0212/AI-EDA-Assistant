"""
Tests for file_loader module — CSV loading, duplicate column handling,
file hash computation, empty column dropping, and column name standardization.
"""

import os
import sys
import io
import csv

import numpy as np
import pandas as pd
import pytest

# Ensure project root is on sys.path so that `from modules…` works inside tests/
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.utils import compute_file_hash, safe_standardize_columns, drop_empty_columns


# ---------------------------------------------------------------------------
# Helpers / lightweight mocks
# ---------------------------------------------------------------------------

class _FakeUploadedFile:
    """Minimal stand-in for st.runtime.uploaded_file_manager.UploadedFile."""

    def __init__(self, name: str, data: bytes):
        self.name = name
        self._buf = io.BytesIO(data)

    def read(self):
        return self._buf.read()

    def seek(self, pos):
        self._buf.seek(pos)


def _make_csv_bytes(df: pd.DataFrame, encoding: str = "utf-8", sep: str = ",") -> bytes:
    return df.to_csv(index=False, sep=sep).encode(encoding)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def simple_df():
    """A small, well-behaved DataFrame for general-purpose tests."""
    np.random.seed(42)
    return pd.DataFrame({
        "Age": np.random.randint(18, 70, 50),
        "Income": np.random.uniform(30_000, 120_000, 50),
        "Category": np.random.choice(["A", "B", "C"], 50),
    })


@pytest.fixture
def csv_bytes_utf8(simple_df):
    return _make_csv_bytes(simple_df, encoding="utf-8")


@pytest.fixture
def csv_bytes_latin1(simple_df):
    #latin-1 can encode any byte so this always works
    return _make_csv_bytes(simple_df, encoding="latin-1")


@pytest.fixture
def csv_with_dup_columns():
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Name", "Score", "Name", "Score"])
    writer.writerow(["Alice", 88, "Bob", 92])
    writer.writerow(["Carol", 75, "Dave", 81])
    return buf.getvalue().encode("utf-8")


@pytest.fixture
def csv_with_empty_columns():
    df = pd.DataFrame({
        "A": [1, 2, 3],
        "B": [None, None, None],
        "C": ["x", "y", "z"],
    })
    return _make_csv_bytes(df)


@pytest.fixture
def csv_messy_columns():
    df = pd.DataFrame({
        " First Name ": ["Alice", "Bob"],
        "Last-Name@": ["Smith", "Jones"],
        "  Age  ": [30, 25],
    })
    return _make_csv_bytes(df)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestCSVLoadingEncodings:
    """Verify that CSV content can be loaded from different encodings."""

    def test_load_utf8_csv(self, simple_df, csv_bytes_utf8):
        """CSV encoded as UTF-8 should load without error."""
        from modules.file_loader import _load_csv
        df = _load_csv(csv_bytes_utf8, "test_utf8.csv")
        assert df is not None
        assert len(df) == len(simple_df)
        assert "Age" in df.columns

    def test_load_latin1_csv(self, simple_df, csv_bytes_latin1):
        """CSV encoded as latin-1 should load without error."""
        from modules.file_loader import _load_csv
        df = _load_csv(csv_bytes_latin1, "test_latin1.csv")
        assert df is not None
        assert len(df) == len(simple_df)

    def test_load_csv_with_different_delimiters(self, simple_df):
        """Semicolon and tab-delimited CSVs should be auto-detected."""
        from modules.file_loader import _load_csv
        for sep in (";", "\t"):
            raw = simple_df.to_csv(index=False, sep=sep).encode("utf-8")
            df = _load_csv(raw, f"test_sep_{repr(sep)}.csv")
            assert len(df) == len(simple_df), f"Failed for delimiter {repr(sep)}"


class TestDuplicateColumnHandling:
    """Ensure duplicate column names are resolved after standardization."""

    def test_duplicate_columns_standardized(self, csv_with_dup_columns):
        """After prepare_dataset, duplicate column names should be unique."""
        from modules.file_loader import _load_csv, prepare_dataset
        df = _load_csv(csv_with_dup_columns, "dup_cols.csv")
        df, _ = prepare_dataset(df, "dup_cols.csv")
        # Column names must be unique
        assert len(df.columns) == len(set(df.columns))

    def test_standardize_adds_dup_suffix(self):
        """safe_standardize_columns should suffix duplicates with _dup_N."""
        df = pd.DataFrame([[1, 2, 3]], columns=["col", "col", "col"])
        result = safe_standardize_columns(df)
        assert result.columns.tolist() == ["col", "col_dup_1", "col_dup_2"]


class TestFileHashComputation:
    """File hashing for detecting new uploads."""

    def test_same_bytes_same_hash(self, csv_bytes_utf8):
        """Identical file content must produce the same hash."""
        h1 = compute_file_hash(csv_bytes_utf8)
        h2 = compute_file_hash(csv_bytes_utf8)
        assert h1 == h2

    def test_different_bytes_different_hash(self, csv_bytes_utf8):
        """Different file content should (with overwhelming probability) differ."""
        h1 = compute_file_hash(csv_bytes_utf8)
        altered = csv_bytes_utf8[:-1] + (b"!" if csv_bytes_utf8[-1] != b"!"[0] else b"?")
        h2 = compute_file_hash(altered)
        assert h1 != h2

    def test_get_file_hash_via_fake_uploaded_file(self, csv_bytes_utf8):
        """get_file_hash should return a non-empty hex string."""
        from modules.file_loader import get_file_hash
        fake = _FakeUploadedFile("test.csv", csv_bytes_utf8)
        h = get_file_hash(fake)
        assert isinstance(h, str)
        assert len(h) > 0

    def test_get_file_hash_supports_sha256_algorithm(self, csv_bytes_utf8):
        """SHA-256 digests should be 64 hex characters long."""
        h = compute_file_hash(csv_bytes_utf8, algorithm="sha256")
        assert len(h) == 64

    def test_unsupported_hash_algorithm_raises(self, csv_bytes_utf8):
        """An unsupported algorithm should raise ValueError."""
        with pytest.raises(ValueError, match="Unsupported hash algorithm"):
            compute_file_hash(csv_bytes_utf8, algorithm="nonexistent_algo")


class TestEmptyColumnDropping:
    """Columns that are entirely NaN should be dropped."""

    def test_drop_empty_columns(self, csv_with_empty_columns):
        """After prepare_dataset, the all-NaN column B should be gone."""
        from modules.file_loader import _load_csv, prepare_dataset
        df = _load_csv(csv_with_empty_columns, "empty_cols.csv")
        df, _ = prepare_dataset(df, "empty_cols.csv")
        # Column names are lowercased during standardization
        assert "b" not in df.columns
        assert "a" in df.columns
        assert "c" in df.columns

    def test_drop_empty_columns_no_op(self, simple_df):
        """If no columns are empty, none should be dropped."""
        df = drop_empty_columns(simple_df.copy())
        assert len(df.columns) == len(simple_df.columns)


class TestColumnNameStandardization:
    """Column names should be lowercased, spaces replaced, special chars removed."""

    def test_messy_columns_standardized(self, csv_messy_columns):
        """Whitespace-trimmed, lowercased, special-chars-removed column names."""
        from modules.file_loader import _load_csv, prepare_dataset
        df = _load_csv(csv_messy_columns, "messy.csv")
        df, orig = prepare_dataset(df, "messy.csv")
        # Check that no column has uppercase letters
        for col in df.columns:
            assert col == col.lower(), f"Column '{col}' is not lowercased"
        # Check that no column has leading/trailing whitespace
        for col in df.columns:
            assert col == col.strip(), f"Column '{col}' has leading/trailing whitespace"

    def test_special_characters_removed(self):
        """Special characters like @, -, etc. should be stripped from column names."""
        df = pd.DataFrame([[1]], columns=["col@#$"])
        result = safe_standardize_columns(df)
        assert result.columns[0] == "col"

    def test_spaces_replaced_with_underscores(self):
        """Internal spaces in column names should become underscores."""
        df = pd.DataFrame([[1]], columns=["my column name"])
        result = safe_standardize_columns(df)
        assert result.columns[0] == "my_column_name"

    def test_numeric_column_names_handled(self):
        """Numeric column names should be stringified without error."""
        df = pd.DataFrame([[1, 2]], columns=[0, 1])
        result = safe_standardize_columns(df)
        assert result.columns.tolist() == ["0", "1"]

    def test_prepare_dataset_returns_original_columns(self, simple_df):
        """prepare_dataset should return the original column names as second element."""
        from modules.file_loader import prepare_dataset
        df, orig = prepare_dataset(simple_df.copy(), "test.csv")
        assert orig == list(simple_df.columns)
