"""
Tests for ml_engine module — regression/classification training with synthetic
data, model save/load round-trip, feature importance, target exclusion, and
leakage detection.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.ml_engine import MLPipeline


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def regression_df():
    """Synthetic dataset for a regression task: y = 3*x1 + 5*x2 + noise.

    Uses rounded values to keep cardinality moderate so the ML pipeline's
    identifier detector (which rejects columns with > 95 % unique values)
    does not filter out the feature columns.
    """
    np.random.seed(42)
    n = 300
    # Round to 1 decimal → ~60 unique values → cardinality ≈ 0.2
    x1 = np.round(np.random.randn(n) * 5, 1)
    x2 = np.round(np.random.randn(n) * 5, 1)
    noise = np.random.randn(n) * 0.5
    y = 3.0 * x1 + 5.0 * x2 + noise
    return pd.DataFrame({
        "measurement_a": x1,
        "measurement_b": x2,
        "category": np.random.choice(["low", "medium", "high"], n),
        "target": y,
    })


@pytest.fixture
def classification_df():
    """Synthetic dataset for a binary classification task.

    Uses rounded values to keep cardinality moderate.
    """
    np.random.seed(42)
    n = 300
    x1 = np.round(np.random.randn(n) * 5, 1)
    x2 = np.round(np.random.randn(n) * 5, 1)
    # Deterministic label based on linear combination
    z = 2.0 * x1 - 1.5 * x2
    y = (z > 0).astype(int)
    return pd.DataFrame({
        "measurement_a": x1,
        "measurement_b": x2,
        "category": np.random.choice(["red", "blue", "green"], n),
        "target": y,
    })


@pytest.fixture
def pipeline():
    return MLPipeline(problem_type="auto", random_state=42)


# ---------------------------------------------------------------------------
# Tests: Regression training
# ---------------------------------------------------------------------------

class TestRegressionTraining:

    def test_regression_full_pipeline_runs(self, pipeline, regression_df):
        """run_full_pipeline should complete without error for regression data."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        assert "problem_type" in result
        assert result["problem_type"] == "regression"
        assert "best_model_name" in result
        assert "evaluation" in result

    def test_regression_has_metrics(self, pipeline, regression_df):
        """Regression evaluation should contain R2, RMSE, and MAE."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        for model_name, metrics in result["evaluation"].items():
            assert "R2" in metrics
            assert "RMSE" in metrics
            assert "MAE" in metrics
            # On a well-separated synthetic dataset, R2 should be reasonably high
            assert metrics["R2"] > 0.5

    def test_regression_trains_multiple_models(self, pipeline, regression_df):
        """Multiple models (Ridge, RandomForest, HistGradientBoosting) should be trained."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        assert len(result["models"]) >= 3


# ---------------------------------------------------------------------------
# Tests: Classification training
# ---------------------------------------------------------------------------

class TestClassificationTraining:

    def test_classification_full_pipeline_runs(self, pipeline, classification_df):
        """run_full_pipeline should complete without error for classification data."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=classification_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="classification",
        )
        assert result["problem_type"] == "classification"
        assert "best_model_name" in result

    def test_classification_has_metrics(self, pipeline, classification_df):
        """Classification evaluation should contain Accuracy and F1_weighted."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=classification_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="classification",
        )
        for model_name, metrics in result["evaluation"].items():
            assert "Accuracy" in metrics
            assert "F1_weighted" in metrics
            # On a well-separated dataset, accuracy should be high
            assert metrics["Accuracy"] > 0.5

    def test_auto_detects_classification(self, pipeline, classification_df):
        """When problem_type='auto', classification should be detected for binary target."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=classification_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="auto",
        )
        assert result["problem_type"] == "classification"


# ---------------------------------------------------------------------------
# Tests: Model save/load round-trip
# ---------------------------------------------------------------------------

class TestModelSaveLoad:

    def test_save_and_load_roundtrip(self, pipeline, regression_df, tmp_path):
        """A saved model package should load back with identical contents."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )

        filepath = str(tmp_path / "test_model.joblib")
        pipeline.save_model_package(
            model=result["best_model"],
            preprocessor=result["preprocessor"],
            feature_list=result["feature_names"],
            target="target",
            problem_type=result["problem_type"],
            numeric_features=result["numeric_features"],
            categorical_features=result["categorical_features"],
            date_columns=[],
            metrics=result["evaluation"][result["best_model_name"]],
            feature_importance=result["feature_importance"],
            filepath=filepath,
        )

        assert os.path.isfile(filepath)

        loaded = MLPipeline.load_model_package(filepath)
        assert loaded["problem_type"] == "regression"
        assert loaded["target"] == "target"
        assert loaded["model"] is not None
        assert loaded["preprocessor"] is not None
        assert loaded["feature_list"] == result["feature_names"]

    def test_loaded_model_makes_predictions(self, pipeline, regression_df, tmp_path):
        """A model loaded from disk should be able to predict on new data."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )

        filepath = str(tmp_path / "test_predict_model.joblib")
        pipeline.save_model_package(
            model=result["best_model"],
            preprocessor=result["preprocessor"],
            feature_list=result["feature_names"],
            target="target",
            problem_type=result["problem_type"],
            numeric_features=result["numeric_features"],
            categorical_features=result["categorical_features"],
            date_columns=[],
            metrics=result["evaluation"][result["best_model_name"]],
            feature_importance=result["feature_importance"],
            filepath=filepath,
        )

        loaded = MLPipeline.load_model_package(filepath)
        model = loaded["model"]
        preprocessor = loaded["preprocessor"]

        # Create a single-row test sample
        test_df = regression_df[features].iloc[:1]
        X_test = preprocessor.transform(test_df)
        preds = model.predict(X_test)
        assert len(preds) == 1
        assert np.isfinite(preds[0])


# ---------------------------------------------------------------------------
# Tests: Feature importance
# ---------------------------------------------------------------------------

class TestFeatureImportance:

    def test_feature_importance_returns_dataframe(self, pipeline, regression_df):
        """get_feature_importance should return a DataFrame with Feature and Importance columns."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        fi = result["feature_importance"]
        assert isinstance(fi, pd.DataFrame)
        assert "Feature" in fi.columns
        assert "Importance" in fi.columns
        assert len(fi) > 0

    def test_feature_importance_sorted_descending(self, pipeline, regression_df):
        """Feature importances should be sorted in descending order."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        fi = result["feature_importance"]
        if len(fi) > 1:
            assert fi["Importance"].is_monotonic_decreasing

    def test_feature_importance_top_n_limit(self, pipeline, regression_df):
        """get_feature_importance should respect the top_n parameter."""
        features = ["measurement_a", "measurement_b", "category"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        fi = pipeline.get_feature_importance(
            model=result["best_model"],
            preprocessor=result["preprocessor"],
            feature_names=result["feature_names"],
            problem_type="regression",
            top_n=2,
        )
        assert len(fi) <= 2


# ---------------------------------------------------------------------------
# Tests: Target not included in features
# ---------------------------------------------------------------------------

class TestTargetExclusion:

    def test_target_not_in_feature_names(self, pipeline, regression_df):
        """The target column should not appear in the prepared feature names."""
        features = ["measurement_a", "measurement_b", "category", "target"]
        result = pipeline.run_full_pipeline(
            df=regression_df,
            target_column="target",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        for fname in result["feature_names"]:
            assert fname != "target", "Target column leaked into feature names"


# ---------------------------------------------------------------------------
# Tests: Leakage detection
# ---------------------------------------------------------------------------

class TestLeakageDetection:

    def test_leakage_column_excluded(self, pipeline):
        """A column whose name contains the target name should be excluded as a leakage risk."""
        np.random.seed(42)
        n = 200
        # Use rounded values to keep cardinality moderate
        df = pd.DataFrame({
            "age": np.random.randint(18, 65, n),
            "salary": np.round(np.random.uniform(30, 100, n), 1),
            "salary_predicted": np.round(np.random.uniform(30, 100, n), 1),  # leakage
        })
        features = ["age", "salary", "salary_predicted"]
        result = pipeline.run_full_pipeline(
            df=df,
            target_column="salary",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        # "salary_predicted" contains the target name "salary" → leakage risk
        for fname in result["feature_names"]:
            assert "salary_predicted" not in fname

    def test_leakage_warning_on_high_r2(self, pipeline):
        """If a regression model achieves R² > 0.99, a leakage_warning should appear."""
        np.random.seed(42)
        n = 200
        # Round to keep cardinality moderate (avoid identifier detection)
        x = np.round(np.random.randn(n) * 5, 1)
        y = x + np.random.randn(n) * 0.01  # near-perfect linear relationship
        y = np.round(y, 2)
        df = pd.DataFrame({"value_a": x, "value_b": y})
        features = ["value_a"]
        result = pipeline.run_full_pipeline(
            df=df,
            target_column="value_b",
            selected_features=features,
            exclude_features=[],
            problem_type="regression",
        )
        # At least one model should have a leakage warning
        has_warning = any(
            "leakage_warning" in metrics
            for metrics in result["evaluation"].values()
        )
        assert has_warning, "Expected leakage warning for near-perfect linear relationship"
