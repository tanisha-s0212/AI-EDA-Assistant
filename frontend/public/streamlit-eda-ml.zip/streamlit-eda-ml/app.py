"""
AI-Assisted EDA & ML Platform
=============================
A production-grade, dataset-agnostic Streamlit application for automated
Exploratory Data Analysis, cleaning, ML model training, and predictions.
"""

import os
import sys
import json
import base64
import tempfile
import streamlit as st
import pandas as pd
import numpy as np
from io import StringIO
from typing import Any

# Add project root to path for module imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
load_dotenv()

from modules.session_manager import (
    init_session_state, reset_dataset_state, reset_ml_state,
    get_state, set_state, has_state,
    DATASET_KEY, CLEANED_KEY, CLEANING_LOGS_KEY, CLEANING_SUMMARY_KEY,
    AI_STRATEGY_KEY, ML_PLAN_KEY, ML_RESULTS_KEY, SELECTED_FEATURES_KEY,
    UPLOADED_MODEL_KEY, PREDICTION_HISTORY_KEY, ACTIVE_DATASET_KEY,
    FILE_HASH_KEY, ORIGINAL_COLUMNS_KEY, ENGINEERED_COLUMNS_KEY,
)
from modules.file_loader import load_uploaded_file, prepare_dataset, get_file_hash, _try_merge_datasets
from modules.data_understanding import DataProfiler, generate_profile_summary
from modules.data_cleanser import DataCleanser
from modules.eda_engine import EDAEngine, generate_eda_narrative
from modules.ai_assistant import AIAssistant
from modules.ml_engine import MLPipeline
from modules.prediction_engine import PredictionEngine

# ─── Page Configuration ────────────────────────────────────────────────────

st.set_page_config(
    page_title="AI-Assisted EDA & ML Platform",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS — Adaptive for Light & Dark Mode ───────────────────────────

CUSTOM_CSS = """
<style>
    /* ═══════════════════════════════════════════════════════════════
       THEME VARIABLES — auto-switch between light and dark mode
       Streamlit injects [data-theme="light"] or [data-theme="dark"]
       on the <body> element.
       ═══════════════════════════════════════════════════════════════ */

    /* ── Global base overrides ── */
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 4rem;
    }
    h1, h2, h3 { color: var(--st-app-header-color) !important; }

    /* ── Sidebar ── */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0f0f1a 0%, #1a1a2e 100%) !important;
    }
    [data-testid="stSidebar"] * {
        color: #e2e2e2 !important;
    }
    [data-testid="stSidebar"] .stButton > button,
    [data-testid="stSidebar"] .stDownloadButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff !important;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        padding: 0.5rem 1rem;
        transition: all 0.3s ease;
    }
    [data-testid="stSidebar"] .stButton > button:hover,
    [data-testid="stSidebar"] .stDownloadButton > button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.5);
    }

    /* ── Metric Cards ── */
    .metric-card {
        background: var(--st-app-background-color, #ffffff);
        border-radius: 14px;
        padding: 1.25rem 1.5rem;
        border-left: 4px solid #667eea;
        box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    [data-theme="dark"] .metric-card {
        background: #1e1e2e;
        border-left-color: #667eea;
        box-shadow: 0 2px 12px rgba(0,0,0,0.3);
    }
    .metric-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.18);
    }
    .metric-card .metric-value {
        font-size: 1.85rem;
        font-weight: 800;
        color: var(--st-app-header-color, #1a1a2e);
        letter-spacing: -0.5px;
    }
    .metric-card .metric-label {
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        margin-bottom: 0.35rem;
        opacity: 0.6;
    }

    /* ── Status Badges ── */
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.375rem;
        padding: 0.3rem 0.85rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    .status-badge.success { background: #d4edda; color: #155724; }
    .status-badge.warning { background: #fff3cd; color: #856404; }
    .status-badge.error   { background: #f8d7da; color: #721c24; }
    .status-badge.info    { background: #d1ecf1; color: #0c5460; }
    [data-theme="dark"] .status-badge.success { background: #1a3a2a; color: #6ee7a0; }
    [data-theme="dark"] .status-badge.warning { background: #3a3520; color: #ffd666; }
    [data-theme="dark"] .status-badge.error   { background: #3a1a1a; color: #ff8a8a; }
    [data-theme="dark"] .status-badge.info    { background: #1a2a3a; color: #74c0fc; }

    /* ── Section Headers ── */
    .section-header {
        font-size: 1.4rem;
        font-weight: 800;
        padding-bottom: 0.75rem;
        border-bottom: 3px solid #667eea;
        margin-bottom: 1.25rem;
        color: var(--st-app-header-color, #1a1a2e);
    }

    /* ── Tab Styling ── */
    .stTabs [data-baseweb="tab-list"] {
        gap: 0.4rem;
        padding: 0.5rem;
        border-radius: 12px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 8px;
        font-weight: 600;
        padding: 0.5rem 1.25rem;
        transition: all 0.2s ease;
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        color: white !important;
    }

    /* ── Processing Log ── */
    .processing-log {
        background: #0d1117;
        color: #58a6ff;
        font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace;
        font-size: 0.72rem;
        padding: 0.85rem;
        border-radius: 10px;
        border: 1px solid #30363d;
        max-height: 260px;
        overflow-y: auto;
        line-height: 1.5;
    }
    .processing-log .log-entry {
        padding: 0.12rem 0;
        border-bottom: 1px solid rgba(255,255,255,0.04);
    }
    .processing-log .log-entry.success { color: #3fb950; }
    .processing-log .log-entry.warning { color: #d29922; }
    .processing-log .log-entry.error   { color: #f85149; }
    .processing-log .log-entry.info    { color: #58a6ff; }

    /* ── Prediction Result Card ── */
    .prediction-result {
        border-radius: 18px;
        padding: 2.5rem 2rem;
        text-align: center;
        border: 2px solid #667eea;
        background: linear-gradient(135deg, rgba(102,126,234,0.08) 0%, rgba(118,75,162,0.08) 100%);
    }
    [data-theme="dark"] .prediction-result {
        background: linear-gradient(135deg, rgba(102,126,234,0.15) 0%, rgba(118,75,162,0.15) 100%);
    }
    .prediction-result .prediction-value {
        font-size: 3.25rem;
        font-weight: 900;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .prediction-result .prediction-sub {
        font-size: 0.9rem;
        opacity: 0.6;
        margin-top: 0.5rem;
        color: var(--st-app-text-color, #6c757d);
    }

    /* ── Chart Container ── */
    .chart-container {
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        padding: 0.5rem;
        background: var(--st-app-background-color, #fff);
    }
    [data-theme="dark"] .chart-container {
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }
    .chart-container img { border-radius: 8px; width: 100%; }

    /* ── AI Response Box ── */
    .ai-response {
        border-left: 4px solid #667eea;
        border-radius: 0 12px 12px 0;
        padding: 1.1rem 1.35rem;
        margin: 0.75rem 0;
        font-size: 0.95rem;
        line-height: 1.7;
        background: linear-gradient(135deg, rgba(102,126,234,0.06) 0%, rgba(236,72,153,0.04) 100%);
        color: var(--st-app-text-color, #333);
    }
    [data-theme="dark"] .ai-response {
        background: linear-gradient(135deg, rgba(102,126,234,0.12) 0%, rgba(236,72,153,0.08) 100%);
        color: #e0e0e0;
    }

    /* ── Welcome Page Cards ── */
    .welcome-card {
        background: var(--st-app-background-color, #f8f9fa);
        border: 1px solid var(--st-app-border-color, #e0e0e0);
        padding: 1.75rem 1.25rem;
        border-radius: 14px;
        width: 190px;
        text-align: center;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }
    .welcome-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(102,126,234,0.15);
    }
    .welcome-card .wc-icon { font-size: 2.25rem; margin-bottom: 0.6rem; }
    .welcome-card .wc-title {
        font-weight: 700; font-size: 0.95rem;
        color: var(--st-app-header-color, #1a1a2e);
    }
    .welcome-card .wc-desc {
        font-size: 0.8rem; margin-top: 0.3rem;
        color: var(--st-app-text-color, #6c757d); opacity: 0.75;
    }

    /* ── Hide defaults ── */
    #MainMenu { visibility: hidden; }
    footer { visibility: hidden; }
</style>
"""

st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# ─── Helper Functions ──────────────────────────────────────────────────────

def render_metric_card(label: str, value: str, css_class: str = "metric-card") -> str:
    """Render a styled metric card."""
    return f"""
    <div class="{css_class}">
        <div class="metric-label">{label}</div>
        <div class="metric-value">{value}</div>
    </div>
    """


def render_status_badge(text: str, status: str) -> str:
    """Render a status badge."""
    return f'<span class="status-badge {status}">● {text}</span>'


def render_processing_log(logs: list[str]) -> str:
    """Render processing log entries."""
    if not logs:
        return '<div class="processing-log"><div class="log-entry info">No processing logs yet.</div></div>'
    entries = ""
    for log in logs[-50:]:
        cls = "info"
        if "✓" in log or "success" in log.lower() or "completed" in log.lower():
            cls = "success"
        elif "⚠" in log or "warning" in log.lower():
            cls = "warning"
        elif "✗" in log or "error" in log.lower() or "failed" in log.lower():
            cls = "error"
        entries += f'<div class="log-entry {cls}">{log}</div>'
    return f'<div class="processing-log">{entries}</div>'


def display_base64_image(image_b64: str, caption: str = "") -> None:
    """Display a base64-encoded image in Streamlit."""
    img_html = f'<div class="chart-container"><img src="data:image/png;base64,{image_b64}" width="100%">'
    if caption:
        img_html += f'<p style="text-align:center; font-size:0.85rem; opacity:0.65; margin-top:0.5rem;">{caption}</p>'
    img_html += '</div>'
    st.markdown(img_html, unsafe_allow_html=True)


def safe_display_df(df: Any, max_rows: int = 100) -> None:
    """Safely display a DataFrame or Styler with row limit."""
    if df is None:
        st.info("No data to display.")
        return
    # Styler objects (from .style.format()) don't have .empty
    is_styler = hasattr(df, '_repr_html_') and not hasattr(df, 'empty')
    if is_styler:
        st.dataframe(df, use_container_width=True, hide_index=True)
        return
    # Regular DataFrame
    if df.empty:
        st.info("No data to display.")
        return
    if len(df) > max_rows:
        st.dataframe(df.head(max_rows), use_container_width=True, hide_index=True)
        st.caption(f"Showing {max_rows} of {len(df):,} rows")
    else:
        st.dataframe(df, use_container_width=True, hide_index=True)


def add_log(message: str, status: str = "info") -> None:
    """Add a log entry to session state processing log."""
    logs = get_state("processing_log") or []
    prefix = {"info": "ℹ️", "success": "✓", "warning": "⚠", "error": "✗"}.get(status, "•")
    logs.append(f"{prefix} {message}")
    if len(logs) > 200:
        logs = logs[-200:]
    set_state("processing_log", logs)


# ─── Initialize Session ───────────────────────────────────────────────────

init_session_state()
if not has_state("processing_log"):
    set_state("processing_log", [])
if not has_state("ai_assistant"):
    set_state("ai_assistant", AIAssistant())

# ─── Sidebar ───────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("""
    <div style="text-align:center; padding: 1.25rem 0 1.75rem 0;">
        <div style="font-size: 2.8rem; margin-bottom: 0.3rem;">📊</div>
        <div style="font-size: 1.15rem; font-weight: 800; color: #667eea; letter-spacing: -0.5px;">
            EDA & ML Platform
        </div>
        <div style="font-size: 0.75rem; color: #8888aa; margin-top: 0.35rem; text-transform: uppercase; letter-spacing: 1.5px;">
            AI-Assisted Data Intelligence
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.divider()

    st.markdown("**📂 Upload Dataset**")
    uploaded_file = st.file_uploader(
        "CSV, Excel, Parquet, or ZIP",
        type=["csv", "xlsx", "xls", "parquet", "zip"],
        help="Upload a tabular file. ZIP may contain multiple files.",
        key="file_uploader",
    )

    datasets_dict = get_state("datasets_dict")
    if datasets_dict and len(datasets_dict) > 1:
        st.markdown("**🗂️ Switch Dataset**")
        dataset_names = list(datasets_dict.keys())
        current_active = get_state(ACTIVE_DATASET_KEY) or dataset_names[0]
        selected_name = st.selectbox("Select dataset", dataset_names, index=dataset_names.index(current_active) if current_active in dataset_names else 0)
        if selected_name != current_active:
            set_state(ACTIVE_DATASET_KEY, selected_name)
            set_state(DATASET_KEY, datasets_dict[selected_name])
            reset_ml_state()
            add_log(f"Switched to dataset: {selected_name}")
            st.rerun()

    st.divider()

    with st.expander("📋 Processing Log", expanded=False):
        logs = get_state("processing_log") or []
        if logs:
            st.markdown(render_processing_log(logs), unsafe_allow_html=True)
            if st.button("Clear Log", use_container_width=True):
                set_state("processing_log", [])
                st.rerun()
        else:
            st.caption("No processing logs yet.")

    st.divider()

    ai: AIAssistant = get_state("ai_assistant")
    provider_status = ai.get_provider_status()
    st.markdown("**🤖 AI Provider Status**")
    if provider_status["longcat_configured"]:
        st.markdown(render_status_badge("LongCat", "success"), unsafe_allow_html=True)
    else:
        st.markdown(render_status_badge("LongCat — not configured", "warning"), unsafe_allow_html=True)
    if provider_status["groq_configured"]:
        st.markdown(render_status_badge("Groq", "success"), unsafe_allow_html=True)
    else:
        st.markdown(render_status_badge("Groq — not configured", "warning"), unsafe_allow_html=True)

    if not ai.is_available():
        st.warning("No AI provider configured. Set `GROQ_API_KEY` or `LONGCAT_API_KEY` in `.env`.")
        with st.expander("Setup Instructions"):
            st.code("""# .env file
GROQ_API_KEY=gsk_your_key_here
# or
LONGCAT_API_KEY=your_key_here
LONGCAT_MODEL=LongCat-Flash-Chat""", language="bash")

    if has_state(CLEANED_KEY):
        cleaned_df = get_state(CLEANED_KEY)
        if cleaned_df is not None:
            st.divider()
            st.markdown("**💾 Downloads**")
            col1, col2 = st.columns(2)
            with col1:
                csv_buffer = StringIO()
                cleaned_df.to_csv(csv_buffer, index=False)
                st.download_button("📥 CSV", csv_buffer.getvalue(), "cleaned_data.csv", "text/csv", use_container_width=True)
            with col2:
                parquet_buffer = tempfile.NamedTemporaryFile(suffix=".parquet", delete=False)
                cleaned_df.to_parquet(parquet_buffer.name, index=False)
                with open(parquet_buffer.name, "rb") as f:
                    parquet_bytes = f.read()
                os.unlink(parquet_buffer.name)
                st.download_button("📥 Parquet", parquet_bytes, "cleaned_data.parquet", "application/octet-stream", use_container_width=True)

    if has_state(ML_RESULTS_KEY):
        ml_results = get_state(ML_RESULTS_KEY)
        if ml_results and "model_package_path" in ml_results:
            try:
                import joblib
                with open(ml_results["model_package_path"], "rb") as f:
                    model_bytes = f.read()
                st.download_button("📦 Download Model", model_bytes, "model_package.pkl", "application/octet-stream", use_container_width=True)
            except Exception:
                pass

# ─── Handle File Upload ────────────────────────────────────────────────────

if uploaded_file is not None:
    try:
        new_hash = get_file_hash(uploaded_file)
        current_hash = get_state(FILE_HASH_KEY)

        if new_hash != current_hash:
            add_log(f"New file detected: {uploaded_file.name} ({len(uploaded_file.getvalue()):,} bytes)", "info")
            reset_dataset_state(exclude_keys=["processing_log", "ai_assistant"])
            set_state("processing_log", get_state("processing_log") or [])

            try:
                datasets = load_uploaded_file(uploaded_file)
                add_log(f"Loaded {len(datasets)} dataset(s) from {uploaded_file.name}", "success")

                if len(datasets) == 1:
                    name, raw_df = list(datasets.items())[0]
                    prepared_df, original_cols = prepare_dataset(raw_df, name)
                    set_state(DATASET_KEY, prepared_df)
                    set_state(ORIGINAL_COLUMNS_KEY, original_cols)
                    set_state(ENGINEERED_COLUMNS_KEY, [])
                    set_state(ACTIVE_DATASET_KEY, name)
                    add_log(f"Dataset '{name}': {prepared_df.shape[0]:,} rows × {prepared_df.shape[1]} columns", "success")
                else:
                    set_state("datasets_dict", datasets)
                    first_name = list(datasets.keys())[0]
                    prepared_df, original_cols = prepare_dataset(datasets[first_name], first_name)
                    set_state(DATASET_KEY, prepared_df)
                    set_state(ORIGINAL_COLUMNS_KEY, original_cols)
                    set_state(ENGINEERED_COLUMNS_KEY, [])
                    set_state(ACTIVE_DATASET_KEY, first_name)
                    add_log(f"ZIP archive: {len(datasets)} datasets found. Showing '{first_name}'.", "info")

                set_state(FILE_HASH_KEY, new_hash)

            except Exception as e:
                add_log(f"File load error: {str(e)}", "error")
                st.error(f"Failed to load file: {e}")

    except Exception as e:
        st.error(f"File processing error: {e}")

# ─── Main Content ──────────────────────────────────────────────────────────

df = get_state(DATASET_KEY)

if df is None:
    st.markdown("""
    <div style="text-align: center; padding: 4rem 2rem 2rem;">
        <div style="font-size: 4.5rem; margin-bottom: 1rem;">📊</div>
        <h1 style="font-size: 2.6rem; font-weight: 900; margin-bottom: 0.5rem;">
            AI-Assisted EDA & ML Platform
        </h1>
        <p style="font-size: 1.1rem; max-width: 580px; margin: 0 auto 2.5rem auto; line-height: 1.7; opacity: 0.7;">
            Upload any tabular dataset to automatically explore, clean, analyze,
            build ML models, and make predictions — all without writing code.
        </p>
        <div style="display: flex; justify-content: center; gap: 1.5rem; flex-wrap: wrap;">
            <div class="welcome-card">
                <div class="wc-icon">📂</div>
                <div class="wc-title">Universal Ingestion</div>
                <div class="wc-desc">CSV, Excel, Parquet, ZIP</div>
            </div>
            <div class="welcome-card">
                <div class="wc-icon">🧹</div>
                <div class="wc-title">Smart Cleaning</div>
                <div class="wc-desc">Heuristic-driven, safe</div>
            </div>
            <div class="welcome-card">
                <div class="wc-icon">📈</div>
                <div class="wc-title">EDA & ML</div>
                <div class="wc-desc">AI-assisted workflow</div>
            </div>
            <div class="welcome-card">
                <div class="wc-icon">🎯</div>
                <div class="wc-title">Predictions</div>
                <div class="wc-desc">Save, load, deploy</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

else:
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🔍 Data Understanding",
        "🧹 Cleaning & Preprocessing",
        "📊 EDA",
        "🤖 ML Assistant",
        "🎯 Prediction",
    ])

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 1: Data Understanding
    # ═══════════════════════════════════════════════════════════════════════
    with tab1:
        st.markdown('<div class="section-header">🔍 Data Understanding</div>', unsafe_allow_html=True)

        profile = DataProfiler(df)
        full_profile = profile.get_full_profile()
        summary_text = generate_profile_summary(full_profile)

        rows, cols = profile.get_shape()
        mem_info = profile.get_memory_usage()
        dup_count = profile.get_duplicate_count()

        metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)
        with metric_col1:
            st.markdown(render_metric_card("Total Rows", f"{rows:,}"), unsafe_allow_html=True)
        with metric_col2:
            st.markdown(render_metric_card("Total Columns", f"{cols}"), unsafe_allow_html=True)
        with metric_col3:
            st.markdown(render_metric_card("Memory Usage", mem_info["total_formatted"]), unsafe_allow_html=True)
        with metric_col4:
            dup_color = "error" if dup_count > 0 else "metric-card"
            st.markdown(render_metric_card("Duplicate Rows", f"{dup_count:,}", dup_color), unsafe_allow_html=True)

        st.markdown("---")

        roles = full_profile.get("column_roles", {})
        role_dist = full_profile.get("role_distribution", {})
        if role_dist:
            st.markdown("**Column Role Distribution**")
            role_cols = st.columns(len(role_dist))
            for idx, (role, count) in enumerate(sorted(role_dist.items())):
                with role_cols[idx]:
                    cols_list = [c for c, r in roles.items() if r == role]
                    with st.expander(f"{role.capitalize()} ({count})"):
                        st.write(", ".join(cols_list[:20]))
                        if len(cols_list) > 20:
                            st.caption(f"...and {len(cols_list) - 20} more")

        st.markdown("---")

        missing_df = profile.get_missing_summary()
        if missing_df is not None and not missing_df.empty:
            st.markdown(f"**Missing Values** {render_status_badge(f'{len(missing_df)} columns affected', 'warning')}", unsafe_allow_html=True)
            safe_display_df(missing_df, max_rows=50)
        else:
            st.markdown(render_status_badge("No Missing Values", "success"), unsafe_allow_html=True)

        st.markdown("---")

        st.markdown("**Column Types**")
        dtype_df = profile.get_dtype_summary()
        safe_display_df(dtype_df, max_rows=50)

        st.markdown("---")

        with st.expander("📋 DataFrame Info"):
            st.code(profile.get_info_capture(), language="text")

        if ai.is_available():
            with st.expander("🤖 AI-Generated Data Explanation"):
                if st.button("Generate AI Summary", key="btn_ai_summary"):
                    with st.spinner("AI is analyzing your dataset..."):
                        try:
                            ai_summary, provider = ai.generate_data_summary(
                                summary_text,
                                json.dumps(roles, default=str),
                                dtype_df.head(20).to_string(),
                            )
                            set_state("ai_data_summary", ai_summary)
                            add_log(f"AI data summary generated via {provider}", "success")
                        except Exception as e:
                            add_log(f"AI summary error: {e}", "error")
                cached_summary = get_state("ai_data_summary")
                if cached_summary:
                    st.markdown(f'<div class="ai-response">{cached_summary}</div>', unsafe_allow_html=True)

            with st.expander("🤖 AI Cleaning Recommendations"):
                if st.button("Get Cleaning Suggestions", key="btn_ai_cleaning"):
                    with st.spinner("AI is generating cleaning recommendations..."):
                        try:
                            missing_str = missing_df.to_string() if missing_df is not None and not missing_df.empty else "No missing values"
                            recs, provider = ai.generate_cleaning_recommendations(summary_text, missing_str, roles)
                            set_state("ai_cleaning_recs", recs)
                            add_log(f"AI cleaning recommendations generated via {provider}", "success")
                        except Exception as e:
                            add_log(f"AI cleaning recs error: {e}", "error")
                cached_recs = get_state("ai_cleaning_recs")
                if cached_recs:
                    st.markdown(f'<div class="ai-response">{cached_recs}</div>', unsafe_allow_html=True)

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 2: Cleaning & Preprocessing
    # ═══════════════════════════════════════════════════════════════════════
    with tab2:
        st.markdown('<div class="section-header">🧹 Cleaning & Preprocessing</div>', unsafe_allow_html=True)

        st.markdown("**Configure Cleaning Steps**")
        opt_col1, opt_col2 = st.columns(2)
        with opt_col1:
            opt_remove_dups = st.checkbox("Remove Duplicate Rows", value=True)
            opt_remove_summary = st.checkbox("Remove Summary Rows (Total, Subtotal, etc.)", value=True)
            opt_impute_num = st.checkbox("Impute Missing Numeric Values (median)", value=True)
            opt_impute_cat = st.checkbox("Impute Missing Categorical Values (mode)", value=True)
        with opt_col2:
            opt_convert_cat = st.checkbox("Convert to Category dtype", value=True)
            opt_downcast = st.checkbox("Downcast Numeric Types", value=True)
            opt_parse_dates = st.checkbox("Parse Date Columns", value=True)

        if st.button("🚀 Run Cleaning Pipeline", type="primary", use_container_width=True):
            with st.spinner("Cleaning dataset..."):
                try:
                    cleanser = DataCleanser(df)
                    cleaned = cleanser.clean(
                        remove_duplicates=opt_remove_dups,
                        remove_summary_rows=opt_remove_summary,
                        impute_numeric=opt_impute_num,
                        impute_categorical=opt_impute_cat,
                        convert_categories=opt_convert_cat,
                        downcast_numeric=opt_downcast,
                        parse_dates=opt_parse_dates,
                    )
                    set_state(CLEANED_KEY, cleaned)
                    set_state(CLEANING_LOGS_KEY, cleanser.get_logs())
                    set_state(CLEANING_SUMMARY_KEY, cleanser.get_summary())
                    reset_ml_state()
                    add_log("Cleaning pipeline completed", "success")
                    st.success("Cleaning completed!")
                    st.rerun()
                except Exception as e:
                    add_log(f"Cleaning error: {e}", "error")
                    st.error(f"Cleaning failed: {e}")

        cleaning_summary = get_state(CLEANING_SUMMARY_KEY)
        cleaning_logs = get_state(CLEANING_LOGS_KEY)

        if cleaning_summary:
            st.markdown("---")
            st.markdown("**Cleaning Summary**")
            s = cleaning_summary
            mc1, mc2, mc3, mc4 = st.columns(4)
            with mc1:
                st.markdown(render_metric_card("Rows Before", f"{s.get('rows_before', 0):,}"), unsafe_allow_html=True)
            with mc2:
                st.markdown(render_metric_card("Rows After", f"{s.get('rows_after', 0):,}"), unsafe_allow_html=True)
            with mc3:
                removed = s.get('rows_before', 0) - s.get('rows_after', 0)
                st.markdown(render_metric_card("Rows Removed", f"{removed:,}"), unsafe_allow_html=True)
            with mc4:
                mem_saved = s.get('memory_before_mb', 0) - s.get('memory_after_mb', 0)
                st.markdown(render_metric_card("Memory Saved", f"{mem_saved:.1f} MB"), unsafe_allow_html=True)

            if cleaning_logs:
                with st.expander("📋 Cleaning Log"):
                    for log_entry in cleaning_logs:
                        st.caption(log_entry)

        cleaned_df = get_state(CLEANED_KEY)
        if cleaned_df is not None:
            st.markdown("---")
            st.markdown("**Cleaned Dataset Preview**")
            safe_display_df(cleaned_df, max_rows=100)

            original_cols = get_state(ORIGINAL_COLUMNS_KEY) or []
            current_cols = list(cleaned_df.columns)
            new_cols = [c for c in current_cols if c not in original_cols]
            if new_cols:
                set_state(ENGINEERED_COLUMNS_KEY, new_cols)
                with st.expander("🔧 Engineered Columns (auto-generated during cleaning)"):
                    st.write(new_cols)

            # AI: Explain cleaning results
            if ai.is_available():
                with st.expander("🤖 AI: What Did Cleaning Do & Why?"):
                    if st.button("Explain Cleaning Results", key="btn_explain_cleaning"):
                        with st.spinner("AI is analyzing cleaning results..."):
                            try:
                                explanation = ai.explain_cleaning_results(
                                    cleaning_summary=cleaning_summary,
                                    cleaning_logs=cleaning_logs or [],
                                    original_shape=(df.shape[0], df.shape[1]),
                                    cleaned_shape=(cleaned_df.shape[0], cleaned_df.shape[1]),
                                )
                                set_state("ai_cleaning_explanation", explanation)
                                add_log("AI cleaning explanation generated", "success")
                            except Exception as e:
                                add_log(f"AI cleaning explain error: {e}", "error")
                    cached = get_state("ai_cleaning_explanation")
                    if cached:
                        st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

            # AI: Dataset quality score
            if ai.is_available():
                with st.expander("🤖 AI: Overall Dataset Quality Score"):
                    if st.button("Assess Dataset Quality", key="btn_quality_score"):
                        with st.spinner("AI is assessing dataset quality..."):
                            try:
                                quality = ai.explain_dataset_quality(
                                    profile_summary=generate_profile_summary(full_profile),
                                    missing_summary=missing_df.to_string() if missing_df is not None and not missing_df.empty else "No missing values",
                                    duplicate_count=dup_count,
                                    id_cols=profiler.get_identifier_columns(),
                                    date_cols=profiler.get_date_columns(),
                                )
                                set_state("ai_quality_score", quality)
                                add_log("AI quality assessment generated", "success")
                            except Exception as e:
                                add_log(f"AI quality error: {e}", "error")
                    cached = get_state("ai_quality_score")
                    if cached:
                        st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

            # AI: User guide
            if ai.is_available():
                with st.expander("🤖 AI: What Should I Do Next?"):
                    if st.button("Get Step-by-Step Guide", key="btn_user_guide"):
                        with st.spinner("AI is generating your personalized guide..."):
                            try:
                                guide = ai.generate_user_guide(
                                    dataset_shape=(len(cleaned_df), len(cleaned_df.columns)),
                                    columns=list(cleaned_df.columns),
                                    column_roles=roles,
                                    problem_type="regression",
                                    target_column="",
                                )
                                set_state("ai_user_guide", guide)
                                add_log("AI user guide generated", "success")
                            except Exception as e:
                                add_log(f"AI guide error: {e}", "error")
                    cached = get_state("ai_user_guide")
                    if cached:
                        st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

        else:
            st.info("Run the cleaning pipeline to see results here.")

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 3: EDA
    # ═══════════════════════════════════════════════════════════════════════
    with tab3:
        st.markdown('<div class="section-header">📊 Exploratory Data Analysis</div>', unsafe_allow_html=True)

        eda_df = get_state(CLEANED_KEY) or df
        profiler = DataProfiler(eda_df)
        id_cols = profiler.get_identifier_columns()
        eda = EDAEngine(eda_df, identifier_columns=id_cols)

        st.markdown("**Numeric Feature Statistics**")
        numeric_stats = eda.get_numeric_stats()
        if numeric_stats is not None and not numeric_stats.empty:
            safe_display_df(numeric_stats.style.format(precision=3), max_rows=50)
        else:
            st.info("No numeric features found for statistical analysis.")

        dist_plots = eda.plot_distributions(max_cols=6)
        if dist_plots:
            st.markdown("---")
            st.markdown("**Distribution Plots**")
            plot_cols = st.columns(min(2, len(dist_plots)))
            for idx, plot_info in enumerate(dist_plots):
                with plot_cols[idx % len(plot_cols)]:
                    display_base64_image(plot_info["image_base64"], f"Distribution: {plot_info['column']}")
        else:
            st.info("No numeric distributions to display.")

        box_plots = eda.plot_boxplots(max_cols=6)
        if box_plots:
            st.markdown("---")
            st.markdown("**Box Plots (Outlier Detection)**")
            plot_cols = st.columns(min(2, len(box_plots)))
            for idx, plot_info in enumerate(box_plots):
                with plot_cols[idx % len(plot_cols)]:
                    display_base64_image(plot_info["image_base64"], f"Box Plot: {plot_info['column']}")

        cat_plots = eda.plot_categorical_distributions(max_cols=4, max_categories=10)
        if cat_plots:
            st.markdown("---")
            st.markdown("**Categorical Feature Distributions**")
            plot_cols = st.columns(min(2, len(cat_plots)))
            for idx, plot_info in enumerate(cat_plots):
                with plot_cols[idx % len(plot_cols)]:
                    display_base64_image(plot_info["image_base64"], f"Categorical: {plot_info['column']}")

        heatmap = eda.plot_correlation_heatmap(max_features=15)
        if heatmap:
            st.markdown("---")
            st.markdown("**Correlation Heatmap**")
            display_base64_image(heatmap["image_base64"], "Feature Correlation Matrix")

        corr_matrix = eda.get_correlation_matrix(max_features=20)
        if corr_matrix is not None:
            with st.expander("📊 Correlation Matrix (table)"):
                safe_display_df(corr_matrix.style.background_gradient(cmap="RdBu_r", axis=None, vmin=-1, vmax=1).format(precision=2), max_rows=30)

        if ai.is_available():
            st.markdown("---")

            # AI: Per-chart explanations
            numeric_cols_filtered = eda._filter_numeric_columns()
            if numeric_cols_filtered or cat_plots:
                with st.expander("🤖 AI: Explain Individual Charts"):
                    chart_to_explain = st.selectbox(
                        "Select a chart to explain",
                        [""] + numeric_cols_filtered[:12] + ([f"cat: {p['column']}" for p in (cat_plots or [])]),
                        key="chart_explain_select",
                    )
                    if chart_to_explain:
                        if st.button("Explain This Chart", key="btn_explain_chart"):
                            with st.spinner("AI is analyzing the chart..."):
                                try:
                                    is_cat = chart_to_explain.startswith("cat:")
                                    actual_col = chart_to_explain.replace("cat: ", "") if is_cat else chart_to_explain
                                    col_stats = {}
                                    if numeric_stats is not None and actual_col in numeric_stats.index:
                                        col_stats = numeric_stats.loc[actual_col].to_dict()
                                    explanation = ai.explain_chart(
                                        chart_type="categorical_bar" if is_cat else "distribution",
                                        column_name=actual_col,
                                        stats=col_stats,
                                        dataset_shape=(len(eda_df), len(eda_df.columns)),
                                    )
                                    set_state("ai_chart_explanation", explanation)
                                    add_log(f"AI chart explanation for {actual_col} generated", "success")
                                except Exception as e:
                                    add_log(f"AI chart explain error: {e}", "error")
                        cached = get_state("ai_chart_explanation")
                        if cached:
                            st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

            # AI: Correlation insights
            if corr_matrix is not None and not corr_matrix.empty:
                with st.expander("🤖 AI: Explain Correlation Patterns"):
                    if st.button("Analyze Correlations", key="btn_explain_corr"):
                        with st.spinner("AI is analyzing correlations..."):
                            try:
                                corr_explanation = ai.explain_correlations(
                                    correlation_matrix_str=corr_matrix.head(15).to_string(),
                                    dataset_shape=(len(eda_df), len(eda_df.columns)),
                                    top_features=list(corr_matrix.columns[:15]),
                                )
                                set_state("ai_corr_explanation", corr_explanation)
                                add_log("AI correlation explanation generated", "success")
                            except Exception as e:
                                add_log(f"AI corr explain error: {e}", "error")
                    cached = get_state("ai_corr_explanation")
                    if cached:
                        st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

            # AI: Overall EDA Narrative
            with st.expander("🤖 AI: Overall EDA Summary"):
                if st.button("Generate AI EDA Summary", key="btn_ai_eda"):
                    with st.spinner("AI is analyzing EDA patterns..."):
                        try:
                            missing_df_tab3 = profiler.get_missing_summary()
                            narrative = generate_eda_narrative(numeric_stats, corr_matrix, missing_df_tab3, len(eda_df))
                            ai_enhanced, provider = ai.chat(
                                system_prompt="You are a data science expert. Enhance the following EDA summary with additional insights. Keep it concise and actionable. Do not use markdown headers.",
                                user_prompt=f"Dataset has {len(eda_df)} rows, {len(eda_df.columns)} columns.\n\n{narrative}"
                            )
                            set_state("ai_eda_narrative", ai_enhanced)
                            add_log(f"AI EDA narrative generated via {provider}", "success")
                        except Exception as e:
                            add_log(f"AI EDA error: {e}", "error")
                            set_state("ai_eda_narrative", narrative)
                cached_narrative = get_state("ai_eda_narrative")
                if cached_narrative:
                    st.markdown(f'<div class="ai-response">{cached_narrative}</div>', unsafe_allow_html=True)

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 4: ML Assistant
    # ═══════════════════════════════════════════════════════════════════════
    with tab4:
        st.markdown('<div class="section-header">🤖 ML Assistant</div>', unsafe_allow_html=True)

        ml_df = get_state(CLEANED_KEY) or df
        if ml_df is None or ml_df.empty:
            st.warning("Upload and prepare a dataset first.")
            st.stop()

        st.markdown("**Step 1: Define Your Objective**")
        objective = st.text_input(
            "What do you want to predict or analyze?",
            placeholder="e.g., Predict house prices based on features, Classify customer churn risk...",
            key="ml_objective",
        )

        cols_info = ml_df.dtypes.to_string()
        sample_data = ml_df.head(5).to_string()

        if objective:
            if ai.is_available():
                if st.button("🤖 Get AI-Recommended Strategy", type="primary", use_container_width=True):
                    with st.spinner("AI is analyzing your dataset and objective..."):
                        try:
                            strategy_json, provider = ai.suggest_ml_strategy(
                                objective=objective,
                                columns_info=cols_info,
                                dtypes_info=cols_info,
                                sample_data=sample_data,
                            )
                            set_state(AI_STRATEGY_KEY, strategy_json)
                            add_log(f"AI ML strategy generated via {provider}", "success")
                        except Exception as e:
                            add_log(f"AI strategy error: {e}", "error")
                            st.error(f"AI strategy failed: {e}")

            ai_strategy = get_state(AI_STRATEGY_KEY)
            if ai_strategy and isinstance(ai_strategy, dict):
                st.markdown("---")
                st.markdown(f'<div class="ai-response"><strong>AI Strategy:</strong> {ai_strategy.get("reasoning", "")}</div>', unsafe_allow_html=True)
                ai_target = ai_strategy.get("target_column")
                ai_problem_type = ai_strategy.get("problem_type", "regression")
                ai_recommended = ai_strategy.get("recommended_features", [])
                ai_excluded = ai_strategy.get("not_recommended_features", [])
            else:
                ai_target = None
                ai_problem_type = "regression"
                ai_recommended = []
                ai_excluded = []

            st.markdown("---")
            st.markdown("**Step 2: Configure Target & Features**")

            profiler_ml = DataProfiler(ml_df)
            id_cols_ml = profiler_ml.get_identifier_columns()
            from modules.utils import is_leakage_risk

            all_columns = list(ml_df.columns)
            excluded_by_rules = set(id_cols_ml)
            for col in all_columns:
                if ai_target and is_leakage_risk(col, ai_target):
                    excluded_by_rules.add(col)
            for col in ai_excluded:
                excluded_by_rules.add(col)
            if ai_target and ai_target in all_columns:
                excluded_by_rules.add(ai_target)

            valid_features = [c for c in all_columns if c not in excluded_by_rules]

            col1, col2 = st.columns(2)
            with col1:
                target_column = st.selectbox(
                    "🎯 Target Column",
                    all_columns,
                    index=all_columns.index(ai_target) if ai_target and ai_target in all_columns else 0,
                    help="The variable you want to predict.",
                )
            with col2:
                problem_type = st.selectbox(
                    "📐 Problem Type",
                    ["regression", "classification"],
                    index=0 if ai_problem_type == "regression" else 1,
                    help="Regression for continuous targets, classification for categories.",
                )

            st.markdown("**Feature Selection**")
            default_selected = list(set(ai_recommended) & set(valid_features))
            if not default_selected:
                default_selected = valid_features[:min(10, len(valid_features))]

            selected_features = st.multiselect(
                "Select Features for Training",
                valid_features,
                default=default_selected,
                help="Choose which features to include. Excluded: identifiers, leakage risks, target.",
            )

            if excluded_by_rules:
                with st.expander(f"⚠️ Excluded Features ({len(excluded_by_rules)})"):
                    for col in sorted(excluded_by_rules):
                        reason = []
                        if col in id_cols_ml:
                            reason.append("identifier")
                        if ai_target and is_leakage_risk(col, ai_target):
                            reason.append("leakage risk")
                        if col == target_column:
                            reason.append("is target")
                        if col in ai_excluded:
                            reason.append("AI-recommended exclusion")
                        st.markdown(f"`{col}` — {', '.join(reason)}")

                    # AI: Explain why features were excluded
                    if ai.is_available():
                        if st.button("🤖 Ask AI: Were Any Exclusions Wrong?", key="btn_explain_excluded"):
                            with st.spinner("AI is analyzing exclusions..."):
                                try:
                                    exclusion_reasons = {}
                                    for col in sorted(excluded_by_rules):
                                        reasons = []
                                        if col in id_cols_ml:
                                            reasons.append("identifier")
                                        if ai_target and is_leakage_risk(col, ai_target):
                                            reasons.append("leakage risk")
                                        if col == target_column:
                                            reasons.append("is target")
                                        if col in ai_excluded:
                                            reasons.append("AI-recommended exclusion")
                                        exclusion_reasons[col] = ", ".join(reasons)
                                    excluded_explanation = ai.explain_excluded_features(
                                        excluded_features=list(excluded_by_rules),
                                        exclusion_reasons=exclusion_reasons,
                                        target_column=target_column,
                                        all_columns=all_columns,
                                    )
                                    set_state("ai_excluded_explanation", excluded_explanation)
                                    add_log("AI excluded features explanation generated", "success")
                                except Exception as e:
                                    add_log(f"AI excluded explain error: {e}", "error")
                        cached = get_state("ai_excluded_explanation")
                        if cached:
                            st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

            st.markdown("---")
            st.markdown("**Step 3: Train Models**")

            if not selected_features:
                st.warning("Select at least one feature to train models.")
            elif target_column not in ml_df.columns:
                st.error(f"Target column '{target_column}' not found in dataset.")
            else:
                target_series = ml_df[target_column]
                unique_targets = target_series.nunique()
                total_rows = len(ml_df)
                missing_target = target_series.isnull().sum()

                warnings_list = []
                if missing_target > 0:
                    warnings_list.append(f"Target has {missing_target} missing values ({missing_target/total_rows*100:.1f}%)")
                if unique_targets == 1:
                    warnings_list.append("Target has only 1 unique value — not suitable for ML")
                if total_rows < 20:
                    warnings_list.append(f"Very few rows ({total_rows}) — models may be unreliable")
                if total_rows < len(selected_features) * 3:
                    warnings_list.append("More features than rows/3 — risk of overfitting")
                if problem_type == "classification" and unique_targets < 2:
                    warnings_list.append("Classification requires at least 2 classes")

                if warnings_list:
                    for w in warnings_list:
                        st.warning(w)

                can_train = "only 1 unique value" not in " ".join(warnings_list)

                train_col1, train_col2 = st.columns(2)
                with train_col1:
                    train_btn = st.button("🚀 Train Models", type="primary", use_container_width=True, disabled=not can_train)
                with train_col2:
                    st.checkbox("Enable Backtest (walk-forward if date column exists)")

                if train_btn and can_train:
                    with st.spinner("Training models..."):
                        try:
                            add_log(f"Starting ML pipeline: target={target_column}, type={problem_type}, features={len(selected_features)}", "info")

                            pipeline = MLPipeline(problem_type=problem_type, random_state=42)
                            profiler_train = DataProfiler(ml_df)
                            date_cols = profiler_train.get_date_columns()
                            feature_date_cols = [c for c in date_cols if c in selected_features]
                            non_feature_date_cols = [c for c in date_cols if c not in selected_features and c != target_column]
                            has_date_split = len(non_feature_date_cols) > 0

                            if problem_type == "regression" and unique_targets == total_rows:
                                st.error("⚠️ Target appears to be an identifier or unique key (all values unique). This is NOT suitable for regression.")
                                add_log("ML aborted: target appears to be an identifier", "error")
                            else:
                                results = pipeline.run_full_pipeline(
                                    df=ml_df,
                                    target_column=target_column,
                                    selected_features=selected_features,
                                    exclude_features=list(excluded_by_rules),
                                    problem_type=problem_type,
                                    date_columns=feature_date_cols,
                                    has_date_split=has_date_split,
                                )

                                set_state(ML_RESULTS_KEY, results)
                                set_state(ML_PLAN_KEY, {
                                    "target": target_column,
                                    "problem_type": problem_type,
                                    "features": selected_features,
                                    "excluded": list(excluded_by_rules),
                                })

                                add_log(f"ML training completed: {len(results.get('evaluation', {}))} models trained", "success")
                                st.success("Model training completed!")
                                st.rerun()

                        except Exception as e:
                            add_log(f"ML training error: {e}", "error")
                            st.error(f"Training failed: {e}")

            ml_results = get_state(ML_RESULTS_KEY)
            if ml_results:
                st.markdown("---")
                st.markdown("**Model Evaluation Results**")

                evaluations = ml_results.get("evaluation", {})
                if evaluations:
                    best_model_name = ml_results.get("best_model_name", "N/A")

                    results_records = []
                    for model_name, metrics in evaluations.items():
                        record = {"Model": model_name}
                        record.update(metrics)
                        if "leakage_warning" in metrics and metrics["leakage_warning"]:
                            record["⚠️ Leakage"] = "⚠️ SUSPICIOUS"
                        results_records.append(record)

                    results_df = pd.DataFrame(results_records)
                    safe_display_df(results_df)

                    best_metrics = evaluations.get(best_model_name, {}) if best_model_name in evaluations else {}
                    st.markdown(f"**Best Model: `{best_model_name}`**")

                    fi_df = ml_results.get("feature_importance")
                    if fi_df is not None and not fi_df.empty:
                        st.markdown("**Feature Importance (Top 15)**")
                        safe_display_df(fi_df.head(15))

                        if not fi_df.empty:
                            import matplotlib
                            matplotlib.use('Agg')
                            import matplotlib.pyplot as plt
                            fig, ax = plt.subplots(figsize=(10, max(4, len(fi_df.head(15)) * 0.35)))
                            top_fi = fi_df.head(15)
                            colors = plt.cm.RdYlGn_r(np.linspace(0.2, 0.8, len(top_fi)))
                            ax.barh(range(len(top_fi)), top_fi["Importance"].values, color=colors)
                            ax.set_yticks(range(len(top_fi)))
                            ax.set_yticklabels(top_fi["Feature"].values)
                            ax.set_xlabel("Importance")
                            ax.set_title(f"Feature Importance — {best_model_name}")
                            ax.invert_yaxis()
                            plt.tight_layout()
                            buf = __import__('io').BytesIO()
                            fig.savefig(buf, format='png', dpi=100, bbox_inches='tight')
                            plt.close(fig)
                            buf.seek(0)
                            import base64 as b64
                            img_b64 = b64.b64encode(buf.read()).decode()
                            display_base64_image(img_b64, f"Feature Importance: {best_model_name}")

                    # AI: Model comparison explanation
                    if ai.is_available():
                        with st.expander("🤖 AI: Why Did This Model Win?"):
                            if st.button("Explain Model Comparison", key="btn_explain_models"):
                                with st.spinner("AI is comparing models..."):
                                    try:
                                        model_explanation = ai.explain_model_comparison(
                                            evaluations=evaluations,
                                            problem_type=problem_type,
                                            target_column=target_column,
                                            dataset_rows=len(ml_df),
                                        )
                                        set_state("ai_model_explanation", model_explanation)
                                        add_log("AI model comparison generated", "success")
                                    except Exception as e:
                                        add_log(f"AI model explain error: {e}", "error")
                            cached = get_state("ai_model_explanation")
                            if cached:
                                st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

                    # AI: Feature importance explanation
                    if fi_df is not None and not fi_df.empty and ai.is_available():
                        with st.expander("🤖 AI: Explain Feature Importance"):
                            if st.button("Explain Why Features Matter", key="btn_explain_fi"):
                                with st.spinner("AI is analyzing feature importance..."):
                                    try:
                                        fi_explanation = ai.explain_feature_importance(
                                            feature_importance_df_str=fi_df.head(15).to_string(),
                                            top_n=15,
                                            problem_type=problem_type,
                                            target_column=target_column,
                                        )
                                        set_state("ai_fi_explanation", fi_explanation)
                                        add_log("AI feature importance explanation generated", "success")
                                    except Exception as e:
                                        add_log(f"AI FI explain error: {e}", "error")
                            cached = get_state("ai_fi_explanation")
                            if cached:
                                st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

                    # AI: ML Suitability assessment
                    if ai.is_available():
                        with st.expander("🤖 AI: Is This Problem Suitable for ML?"):
                            if st.button("Assess ML Suitability", key="btn_ml_suitability"):
                                with st.spinner("AI is assessing ML suitability..."):
                                    try:
                                        ml_target = ml_df[target_column]
                                        suitability = ai.explain_ml_suitability(
                                            dataset_shape=(len(ml_df), len(ml_df.columns)),
                                            target_column=target_column,
                                            unique_targets=ml_target.nunique(),
                                            missing_target_pct=float(ml_target.isnull().sum() / len(ml_df) * 100),
                                            problem_type=problem_type,
                                            selected_features=selected_features,
                                            excluded_features=list(excluded_by_rules),
                                        )
                                        set_state("ai_ml_suitability", suitability)
                                        add_log("AI ML suitability assessment generated", "success")
                                    except Exception as e:
                                        add_log(f"AI suitability error: {e}", "error")
                            cached = get_state("ai_ml_suitability")
                            if cached:
                                st.markdown(f'<div class="ai-response">{cached}</div>', unsafe_allow_html=True)

                    st.markdown("---")
                    if st.button("💾 Save Model Package", type="primary", use_container_width=True):
                        try:
                            os.makedirs("models", exist_ok=True)
                            safe_name = "".join(c if c.isalnum() or c in "_-" else "_" for c in target_column)
                            filepath = f"models/model_{safe_name}_{problem_type}.pkl"

                            original_feature_list = (
                                ml_results.get("numeric_features", []) +
                                ml_results.get("categorical_features", [])
                            )
                            pipeline_obj = MLPipeline()
                            pipeline_obj.save_model_package(
                                model=ml_results.get("best_model"),
                                preprocessor=ml_results.get("preprocessor"),
                                feature_list=original_feature_list,
                                target=target_column,
                                problem_type=problem_type,
                                numeric_features=ml_results.get("numeric_features", []),
                                categorical_features=ml_results.get("categorical_features", []),
                                date_columns=[],
                                metrics={k: float(v) if hasattr(v, '__float__') else v for k, v in best_metrics.items()},
                                feature_importance=fi_df,
                                filepath=filepath,
                            )
                            ml_results["model_package_path"] = filepath
                            set_state(ML_RESULTS_KEY, ml_results)
                            add_log(f"Model saved to {filepath}", "success")
                            st.success(f"Model saved to `{filepath}`")
                        except Exception as e:
                            add_log(f"Model save error: {e}", "error")
                            st.error(f"Save failed: {e}")

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 5: Prediction
    # ═══════════════════════════════════════════════════════════════════════
    with tab5:
        st.markdown('<div class="section-header">🎯 Prediction</div>', unsafe_allow_html=True)

        st.markdown("**Step 1: Load a Model Package**")
        pred_col1, pred_col2 = st.columns(2)

        with pred_col1:
            use_trained = st.checkbox("Use last trained model", value=False)

        with pred_col2:
            uploaded_model = st.file_uploader(
                "Or upload a saved model (.pkl)",
                type=["pkl"],
                key="model_uploader",
            )

        pred_engine: PredictionEngine | None = None

        if use_trained:
            ml_results = get_state(ML_RESULTS_KEY)
            if ml_results and "model_package_path" in ml_results:
                try:
                    import joblib
                    with open(ml_results["model_package_path"], "rb") as f:
                        pkg = joblib.load(f)
                    pred_engine = PredictionEngine(pkg)
                    add_log("Loaded trained model for prediction", "info")
                except Exception as e:
                    st.error(f"Failed to load trained model: {e}")
                    add_log(f"Model load error: {e}", "error")

        elif uploaded_model is not None:
            try:
                import joblib
                with tempfile.NamedTemporaryFile(suffix=".pkl", delete=False) as tmp:
                    tmp.write(uploaded_model.read())
                    tmp_path = tmp.name
                pkg = joblib.load(tmp_path)
                os.unlink(tmp_path)
                pred_engine = PredictionEngine(pkg)
                set_state(UPLOADED_MODEL_KEY, pkg)
                add_log("Uploaded model loaded for prediction", "success")
            except Exception as e:
                st.error(f"Failed to load uploaded model: {e}")
                add_log(f"Upload model error: {e}", "error")

        if pred_engine:
            model_info = pred_engine.get_model_info()

            # ── Model & Feature Overview ──
            st.markdown("---")
            st.markdown("**Model & Feature Overview**")
            mi_c1, mi_c2, mi_c3 = st.columns(3)
            with mi_c1:
                st.markdown(render_metric_card("Target", model_info.get('target', 'N/A')), unsafe_allow_html=True)
            with mi_c2:
                st.markdown(render_metric_card("Problem Type", model_info.get('problem_type', 'N/A').capitalize()), unsafe_allow_html=True)
            with mi_c3:
                st.markdown(render_metric_card("Total Features", str(model_info.get('feature_count', 0))), unsafe_allow_html=True)

            # Show feature breakdown
            schema = pred_engine.generate_input_form_schema()
            if schema:
                numeric_feats = [f for f in schema if f['role'] == 'numeric']
                categorical_feats = [f for f in schema if f['role'] == 'categorical']
                date_feats = [f for f in schema if f['role'] == 'date']
                other_feats = [f for f in schema if f['role'] not in ('numeric', 'categorical', 'date')]

                st.markdown("**Feature Breakdown**")
                fb_cols = st.columns(4)
                with fb_cols[0]:
                    st.caption(f"🔢 **Numeric** ({len(numeric_feats)})")
                    if numeric_feats:
                        for f in numeric_feats:
                            min_v = f.get('min', 'N/A')
                            max_v = f.get('max', 'N/A')
                            st.markdown(f"• `{f['name']}` — range: {min_v} to {max_v}", help=f"Type: {f['dtype']} | Role: {f['role']}")
                with fb_cols[1]:
                    st.caption(f"🏷️ **Categorical** ({len(categorical_feats)})")
                    if categorical_feats:
                        for f in categorical_feats:
                            opts = f.get('options')
                            preview = f"{len(opts)} categories" if opts else "free text"
                            st.markdown(f"• `{f['name']}` — {preview}", help=f"Type: {f['dtype']} | Role: {f['role']}")
                with fb_cols[2]:
                    st.caption(f"📅 **Date** ({len(date_feats)})")
                    if date_feats:
                        for f in date_feats:
                            st.markdown(f"• `{f['name']}` — auto-converted to numeric", help=f"Type: {f['dtype']} | Role: {f['role']}")
                with fb_cols[3]:
                    st.caption(f"📝 **Other** ({len(other_feats)})")
                    if other_feats:
                        for f in other_feats:
                            st.markdown(f"• `{f['name']}`", help=f"Type: {f['dtype']} | Role: {f['role']}")
                    else:
                        st.caption("None")

            if model_info["metrics"]:
                with st.expander("📊 Training Metrics"):
                    st.json(model_info["metrics"])

            # ── Prediction Mode Toggle ──
            st.markdown("---")
            st.markdown("**Step 2: Choose Prediction Mode**")
            pred_mode = st.radio(
                "How do you want to predict?",
                ["📝 Single Record — Enter values manually", "📁 Batch CSV — Upload a file with multiple records"],
                key="pred_mode_toggle",
                horizontal=True,
            )

            # ── SINGLE RECORD PREDICTION ──
            if pred_mode.startswith("📝"):
                st.markdown("---")
                st.markdown("**Step 3: Enter Feature Values**")

                form_inputs = {}
                for i in range(0, len(schema), 2):
                    form_cols = st.columns(2)
                    for j in range(2):
                        if i + j < len(schema):
                            field = schema[i + j]
                            with form_cols[j]:
                                label = field["name"].replace("_", " ").title()
                                if field["role"] == "numeric":
                                    default = field.get("min", 0.0)
                                    form_inputs[field["name"]] = st.number_input(
                                        label,
                                        value=default,
                                        format="%.4f",
                                        key=f"pred_{field['name']}",
                                        help=f"Range: {field.get('min', 'N/A')} — {field.get('max', 'N/A')}",
                                    )
                                elif field["role"] == "date":
                                    form_inputs[field["name"]] = st.text_input(
                                        label,
                                        value="",
                                        key=f"pred_{field['name']}",
                                        placeholder="YYYY-MM-DD",
                                    )
                                elif field["options"]:
                                    form_inputs[field["name"]] = st.selectbox(
                                        label,
                                        field["options"],
                                        key=f"pred_{field['name']}",
                                    )
                                else:
                                    form_inputs[field["name"]] = st.text_input(
                                        label,
                                        key=f"pred_{field['name']}",
                                    )

                if st.button("🎯 Predict", type="primary", use_container_width=True):
                    result = pred_engine.predict(form_inputs)
                    if result.get("success"):
                        st.markdown("---")
                        pred_value = result["prediction"]
                        pred_label = result.get("prediction_label")
                        confidence = result.get("confidence")

                        display_val = str(pred_label) if pred_label else f"{pred_value:,.4f}" if isinstance(pred_value, (int, float)) else str(pred_value)
                        conf_str = f" | **Confidence:** {confidence:.2%}" if confidence else ""

                        st.markdown(f"""
                        <div class="prediction-result">
                            <div class="prediction-sub" style="text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; font-weight: 600; margin-bottom: 0.5rem;">
                                Prediction Result
                            </div>
                            <div class="prediction-value">{display_val}</div>
                            <div class="prediction-sub">
                                Target: {model_info['target']} | Type: {model_info['problem_type']}{conf_str}
                            </div>
                        </div>
                        """, unsafe_allow_html=True)

                        if ai.is_available():
                            try:
                                explanation, provider = ai.explain_prediction(
                                    inputs=form_inputs,
                                    prediction=pred_value,
                                    model_info=model_info,
                                )
                                st.markdown(f'<div class="ai-response"><strong>🤖 AI Explanation:</strong><br>{explanation}</div>', unsafe_allow_html=True)
                            except Exception:
                                pass

                        history = get_state(PREDICTION_HISTORY_KEY) or []
                        history.append({
                            "inputs": form_inputs,
                            "prediction": pred_value,
                            "label": pred_label,
                            "confidence": confidence,
                        })
                        set_state(PREDICTION_HISTORY_KEY, history[-50:])
                        add_log(f"Prediction: {display_val}", "success")

                    else:
                        st.error(f"Prediction failed: {result.get('error', 'Unknown error')}")
                        add_log(f"Prediction failed: {result.get('error')}", "error")

                history = get_state(PREDICTION_HISTORY_KEY)
                if history:
                    with st.expander(f"📜 Prediction History ({len(history)})"):
                        for idx, h in enumerate(reversed(history[-10:])):
                            val = str(h.get("label") or h.get("prediction", "N/A"))
                            conf = f" (confidence: {h['confidence']:.2%})" if h.get("confidence") else ""
                            st.markdown(f"**#{len(history) - idx}:** `{val}`{conf}")

            # ── BATCH CSV PREDICTION ──
            elif pred_mode.startswith("📁"):
                st.markdown("---")
                st.markdown("**Step 3: Upload CSV for Batch Prediction**")

                feature_names = [f["name"] for f in schema]
                feature_names_str = ", ".join(f"`{n}`" for n in feature_names)
                st.info(f"Your CSV must contain these columns: {feature_names_str}. Extra columns will be ignored.")

                batch_file = st.file_uploader(
                    "Upload CSV with data to predict on",
                    type=["csv"],
                    key="batch_csv_uploader",
                )

                if batch_file is not None:
                    try:
                        batch_df = pd.read_csv(batch_file)
                        missing = [f for f in feature_names if f not in batch_df.columns]

                        if missing:
                            st.error(f"Missing required columns: {', '.join(f'`{m}`' for m in missing)}")
                            st.caption("Please ensure your CSV has all the feature columns the model was trained on.")
                        else:
                            # Let user select which rows to include
                            max_preview = min(20, len(batch_df))
                            st.markdown(f"**CSV Preview** ({len(batch_df):,} rows found)")
                            safe_display_df(batch_df.head(max_preview), max_rows=20)

                            # Row range selector
                            row_range = st.slider(
                                "Select row range for prediction",
                                min_value=1,
                                max_value=len(batch_df),
                                value=(1, len(batch_df)),
                                step=1,
                                help="Choose which rows to include in the batch prediction.",
                            )

                            if st.button("🚀 Run Batch Prediction", type="primary", use_container_width=True):
                                selected_df = batch_df.iloc[row_range[0]-1:row_range[1]].copy()
                                with st.spinner(f"Predicting {len(selected_df)} rows..."):
                                    try:
                                        result_df = pred_engine.predict_batch(selected_df)

                                        # Show results
                                        st.markdown("---")
                                        st.markdown(f"**Batch Results** ({len(result_df)} rows)")
                                        safe_display_df(result_df, max_rows=100)

                                        # Download results
                                        csv_buffer = StringIO()
                                        result_df.to_csv(csv_buffer, index=False)
                                        st.download_button(
                                            "📥 Download Predictions as CSV",
                                            csv_buffer.getvalue(),
                                            "batch_predictions.csv",
                                            "text/csv",
                                            use_container_width=True,
                                        )

                                        # Summary stats
                                        pred_col = [c for c in result_df.columns if 'prediction' in c.lower()][0] if result_df.columns.any() else 'prediction'
                                        st.markdown(f"**Summary:** min={result_df[pred_col].min():.4f}, max={result_df[pred_col].max():.4f}, mean={result_df[pred_col].mean():.4f}")

                                        add_log(f"Batch prediction completed: {len(selected_df)} rows", "success")
                                    except Exception as e:
                                        add_log(f"Batch prediction error: {e}", "error")
                                        st.error(f"Batch prediction failed: {e}")
                    except Exception as e:
                        st.error(f"Failed to read CSV: {e}")
                        add_log(f"Batch CSV read error: {e}", "error")
