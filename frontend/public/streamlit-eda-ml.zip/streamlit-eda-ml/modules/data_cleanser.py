"""
Universal, heuristic-driven data cleaning module for the AI-Assisted EDA & ML Platform.

Provides a :class:`DataCleanser` that applies a configurable pipeline of
dataset-agnostic cleaning steps — duplicate removal, summary-row elimination,
missing-value imputation, dtype optimisation, and date parsing.  No domain-
specific or hardcoded business logic is included.
"""

import logging
import warnings
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd

from modules.utils import detect_date_columns, setup_logging


class DataCleanser:
    """Heuristic data-cleaning pipeline that works on any tabular dataset.

    Parameters
    ----------
    df : pd.DataFrame
        The raw DataFrame to be cleaned.
    """

    # Substrings that signal a summary / aggregation row (case-insensitive).
    _SUMMARY_KEYWORDS: list[str] = [
        "grand total",
        "subtotal",
        "sub total",
        "total",
        "sum",
        "net total",
        "nettotal",
        "grandtotal",
        "grand_total",
        "net_total",
    ]

    # Substrings commonly found in identifier column names (case-insensitive).
    _ID_HINTS: list[str] = ["id", "code", "no"]

    def __init__(self, df: pd.DataFrame) -> None:
        self._df_original = df.copy()
        self._logs: list[str] = []
        self._logger = setup_logging()

        # Tracking counters populated during cleaning.
        self._duplicates_removed: int = 0
        self._summary_rows_removed: int = 0
        self._columns_imputed: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def clean(self, **options: Any) -> pd.DataFrame:
        """Execute the full cleaning pipeline and return the cleaned DataFrame.

        Parameters
        ----------
        **options : Any
            Boolean flags that enable / disable individual cleaning steps:

            * ``remove_duplicates`` (default ``True``)
            * ``remove_summary_rows`` (default ``True``)
            * ``impute_numeric`` (default ``True``)
            * ``impute_categorical`` (default ``True``)
            * ``convert_categories`` (default ``True``)
            * ``downcast_numeric`` (default ``True``)
            * ``parse_dates`` (default ``True``)

        Returns
        -------
        pd.DataFrame
            The cleaned DataFrame.
        """
        remove_duplicates: bool = options.get("remove_duplicates", True)
        remove_summary_rows: bool = options.get("remove_summary_rows", True)
        impute_numeric: bool = options.get("impute_numeric", True)
        impute_categorical: bool = options.get("impute_categorical", True)
        convert_categories: bool = options.get("convert_categories", True)
        downcast_numeric: bool = options.get("downcast_numeric", True)
        parse_dates: bool = options.get("parse_dates", True)

        df = self._df_original.copy()

        # Capture pre-cleaning shape / memory for the summary report.
        rows_before = len(df)
        cols_before = len(df.columns)
        memory_before = df.memory_usage(deep=True).sum()

        self._log("=" * 60)
        self._log("Data Cleansing Pipeline — started at %s", datetime.now().isoformat())
        self._log("Input: %d rows × %d columns", rows_before, cols_before)
        self._log("=" * 60)

        # --- Step 1: Remove exact duplicate rows ---
        if remove_duplicates:
            df = self._remove_duplicates(df)

        # --- Step 2: Remove summary / aggregation rows ---
        if remove_summary_rows:
            df = self._remove_summary_rows(df)

        # --- Step 3: Parse date-like string columns ---
        if parse_dates:
            df = self._parse_dates(df)

        # --- Step 4: Impute missing numeric values ---
        if impute_numeric:
            df = self._impute_numeric(df)

        # --- Step 5: Impute missing categorical values ---
        if impute_categorical:
            df = self._impute_categorical(df)

        # --- Step 6: Convert low-cardinality object cols to category ---
        if convert_categories:
            df = self._convert_categories(df)

        # --- Step 7: Downcast numeric dtypes for memory efficiency ---
        if downcast_numeric:
            df = self._downcast_numeric(df)

        # Capture post-cleaning stats.
        rows_after = len(df)
        cols_after = len(df.columns)
        memory_after = df.memory_usage(deep=True).sum()

        # Store summary metadata.
        self._summary: dict[str, Any] = {
            "rows_before": rows_before,
            "rows_after": rows_after,
            "cols_before": cols_before,
            "cols_after": cols_after,
            "duplicates_removed": self._duplicates_removed,
            "summary_rows_removed": self._summary_rows_removed,
            "columns_imputed": self._columns_imputed,
            "memory_before_mb": round(memory_before / (1024 ** 2), 2),
            "memory_after_mb": round(memory_after / (1024 ** 2), 2),
        }

        self._log("=" * 60)
        self._log("Pipeline complete.")
        self._log(
            "Output: %d rows × %d columns | Memory: %s → %s",
            rows_after,
            cols_after,
            f"{self._summary['memory_before_mb']} MB",
            f"{self._summary['memory_after_mb']} MB",
        )
        self._log("=" * 60)

        return df

    def get_logs(self) -> list[str]:
        """Return the list of log messages produced during cleaning.

        Returns
        -------
        list[str]
            Human-readable log entries.
        """
        return list(self._logs)

    def get_summary(self) -> dict[str, Any]:
        """Return a summary dictionary of the most recent cleaning run.

        Returns
        -------
        dict[str, Any]
            Keys: ``rows_before``, ``rows_after``, ``cols_before``,
            ``cols_after``, ``duplicates_removed``, ``summary_rows_removed``,
            ``columns_imputed``, ``memory_before_mb``, ``memory_after_mb``.
        """
        return getattr(self, "_summary", {})

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _log(self, msg: str, *args: Any) -> None:
        """Append a formatted message to the internal log list."""
        text = msg % args if args else msg
        self._logs.append(text)
        self._logger.info(text)

    # ------------------------------------------------------------------
    # Pipeline steps
    # ------------------------------------------------------------------

    def _remove_duplicates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Drop exact duplicate rows and log the count removed."""
        before = len(df)
        df = df.drop_duplicates()
        removed = before - len(df)
        self._duplicates_removed = removed
        if removed > 0:
            self._log("[duplicates] Removed %d duplicate row(s).", removed)
        else:
            self._log("[duplicates] No duplicate rows found.")
        return df

    def _remove_summary_rows(self, df: pd.DataFrame) -> pd.DataFrame:
        """Drop rows whose object-type cells contain summary keywords."""
        if df.empty:
            return df

        object_cols = df.select_dtypes(include=["object", "string"]).columns.tolist()
        if not object_cols:
            self._log("[summary-rows] No object columns to check — skipped.")
            return df

        # Build a boolean mask: True where *any* object cell contains a keyword.
        keyword_pattern = "|".join(self._SUMMARY_KEYWORDS)
        mask = pd.Series(False, index=df.index)
        for col in object_cols:
            col_mask = (
                df[col]
                .astype(str)
                .str.strip()
                .str.lower()
                .str.contains(keyword_pattern, na=False, regex=True)
            )
            mask = mask | col_mask

        removed = int(mask.sum())
        df = df.loc[~mask].reset_index(drop=True)
        self._summary_rows_removed = removed
        if removed > 0:
            self._log(
                "[summary-rows] Removed %d row(s) containing summary keywords.",
                removed,
            )
        else:
            self._log("[summary-rows] No summary rows detected.")
        return df

    def _impute_numeric(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fill missing values in numeric columns.

        * Identifier-like columns (name contains ``id``, ``code``, ``no``) are
          converted to string and filled with ``'UNKNOWN'``.
        * All other numeric columns are filled with the column median.
        """
        numeric_cols = df.select_dtypes(include="number").columns.tolist()
        if not numeric_cols:
            self._log("[impute-numeric] No numeric columns — skipped.")
            return df

        imputed_count = 0
        for col in numeric_cols:
            if df[col].isna().sum() == 0:
                continue

            col_lower = col.lower().strip()
            is_id_col = any(hint in col_lower for hint in self._ID_HINTS)

            if is_id_col:
                missing_count = int(df[col].isna().sum())
                df[col] = df[col].astype("object").fillna("UNKNOWN")
                self._log(
                    "[impute-numeric] '%s' — filled %d NaN(s) with 'UNKNOWN' (identifier column).",
                    col,
                    missing_count,
                )
            else:
                median_val = df[col].median()
                missing_count = int(df[col].isna().sum())
                df[col] = df[col].fillna(median_val)
                self._log(
                    "[impute-numeric] '%s' — filled %d NaN(s) with median (%.4f).",
                    col,
                    missing_count,
                    float(median_val),
                )

            imputed_count += 1

        self._columns_imputed += imputed_count
        if imputed_count == 0:
            self._log("[impute-numeric] No missing values in numeric columns.")
        return df

    def _impute_categorical(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fill missing values in object / category columns.

        * If a mode exists, the mode value is used.
        * Otherwise the literal string ``'missing'`` is used.
        """
        cat_cols = df.select_dtypes(include=["object", "string", "category"]).columns.tolist()
        if not cat_cols:
            self._log("[impute-categorical] No categorical columns — skipped.")
            return df

        imputed_count = 0
        for col in cat_cols:
            missing_count = int(df[col].isna().sum())
            if missing_count == 0:
                continue

            mode_val = df[col].mode()
            if len(mode_val) > 0:
                fill_val = mode_val.iloc[0]
                self._log(
                    "[impute-categorical] '%s' — filled %d NaN(s) with mode ('%s').",
                    col,
                    missing_count,
                    str(fill_val),
                )
            else:
                fill_val = "missing"
                self._log(
                    "[impute-categorical] '%s' — filled %d NaN(s) with 'missing' (no mode).",
                    col,
                    missing_count,
                )

            df[col] = df[col].fillna(fill_val)
            imputed_count += 1

        self._columns_imputed += imputed_count
        if imputed_count == 0:
            self._log("[impute-categorical] No missing values in categorical columns.")
        return df

    def _convert_categories(self, df: pd.DataFrame) -> pd.DataFrame:
        """Convert low-cardinality object columns to the ``category`` dtype.

        A column is converted when it has fewer than 50 unique values *and*
        the unique-to-total ratio is below 0.5.
        """
        object_cols = df.select_dtypes(include=["object", "string"]).columns.tolist()
        if not object_cols:
            self._log("[convert-categories] No object columns — skipped.")
            return df

        converted: list[str] = []
        for col in object_cols:
            n_unique = df[col].nunique(dropna=True)
            n_total = len(df)

            if n_total == 0:
                continue

            unique_ratio = n_unique / n_total

            if n_unique < 50 and unique_ratio < 0.5:
                df[col] = df[col].astype("category")
                converted.append(col)

        if converted:
            self._log(
                "[convert-categories] Converted %d column(s) to 'category': %s",
                len(converted),
                converted,
            )
        else:
            self._log("[convert-categories] No columns met conversion criteria.")
        return df

    def _downcast_numeric(self, df: pd.DataFrame) -> pd.DataFrame:
        """Downcast numeric columns to the smallest compatible dtype."""
        numeric_cols = df.select_dtypes(include="number").columns.tolist()
        if not numeric_cols:
            self._log("[downcast] No numeric columns — skipped.")
            return df

        memory_before = df.memory_usage(deep=True).sum()

        for col in numeric_cols:
            if pd.api.types.is_integer_dtype(df[col]):
                df[col] = pd.to_numeric(df[col], downcast="integer")
            elif pd.api.types.is_float_dtype(df[col]):
                df[col] = pd.to_numeric(df[col], downcast="float")

        memory_after = df.memory_usage(deep=True).sum()
        saved = memory_before - memory_after

        if saved > 0:
            self._log(
                "[downcast] Numeric downcast saved %s.",
                self._format_bytes(saved),
            )
        else:
            self._log("[downcast] No memory savings from downcasting.")
        return df

    def _parse_dates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Detect and parse date-like columns using :func:`detect_date_columns`."""
        date_cols = detect_date_columns(df)
        if not date_cols:
            self._log("[parse-dates] No date-like columns detected.")
            return df

        parsed_ok: list[str] = []
        parsed_fail: list[str] = []

        for col in date_cols:
            # Skip columns already parsed as datetime.
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                parsed_ok.append(col)
                continue

            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df[col] = pd.to_datetime(
                        df[col], dayfirst=False, format="mixed", errors="coerce"
                    )

                # Check how many values were actually parsed (not NaT).
                total_non_null = df[col].notna().sum() + df[col].isna().sum()
                nat_count = df[col].isna().sum()
                original_na = self._df_original[col].isna().sum()
                newly_nat = nat_count - original_na
                total_values = total_non_null

                if total_values > 0:
                    success_rate = (total_values - newly_nat) / total_values
                else:
                    success_rate = 1.0

                if success_rate >= 0.8:
                    parsed_ok.append(col)
                    self._log(
                        "[parse-dates] Parsed '%s' as datetime (success rate %.0f%%).",
                        col,
                        success_rate * 100,
                    )
                else:
                    # Revert — too many values turned to NaT.
                    df[col] = self._df_original[col].copy()
                    parsed_fail.append(col)
                    self._log(
                        "[parse-dates] Skipped '%s' — success rate too low (%.0f%%).",
                        col,
                        success_rate * 100,
                    )
            except Exception as exc:
                parsed_fail.append(col)
                self._log("[parse-dates] Failed to parse '%s': %s", col, exc)

        if parsed_ok or parsed_fail:
            self._log(
                "[parse-dates] Attempted %d column(s): %d successful, %d skipped/failed.",
                len(date_cols),
                len(parsed_ok),
                len(parsed_fail),
            )
        return df

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @staticmethod
    def _format_bytes(size_bytes: int) -> str:
        """Convert a byte count into a compact human-readable string."""
        if size_bytes <= 0:
            return "0 B"
        for unit in ("B", "KB", "MB", "GB"):
            if abs(size_bytes) < 1024.0 or unit == "GB":
                if unit == "B":
                    return f"{int(size_bytes)} {unit}"
                return f"{size_bytes:,.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:,.2f} TB"
