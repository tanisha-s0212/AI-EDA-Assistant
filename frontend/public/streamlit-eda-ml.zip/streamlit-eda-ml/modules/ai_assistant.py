"""
AI Assistant module for AI-Assisted EDA & ML Platform.

Handles AI provider integration (LongCat and Groq) for data analysis
assistance. Fully dataset-agnostic — no hardcoded column names or
domain assumptions.
"""

import os
import json
import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default models
# ---------------------------------------------------------------------------
_LONGCAT_DEFAULT_MODEL = "LongCat-Flash-Chat"
_GROQ_DEFAULT_MODEL = "llama-3.3-70b-versatile"

# ---------------------------------------------------------------------------
# API endpoints
# ---------------------------------------------------------------------------
_LONGCAT_URL = "https://api.longcat.ai/api/v1/chat/completions"
_GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"


class AIAssistant:
    """Manages multi-provider AI chat completions with automatic fallback.

    Provider priority
    -----------------
    1. **LongCat** — used first when ``LONGCAT_API_KEY`` is present.
    2. **Groq** — used when LongCat is unavailable or has failed.

    A provider that raises an exception is added to ``_failed_providers`` and
    skipped for the remainder of the session (until the instance is recreated).

    Parameters
    ----------
    temperature : float, optional
        Sampling temperature forwarded to every API call.  Default ``0.1``
        for deterministic, factual responses.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    def __init__(self) -> None:
        # API keys from environment
        self._longcat_key: str | None = os.environ.get("LONGCAT_API_KEY")
        self._groq_key: str | None = os.environ.get("GROQ_API_KEY")
        self._longcat_model: str = os.environ.get(
            "LONGCAT_MODEL", _LONGCAT_DEFAULT_MODEL
        )

        # Provider priority: LongCat first if configured, else Groq
        if self._longcat_key:
            self._provider_priority: list[str] = ["longcat", "groq"]
        else:
            self._provider_priority: list[str] = ["groq", "longcat"]

        self._failed_providers: set[str] = set()
        self._temperature: float = 0.1

        logger.info(
            "AIAssistant initialised — longcat=%s, groq=%s, priority=%s",
            "configured" if self._longcat_key else "not configured",
            "configured" if self._groq_key else "not configured",
            self._provider_priority,
        )

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------
    def is_available(self) -> bool:
        """Return ``True`` when at least one API key is configured."""
        return bool(self._longcat_key or self._groq_key)

    def get_provider_status(self) -> dict[str, Any]:
        """Return a status dictionary useful for UI display.

        Returns
        -------
        dict
            ``longcat_configured``, ``groq_configured``,
            ``active_provider``, ``failed_providers``.
        """
        active = self._determine_active_provider()
        return {
            "longcat_configured": bool(self._longcat_key),
            "groq_configured": bool(self._groq_key),
            "active_provider": active,
            "failed_providers": list(self._failed_providers),
        }

    def _determine_active_provider(self) -> str | None:
        """Return the name of the provider that would be tried first, or *None*."""
        for name in self._provider_priority:
            if name not in self._failed_providers:
                key = self._longcat_key if name == "longcat" else self._groq_key
                if key:
                    return name
        return None

    # ------------------------------------------------------------------
    # Low-level provider calls
    # ------------------------------------------------------------------
    def _call_longcat(self, messages: list[dict], model: str) -> str:
        """Call the LongCat chat-completions endpoint.

        Parameters
        ----------
        messages : list[dict]
            OpenAI-style message list (``role`` / ``content``).
        model : str
            Model identifier.

        Returns
        -------
        str
            Assistant reply text, or an error description on failure.
        """
        if not self._longcat_key:
            return "[Error] LongCat API key is not configured."

        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.post(
                    _LONGCAT_URL,
                    headers={
                        "Authorization": f"Bearer {self._longcat_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": model,
                        "messages": messages,
                        "temperature": self._temperature,
                        "max_tokens": 2000,
                    },
                )

            if resp.status_code != 200:
                logger.warning(
                    "LongCat HTTP %s: %s", resp.status_code, resp.text[:300]
                )
                return f"[Error] LongCat returned HTTP {resp.status_code}: {resp.text[:200]}"

            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            logger.info("LongCat response received (%d chars)", len(content))
            return str(content)

        except httpx.TimeoutException:
            msg = "[Error] LongCat request timed out."
            logger.error(msg)
            return msg
        except (httpx.HTTPStatusError, httpx.RequestError) as exc:
            msg = f"[Error] LongCat request failed: {exc}"
            logger.error(msg)
            return msg
        except (KeyError, IndexError, TypeError) as exc:
            msg = f"[Error] LongCat response parsing failed: {exc}"
            logger.error(msg)
            return msg
        except Exception as exc:
            msg = f"[Error] LongCat unexpected error: {exc}"
            logger.error(msg)
            return msg

    def _call_groq(self, messages: list[dict], model: str = _GROQ_DEFAULT_MODEL) -> str:
        """Call the Groq chat-completions endpoint.

        Parameters
        ----------
        messages : list[dict]
            OpenAI-style message list.
        model : str, optional
            Model identifier.  Defaults to ``llama-3.3-70b-versatile``.

        Returns
        -------
        str
            Assistant reply text, or an error description on failure.
        """
        if not self._groq_key:
            return "[Error] Groq API key is not configured."

        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.post(
                    _GROQ_URL,
                    headers={
                        "Authorization": f"Bearer {self._groq_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": model,
                        "messages": messages,
                        "temperature": self._temperature,
                        "max_tokens": 2000,
                    },
                )

            if resp.status_code != 200:
                logger.warning(
                    "Groq HTTP %s: %s", resp.status_code, resp.text[:300]
                )
                return f"[Error] Groq returned HTTP {resp.status_code}: {resp.text[:200]}"

            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            logger.info("Groq response received (%d chars)", len(content))
            return str(content)

        except httpx.TimeoutException:
            msg = "[Error] Groq request timed out."
            logger.error(msg)
            return msg
        except (httpx.HTTPStatusError, httpx.RequestError) as exc:
            msg = f"[Error] Groq request failed: {exc}"
            logger.error(msg)
            return msg
        except (KeyError, IndexError, TypeError) as exc:
            msg = f"[Error] Groq response parsing failed: {exc}"
            logger.error(msg)
            return msg
        except Exception as exc:
            msg = f"[Error] Groq unexpected error: {exc}"
            logger.error(msg)
            return msg

    # ------------------------------------------------------------------
    # Fallback orchestration
    # ------------------------------------------------------------------
    def _call_with_fallback(self, messages: list[dict]) -> tuple[str, str]:
        """Try each configured provider in priority order.

        Parameters
        ----------
        messages : list[dict]
            OpenAI-style message list.

        Returns
        -------
        tuple[str, str]
            ``(response_text, provider_name)`` where *provider_name* is the
            name of the provider that produced the response (or the last
            provider attempted).
        """
        last_provider = "none"
        for provider_name in self._provider_priority:
            if provider_name in self._failed_providers:
                logger.debug("Skipping failed provider: %s", provider_name)
                continue

            last_provider = provider_name

            if provider_name == "longcat" and self._longcat_key:
                result = self._call_longcat(messages, self._longcat_model)
            elif provider_name == "groq" and self._groq_key:
                result = self._call_groq(messages)
            else:
                logger.debug("Provider %s has no API key; skipping.", provider_name)
                continue

            # Detect error responses — anything starting with "[Error]" counts.
            if result.startswith("[Error]"):
                self._failed_providers.add(provider_name)
                logger.warning(
                    "Provider %s failed, marking as failed: %s",
                    provider_name,
                    result[:120],
                )
                continue

            return result, provider_name

        # All providers exhausted or failed
        return (
            "[Error] All AI providers are unavailable or have failed. "
            "Please check your API keys and try again.",
            last_provider,
        )

    # ------------------------------------------------------------------
    # Public chat interface
    # ------------------------------------------------------------------
    def chat(self, system_prompt: str, user_prompt: str) -> tuple[str, str]:
        """Send a chat request and return the response with provider info.

        Parameters
        ----------
        system_prompt : str
            System-level instruction for the AI.
        user_prompt : str
            The user message / query.

        Returns
        -------
        tuple[str, str]
            ``(response_text, provider_used)``.
        """
        messages: list[dict] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        logger.info("chat() called — user prompt length: %d chars", len(user_prompt))
        return self._call_with_fallback(messages)

    # ------------------------------------------------------------------
    # High-level analysis helpers
    # ------------------------------------------------------------------
    def generate_data_summary(
        self,
        profile_summary: str,
        column_roles: dict,
        dtypes_summary: str,
    ) -> str:
        """Generate an AI-powered explanation of the dataset.

        Parameters
        ----------
        profile_summary : str
            Textual summary produced by the profiling step (row count,
            basic statistics, etc.).
        column_roles : dict
            Mapping of column names to inferred semantic roles
            (e.g. ``{"age": "numeric", "name": "categorical"}``).
        dtypes_summary : str
            Human-readable summary of column data types.

        Returns
        -------
        str
            Concise dataset explanation (max ~300 words).
        """
        system_prompt = (
            "You are a data-science assistant.  The user will provide a "
            "profile summary of an unknown dataset along with column roles "
            "and data-type information.  Your task:\n"
            "1. Explain the likely purpose of the dataset.\n"
            "2. Describe key columns and their roles.\n"
            "3. Identify any data-quality concerns (missing values, "
            "high cardinality, outliers, etc.).\n"
            "4. Keep the response concise — max 300 words.\n"
            "5. Be dataset-agnostic: reason from the structure, not from "
            "domain-specific assumptions.\n"
            "Do NOT hallucinate domain knowledge."
        )
        user_prompt = (
            f"## Dataset Profile\n{profile_summary}\n\n"
            f"## Column Roles\n{json.dumps(column_roles, indent=2)}\n\n"
            f"## Data Types\n{dtypes_summary}"
        )
        response, provider = self.chat(system_prompt, user_prompt)
        logger.info(
            "generate_data_summary completed via %s (%d chars)",
            provider,
            len(response),
        )
        return response

    def generate_cleaning_recommendations(
        self,
        profile_summary: str,
        missing_summary: str,
        column_roles: dict,
    ) -> str:
        """Generate practical data-cleaning recommendations.

        Parameters
        ----------
        profile_summary : str
            Textual dataset profile (statistics, distributions, etc.).
        missing_summary : str
            Human-readable summary of missing values per column.
        column_roles : dict
            Mapping of column names to inferred semantic roles.

        Returns
        -------
        str
            Cleaning recommendations (max ~300 words).
        """
        system_prompt = (
            "You are a data-cleaning assistant.  The user will provide a "
            "dataset profile, a missing-values summary, and column roles.  "
            "Your task:\n"
            "1. Suggest specific cleaning steps based on the profile.\n"
            "2. Be conservative and safe — prefer minimal transformations.\n"
            "3. Explain *why* each recommendation is made.\n"
            "4. Keep the response concise — max 300 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Dataset Profile\n{profile_summary}\n\n"
            f"## Missing Values\n{missing_summary}\n\n"
            f"## Column Roles\n{json.dumps(column_roles, indent=2)}"
        )
        response, provider = self.chat(system_prompt, user_prompt)
        logger.info(
            "generate_cleaning_recommendations completed via %s (%d chars)",
            provider,
            len(response),
        )
        return response

    def suggest_ml_strategy(
        self,
        objective: str,
        columns_info: str,
        dtypes_info: str,
        sample_data: str,
        target_name: str | None = None,
    ) -> dict[str, Any]:
        """Suggest an ML modelling strategy for the dataset.

        Parameters
        ----------
        objective : str
            Natural-language description of the analytical objective.
        columns_info : str
            Human-readable column list with descriptions.
        dtypes_info : str
            Data-type summary for all columns.
        sample_data : str
            A few representative rows (CSV or similar).
        target_name : str | None, optional
            User-specified target column.  The model may override this
            if the objective suggests a different target.

        Returns
        -------
        dict
            Parsed strategy with keys ``target_column``, ``problem_type``,
            ``recommended_features``, ``not_recommended_features``,
            ``reasoning``.  Falls back to a minimal dict when JSON parsing
            fails.
        """
        system_prompt = (
            "You are an ML strategy assistant.  The user will provide "
            "dataset context and an analytical objective.  Return a "
            "single JSON object — nothing else — with exactly these keys:\n"
            '- "target_column": the column the model should predict.\n'
            '- "problem_type": either "regression" or "classification".\n'
            '- "recommended_features": list of column names to use as features, with brief reasoning.\n'
            '- "not_recommended_features": list of column names to exclude, with brief reasoning.\n'
            '- "reasoning": a short paragraph explaining the overall strategy.\n'
            "Rules:\n"
            "- If the user supplies a target column name, prefer it unless "
            "the objective clearly implies a different one.\n"
            "- Be dataset-agnostic: reason from column names, types, and "
            "the objective only.\n"
            "- Return ONLY the JSON object, wrapped in ```json ... ``` "
            "fence if you wish."
        )

        target_hint = (
            f"\n\nThe user has specified the target column as: {target_name}"
            if target_name
            else ""
        )

        user_prompt = (
            f"## Objective\n{objective}\n"
            f"{target_hint}\n\n"
            f"## Columns\n{columns_info}\n\n"
            f"## Data Types\n{dtypes_info}\n\n"
            f"## Sample Data\n{sample_data}"
        )

        response, provider = self.chat(system_prompt, user_prompt)
        logger.info(
            "suggest_ml_strategy raw response via %s (%d chars)",
            provider,
            len(response),
        )

        # ---- Attempt JSON extraction ----
        strategy = self._extract_json(response)
        if strategy is None:
            logger.warning("JSON parse failed; returning raw response as reasoning.")
            strategy = {
                "target_column": target_name,
                "problem_type": "unknown",
                "recommended_features": [],
                "not_recommended_features": [],
                "reasoning": response,
            }
        return strategy

    # ------------------------------------------------------------------
    # Prediction explanation
    # ------------------------------------------------------------------
    def explain_prediction(
        self,
        inputs: dict,
        prediction: Any,
        model_info: dict,
    ) -> str:
        """Generate a human-readable explanation for a single prediction.

        Parameters
        ----------
        inputs : dict
            Feature-name → value mapping for the instance being predicted.
        prediction : Any
            The model's output (scalar, label, probability, etc.).
        model_info : dict
            Metadata about the model (type, target, features, metrics, …).

        Returns
        -------
        str
            Plain-language explanation including key feature contributions.
        """
        system_prompt = (
            "You are an ML explanation assistant.  The user will provide "
            "input feature values, a model prediction, and model metadata.  "
            "Your task:\n"
            "1. Explain the prediction in plain language.\n"
            "2. Identify which input features likely contributed most to "
            "the result and why.\n"
            "3. Note any features whose values are unusual or notable.\n"
            "4. Keep the explanation concise and accessible to a "
            "non-technical audience.\n"
            "Do NOT assume the domain of the dataset."
        )

        user_prompt = (
            f"## Model Info\n{json.dumps(model_info, indent=2, default=str)}\n\n"
            f"## Input Features\n{json.dumps(inputs, indent=2, default=str)}\n\n"
            f"## Prediction\n{json.dumps(prediction, default=str)}"
        )

        response, provider = self.chat(system_prompt, user_prompt)
        logger.info(
            "explain_prediction completed via %s (%d chars)",
            provider,
            len(response),
        )
        return response

    # ------------------------------------------------------------------
    # Cleaning results explanation
    # ------------------------------------------------------------------
    def explain_cleaning_results(
        self,
        cleaning_summary: dict,
        cleaning_logs: list[str],
        original_shape: tuple,
        cleaned_shape: tuple,
    ) -> str:
        """Generate a human-readable explanation of what the cleaning pipeline did.

        Parameters
        ----------
        cleaning_summary : dict
            Summary statistics of the cleaning steps performed (e.g.
            ``{"rows_removed": 50, "columns_dropped": ["col_x"],
            "imputations": {"col_y": "median"}, "memory_saved_mb": 2.3}``).
        cleaning_logs : list[str]
            Chronological log messages produced during cleaning.
        original_shape : tuple
            ``(rows, columns)`` of the dataset before cleaning.
        cleaned_shape : tuple
            ``(rows, columns)`` of the dataset after cleaning.

        Returns
        -------
        str
            Concise explanation covering rows removed, imputations performed,
            memory savings, and caveats the user should be aware of.
        """
        system_prompt = (
            "You are a data-cleaning assistant.  The user will provide a "
            "cleaning summary, cleaning logs, and dataset shapes before and "
            "after cleaning.  Your task:\n"
            "1. Summarise what the cleaning pipeline did in plain language.\n"
            "2. Highlight rows removed, imputations performed, and memory savings.\n"
            "3. Explain why each cleaning step matters for downstream analysis.\n"
            "4. Note any caveats or potential concerns the user should be aware of "
            "(e.g., data loss percentage, imputation bias).\n"
            "5. Keep the response concise — max 250 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Original Shape\n{original_shape}\n\n"
            f"## Cleaned Shape\n{cleaned_shape}\n\n"
            f"## Cleaning Summary\n{json.dumps(cleaning_summary, indent=2, default=str)}\n\n"
            f"## Cleaning Logs\n" + "\n".join(f"- {log}" for log in cleaning_logs)
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_cleaning_results completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_cleaning_results failed: %s", exc)
            return (
                "Could not generate cleaning explanation due to an error. "
                f"Rows: {original_shape[0]} → {cleaned_shape[0]}, "
                f"Columns: {original_shape[1]} → {cleaned_shape[1]}."
            )

    # ------------------------------------------------------------------
    # Chart explanation
    # ------------------------------------------------------------------
    def explain_chart(
        self,
        chart_type: str,
        column_name: str,
        stats: dict,
        dataset_shape: tuple,
    ) -> str:
        """Generate an explanation for a specific visualization.

        Parameters
        ----------
        chart_type : str
            Type of chart (e.g. ``"histogram"``, ``"box_plot"``,
            ``"bar_chart"``).
        column_name : str
            Name of the column being visualised.
        stats : dict
            Summary statistics for the column (e.g. mean, median, std,
            skewness, min, max, missing count, unique count).
        dataset_shape : tuple
            ``(rows, columns)`` of the full dataset.

        Returns
        -------
        str
            Explanation covering what the chart shows, notable patterns,
            skewness interpretation, outlier indicators, and data quality
            observations.
        """
        system_prompt = (
            "You are a data-visualisation assistant.  The user will provide "
            "a chart type, column name, summary statistics, and dataset "
            "shape.  Your task:\n"
            "1. Explain what the chart type reveals about this column.\n"
            "2. Identify notable patterns (skewness, bimodality, gaps).\n"
            "3. Interpret skewness if provided.\n"
            "4. Flag potential outliers based on min/max/percentile values.\n"
            "5. Comment on data quality (missing values, cardinality).\n"
            "6. Keep the response concise — max 200 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Chart Type\n{chart_type}\n\n"
            f"## Column\n{column_name}\n\n"
            f"## Dataset Shape\n{dataset_shape}\n\n"
            f"## Statistics\n{json.dumps(stats, indent=2, default=str)}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_chart completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_chart failed: %s", exc)
            return (
                f"Could not generate chart explanation for '{column_name}' "
                f"({chart_type})."
            )

    # ------------------------------------------------------------------
    # Correlation explanation
    # ------------------------------------------------------------------
    def explain_correlations(
        self,
        correlation_matrix_str: str,
        dataset_shape: tuple,
        top_features: list[str],
    ) -> str:
        """Analyse the correlation matrix and explain notable relationships.

        Parameters
        ----------
        correlation_matrix_str : str
            String representation of the correlation matrix (e.g. a
            formatted table or CSV-style text).
        dataset_shape : tuple
            ``(rows, columns)`` of the dataset.
        top_features : list[str]
            List of feature names considered most important or relevant.

        Returns
        -------
        str
            Concise explanation of notable positive/negative correlations,
            potential multicollinearity issues, and feature relationship
            insights.
        """
        system_prompt = (
            "You are a data-analysis assistant.  The user will provide a "
            "correlation matrix, dataset shape, and a list of top features.  "
            "Your task:\n"
            "1. Identify the strongest positive and negative correlations.\n"
            "2. Flag any pairs that suggest potential multicollinearity "
            "(|r| > 0.8).\n"
            "3. Explain what the notable relationships might mean in "
            "general terms.\n"
            "4. Comment on the top features and how they relate to others.\n"
            "5. Keep the response concise — max 250 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Dataset Shape\n{dataset_shape}\n\n"
            f"## Top Features\n{json.dumps(top_features)}\n\n"
            f"## Correlation Matrix\n{correlation_matrix_str}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_correlations completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_correlations failed: %s", exc)
            return "Could not generate correlation explanation due to an error."

    # ------------------------------------------------------------------
    # Model comparison explanation
    # ------------------------------------------------------------------
    def explain_model_comparison(
        self,
        evaluations: dict,
        problem_type: str,
        target_column: str,
        dataset_rows: int,
    ) -> str:
        """Compare model performances and provide recommendations.

        Parameters
        ----------
        evaluations : dict
            Mapping of model names to their evaluation metrics
            (e.g. ``{"Random Forest": {"accuracy": 0.92, "f1": 0.89}}``).
        problem_type : str
            ``"classification"`` or ``"regression"``.
        target_column : str
            Name of the target variable.
        dataset_rows : int
            Number of rows in the dataset used for evaluation.

        Returns
        -------
        str
            Comparison of model performances, explanation of why the best
            model won, notes on overfitting/underperformance, and
            actionable suggestions for improvement.
        """
        system_prompt = (
            "You are an ML evaluation assistant.  The user will provide "
            "evaluation results for multiple models, the problem type, "
            "target column, and dataset size.  Your task:\n"
            "1. Rank the models by performance and explain the ranking.\n"
            "2. Explain why the best-performing model likely won.\n"
            "3. Flag any model that appears to overfit or significantly "
            "underperform.\n"
            "4. Provide actionable suggestions for improvement "
            "(e.g., hyperparameter tuning, feature engineering, more data).\n"
            "5. Keep the response concise — max 300 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Problem Type\n{problem_type}\n\n"
            f"## Target Column\n{target_column}\n\n"
            f"## Dataset Rows\n{dataset_rows}\n\n"
            f"## Model Evaluations\n"
            f"{json.dumps(evaluations, indent=2, default=str)}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_model_comparison completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_model_comparison failed: %s", exc)
            return "Could not generate model comparison explanation due to an error."

    # ------------------------------------------------------------------
    # Feature importance explanation
    # ------------------------------------------------------------------
    def explain_feature_importance(
        self,
        feature_importance_df_str: str,
        top_n: int,
        problem_type: str,
        target_column: str,
    ) -> str:
        """Explain what the top features mean for predictions.

        Parameters
        ----------
        feature_importance_df_str : str
            String representation of the feature importance table
            (feature name and importance score).
        top_n : int
            Number of top features to focus on in the explanation.
        problem_type : str
            ``"classification"`` or ``"regression"``.
        target_column : str
            Name of the target variable being predicted.

        Returns
        -------
        str
            Explanation of top features, how each likely influences the
            target, and whether the ranking makes intuitive sense.
        """
        system_prompt = (
            "You are an ML feature-importance assistant.  The user will "
            "provide a feature importance table, the number of top features "
            "to focus on, the problem type, and the target column.  "
            "Your task:\n"
            "1. Explain what the top features mean for predictions.\n"
            "2. Describe how each top feature likely influences the target.\n"
            "3. Assess whether the importance ranking makes intuitive sense.\n"
            "4. Highlight any surprising or potentially misleading rankings.\n"
            "5. Keep the response concise — max 250 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Problem Type\n{problem_type}\n\n"
            f"## Target Column\n{target_column}\n\n"
            f"## Top N Features to Focus On\n{top_n}\n\n"
            f"## Feature Importance Table\n{feature_importance_df_str}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_feature_importance completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_feature_importance failed: %s", exc)
            return "Could not generate feature importance explanation due to an error."

    # ------------------------------------------------------------------
    # ML suitability assessment
    # ------------------------------------------------------------------
    def explain_ml_suitability(
        self,
        dataset_shape: tuple,
        target_column: str,
        unique_targets: int,
        missing_target_pct: float,
        problem_type: str,
        selected_features: list[str],
        excluded_features: list[str],
    ) -> str:
        """Assess whether the dataset/problem is suitable for ML.

        Parameters
        ----------
        dataset_shape : tuple
            ``(rows, columns)`` of the dataset.
        target_column : str
            Name of the target variable.
        unique_targets : int
            Number of unique values in the target column.
        missing_target_pct : float
            Percentage of missing values in the target column (0–100).
        problem_type : str
            ``"classification"`` or ``"regression"``.
        selected_features : list[str]
            Feature columns selected for modelling.
        excluded_features : list[str]
            Feature columns excluded from modelling.

        Returns
        -------
        str
            Suitability assessment with a clear score/recommendation,
            covering sufficient rows, low missing rate, meaningful target
            variation, and adequate feature count.
        """
        system_prompt = (
            "You are an ML readiness assistant.  The user will provide "
            "dataset characteristics, target information, and feature "
            "selection details.  Your task:\n"
            "1. Assess whether the dataset is suitable for ML on a scale "
            "of 1–10 (10 = ideal).\n"
            "2. Check for: sufficient rows, low missing rate in target, "
            "meaningful target variation, adequate feature count.\n"
            "3. Provide a clear recommendation (go / proceed with caution / "
            "not recommended) with justification.\n"
            "4. Suggest specific improvements if suitability is low.\n"
            "5. Keep the response concise — max 250 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Dataset Shape\n{dataset_shape}\n\n"
            f"## Target Column\n{target_column}\n\n"
            f"## Unique Target Values\n{unique_targets}\n\n"
            f"## Missing Target Percentage\n{missing_target_pct}%\n\n"
            f"## Problem Type\n{problem_type}\n\n"
            f"## Selected Features ({len(selected_features)})\n"
            f"{json.dumps(selected_features)}\n\n"
            f"## Excluded Features ({len(excluded_features)})\n"
            f"{json.dumps(excluded_features)}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_ml_suitability completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_ml_suitability failed: %s", exc)
            return "Could not generate ML suitability assessment due to an error."

    # ------------------------------------------------------------------
    # Excluded features explanation
    # ------------------------------------------------------------------
    def explain_excluded_features(
        self,
        excluded_features: list[str],
        exclusion_reasons: dict,
        target_column: str,
        all_columns: list[str],
    ) -> str:
        """Explain why each feature was excluded from modelling.

        Parameters
        ----------
        excluded_features : list[str]
            List of excluded feature names.
        exclusion_reasons : dict
            Mapping of feature name to the reason for exclusion
            (e.g. ``{"id": "identifier_column", "target_copy": "leakage_risk"}``).
        target_column : str
            Name of the target variable.
        all_columns : list[str]
            Full list of columns in the dataset.

        Returns
        -------
        str
            Explanation of why each feature was excluded, whether any
            exclusions might be incorrect, and guidance for informed
            override decisions.
        """
        system_prompt = (
            "You are an ML feature-selection assistant.  The user will "
            "provide a list of excluded features, the reasons for each "
            "exclusion, the target column, and the full column list.  "
            "Your task:\n"
            "1. Explain why each feature was excluded in plain language.\n"
            "2. Categorise exclusions (identifier, leakage risk, "
            "target-derived, high cardinality, high missingness, etc.).\n"
            "3. Flag any exclusions that might be incorrect or questionable.\n"
            "4. Advise the user on which exclusions they might want to "
            "override and the risks of doing so.\n"
            "5. Keep the response concise — max 250 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Target Column\n{target_column}\n\n"
            f"## All Columns ({len(all_columns)})\n{json.dumps(all_columns)}\n\n"
            f"## Excluded Features ({len(excluded_features)})\n"
            f"{json.dumps(excluded_features)}\n\n"
            f"## Exclusion Reasons\n"
            f"{json.dumps(exclusion_reasons, indent=2, default=str)}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_excluded_features completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_excluded_features failed: %s", exc)
            return "Could not generate excluded features explanation due to an error."

    # ------------------------------------------------------------------
    # Dataset quality assessment
    # ------------------------------------------------------------------
    def explain_dataset_quality(
        self,
        profile_summary: str,
        missing_summary: str,
        duplicate_count: int,
        id_columns: list[str],
        date_columns: list[str],
    ) -> str:
        """Provide an overall dataset quality assessment.

        Parameters
        ----------
        profile_summary : str
            Textual summary of the dataset profile (statistics, types, etc.).
        missing_summary : str
            Human-readable summary of missing values per column.
        duplicate_count : int
            Number of duplicate rows detected.
        id_columns : list[str]
            Columns identified as identifiers.
        date_columns : list[str]
            Columns identified as date/time columns.

        Returns
        -------
        str
            Quality assessment on a scale of 1–10 covering completeness,
            uniqueness, consistency, and readiness for analysis, with
            priority fix suggestions.
        """
        system_prompt = (
            "You are a data-quality assessment assistant.  The user will "
            "provide a dataset profile, missing values summary, duplicate "
            "count, and identified column types.  Your task:\n"
            "1. Rate the overall dataset quality on a scale of 1–10 "
            "(10 = excellent).\n"
            "2. Evaluate: completeness (missing values), uniqueness "
            "(duplicates), consistency (data types and formats), and "
            "readiness for analysis/ML.\n"
            "3. Identify the top priority fixes.\n"
            "4. Provide specific, actionable suggestions.\n"
            "5. Keep the response concise — max 300 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Dataset Profile\n{profile_summary}\n\n"
            f"## Missing Values\n{missing_summary}\n\n"
            f"## Duplicate Rows\n{duplicate_count}\n\n"
            f"## Identifier Columns\n{json.dumps(id_columns)}\n\n"
            f"## Date Columns\n{json.dumps(date_columns)}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "explain_dataset_quality completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("explain_dataset_quality failed: %s", exc)
            return "Could not generate dataset quality assessment due to an error."

    # ------------------------------------------------------------------
    # User guide generation
    # ------------------------------------------------------------------
    def generate_user_guide(
        self,
        dataset_shape: tuple,
        columns: list[str],
        column_roles: dict,
        problem_type: str,
        target_column: str,
    ) -> str:
        """Generate a step-by-step guide tailored to this specific dataset.

        Parameters
        ----------
        dataset_shape : tuple
            ``(rows, columns)`` of the dataset.
        columns : list[str]
            List of all column names.
        column_roles : dict
            Mapping of column names to inferred semantic roles
            (e.g. ``{"age": "numeric", "name": "categorical"}``).
        problem_type : str
            ``"classification"`` or ``"regression"`` (or ``"unknown"``).
        target_column : str
            Name of the target variable.

        Returns
        -------
        str
            Step-by-step guide telling the user what to do next in the
            application — which tabs to visit, what to look for, and
            recommended settings.
        """
        system_prompt = (
            "You are a guided-analytics assistant for an EDA & ML web "
            "application.  The application has these tabs/sections:\n"
            "- **Overview**: Dataset profile, column types, quality summary.\n"
            "- **Data Cleaning**: Missing value handling, outlier removal, "
            "imputation.\n"
            "- **Visualisation**: Histograms, box plots, bar charts, "
            "correlation heatmaps.\n"
            "- **ML Setup**: Problem type, target selection, feature "
            "selection.\n"
            "- **Model Training**: Train and compare multiple models.\n"
            "- **Prediction**: Make predictions on new data.\n\n"
            "The user will provide dataset details.  Your task:\n"
            "1. Generate a numbered step-by-step guide tailored to this "
            "specific dataset.\n"
            "2. Tell the user which tabs to visit and in what order.\n"
            "3. Highlight what to look for at each step.\n"
            "4. Suggest recommended settings (e.g., problem type, features).\n"
            "5. Keep the response concise — max 350 words.\n"
            "Do NOT assume the dataset domain."
        )
        user_prompt = (
            f"## Dataset Shape\n{dataset_shape}\n\n"
            f"## Columns ({len(columns)})\n{json.dumps(columns)}\n\n"
            f"## Column Roles\n{json.dumps(column_roles, indent=2, default=str)}\n\n"
            f"## Problem Type\n{problem_type}\n\n"
            f"## Target Column\n{target_column}"
        )
        try:
            response, provider = self.chat(system_prompt, user_prompt)
            logger.info(
                "generate_user_guide completed via %s (%d chars)",
                provider,
                len(response),
            )
            return response
        except Exception as exc:
            logger.error("generate_user_guide failed: %s", exc)
            return "Could not generate user guide due to an error."

    # ------------------------------------------------------------------
    # Internal utilities
    # ------------------------------------------------------------------
    @staticmethod
    def _extract_json(text: str) -> dict[str, Any] | None:
        """Try to parse a JSON object from *text*.

        Handles:
        * bare JSON
        * JSON wrapped in `````json … ````` fenced code blocks
        * JSON preceded/followed by arbitrary prose (best-effort)
        """
        # 1. Try fenced code block
        if "```json" in text:
            start = text.index("```json") + len("```json")
            end = text.find("```", start)
            if end != -1:
                candidate = text[start:end].strip()
                try:
                    return json.loads(candidate)
                except json.JSONDecodeError:
                    pass

        # 2. Try bare JSON — find the first '{' and last '}'
        brace_start = text.find("{")
        brace_end = text.rfind("}")
        if brace_start != -1 and brace_end > brace_start:
            candidate = text[brace_start : brace_end + 1]
            try:
                return json.loads(candidate)
            except json.JSONDecodeError:
                pass

        # 3. Last resort: try the full text
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return None
