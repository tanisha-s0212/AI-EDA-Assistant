"""
EDA Engine Module — Exploratory Data Analysis visualizations and statistics.

Provides dataset-agnostic charting (distributions, box plots, heatmaps,
categorical bars) and numeric profiling.  All plots are rendered to
in-memory PNG buffers and returned as base64 strings so they integrate
seamlessly with Streamlit or web frontends.
"""

import base64
import io
import logging
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

from modules.utils import is_identifier_column, setup_logging

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logger = setup_logging()

# ---------------------------------------------------------------------------
# Plotting style — use a clean grid-based style with a safe fallback
# ---------------------------------------------------------------------------

_AVAILABLE_STYLES = plt.style.available
_PREFERRED_STYLE = "seaborn-v0_8-whitegrid"
_FALLBACK_STYLE = "seaborn-whitegrid"

if _PREFERRED_STYLE in _AVAILABLE_STYLES:
    _STYLE = _PREFERRED_STYLE
elif _FALLBACK_STYLE in _AVAILABLE_STYLES:
    _STYLE = _FALLBACK_STYLE
else:
    _STYLE = _AVAILABLE_STYLES[0] if _AVAILABLE_STYLES else "default"


# ---------------------------------------------------------------------------
# Helper: cardinality ratio (used by _filter_numeric_columns)
# ---------------------------------------------------------------------------

def _cardinality_ratio(series: pd.Series) -> float:
    """Return unique / non-null count ratio for a series."""
    non_null = series.dropna()
    if len(non_null) == 0:
        return 0.0
    return non_null.nunique() / len(non_null)


# ===================================================================
# EDAEngine
# ===================================================================

class EDAEngine:
    """Exploratory Data Analysis engine built on top of a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Source dataset.
    identifier_columns : list[str] | None, optional
        Explicit list of columns to treat as identifiers.  If ``None``,
        identifiers are detected automatically via
        :func:`modules.utils.is_identifier_column`.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        identifier_columns: list[str] | None = None,
    ) -> None:
        self.df = df.copy()
        self.identifier_columns = set(identifier_columns or [])
        plt.style.use(_STYLE)
        logger.info(
            "EDAEngine initialised with shape %s, style '%s'.",
            self.df.shape,
            _STYLE,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _fig_to_base64(fig: plt.Figure) -> str:
        """Render a matplotlib figure to a base64-encoded PNG string."""
        buf = io.BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight", dpi=100)
        buf.seek(0)
        b64 = base64.b64encode(buf.read()).decode("utf-8")
        plt.close(fig)
        return b64

    def _filter_numeric_columns(self) -> list[str]:
        """Return numeric columns excluding identifiers.

        A numeric column is excluded when:
        * It appears in ``self.identifier_columns``, **or**
        * It passes :func:`is_identifier_column` **and** its name contains
          common identifier substrings (id, code, no, num, etc.).  Purely
          continuous numeric features (e.g. age, temperature) are retained
          even when they have high cardinality, since high uniqueness is
          expected for float-valued measurements.
        """
        _id_name_hints = (
            "id", "code", "no", "num", "number", "key", "uuid", "identifier"
        )
        filtered: list[str] = []
        for col in self.df.select_dtypes(include="number").columns:
            if col in self.identifier_columns:
                continue
            # Only treat a numeric column as identifier when the name
            # explicitly suggests it AND cardinality is high.
            if is_identifier_column(self.df[col]):
                name_lower = str(col).lower()
                has_id_hint = any(hint in name_lower for hint in _id_name_hints)
                if has_id_hint:
                    continue
            filtered.append(col)
        logger.debug(
            "Filtered numeric columns (%d of %d numeric total).",
            len(filtered),
            len(self.df.select_dtypes(include="number").columns),
        )
        return filtered

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def get_numeric_stats(self) -> pd.DataFrame:
        """Compute descriptive statistics for every (non-identifier) numeric column.

        Returns a DataFrame indexed by column name with columns:

        ``count, missing_percent, mean, std, min, 25%, 50%, 75%, max,
        skewness, kurtosis``.
        """
        numeric_cols = self._filter_numeric_columns()
        if not numeric_cols:
            return pd.DataFrame()

        rows: list[dict[str, Any]] = []
        for col in numeric_cols:
            series = self.df[col].dropna()
            count = len(series)
            total = len(self.df[col])
            missing_pct = round((total - count) / total * 100, 2) if total else 0.0

            descriptive = series.describe()
            skewness = float(stats.skew(series)) if count > 2 else float("nan")
            kurtosis = float(stats.kurtosis(series)) if count > 3 else float("nan")

            rows.append({
                "count": int(count),
                "missing_percent": missing_pct,
                "mean": descriptive.get("mean", float("nan")),
                "std": descriptive.get("std", float("nan")),
                "min": descriptive.get("min", float("nan")),
                "25%": descriptive.get("25%", float("nan")),
                "50%": descriptive.get("50%", float("nan")),
                "75%": descriptive.get("75%", float("nan")),
                "max": descriptive.get("max", float("nan")),
                "skewness": skewness,
                "kurtosis": kurtosis,
            })

        result = pd.DataFrame(rows, index=numeric_cols)
        result.index.name = "column"
        logger.info("Computed numeric stats for %d columns.", len(result))
        return result

    # ------------------------------------------------------------------
    # Correlation
    # ------------------------------------------------------------------

    def get_correlation_matrix(
        self,
        max_features: int = 20,
    ) -> pd.DataFrame | None:
        """Compute Pearson correlation for numeric columns.

        Only the *max_features* columns with the highest variance are
        included to keep the matrix manageable.

        Returns ``None`` when fewer than 2 numeric features are available.
        """
        numeric_cols = self._filter_numeric_columns()
        if len(numeric_cols) < 2:
            logger.info(
                "Skipping correlation matrix — only %d numeric columns.",
                len(numeric_cols),
            )
            return None

        # Select top columns by variance
        variances = self.df[numeric_cols].var().sort_values(ascending=False)
        selected = variances.head(max_features).index.tolist()

        corr = self.df[selected].corr(method="pearson")
        logger.info(
            "Correlation matrix computed for %d features (of %d total, max %d).",
            len(selected),
            len(numeric_cols),
            max_features,
        )
        return corr

    # ------------------------------------------------------------------
    # Plotting — distributions
    # ------------------------------------------------------------------

    def plot_distributions(
        self,
        max_cols: int = 8,
    ) -> list[dict[str, str]]:
        """Generate histogram + KDE plots for numeric columns.

        Returns a list of dicts ``{"column": str, "image_base64": str}``.
        """
        numeric_cols = self._filter_numeric_columns()
        numeric_cols = numeric_cols[:max_cols]
        results: list[dict[str, str]] = []

        for col in numeric_cols:
            series = self.df[col].dropna()
            if series.empty:
                continue

            fig, ax = plt.subplots(figsize=(8, 5))
            sns.histplot(series, kde=True, ax=ax, color="#4C72B0", edgecolor="white")
            ax.set_title(f"Distribution of {col}", fontsize=13, fontweight="bold")
            ax.set_xlabel(col, fontsize=11)
            ax.set_ylabel("Frequency", fontsize=11)
            ax.tick_params(labelsize=9)
            plt.tight_layout()

            results.append({
                "column": col,
                "image_base64": self._fig_to_base64(fig),
            })

        logger.info("Generated %d distribution plots.", len(results))
        return results

    # ------------------------------------------------------------------
    # Plotting — box plots
    # ------------------------------------------------------------------

    def plot_boxplots(
        self,
        max_cols: int = 8,
    ) -> list[dict[str, str]]:
        """Generate box plots for numeric columns.

        Returns a list of dicts ``{"column": str, "image_base64": str}``.
        """
        numeric_cols = self._filter_numeric_columns()
        numeric_cols = numeric_cols[:max_cols]
        results: list[dict[str, str]] = []

        for col in numeric_cols:
            series = self.df[col].dropna()
            if series.empty:
                continue

            fig, ax = plt.subplots(figsize=(7, 5))
            sns.boxplot(x=series, ax=ax, color="#4C72B0", width=0.5,
                        flierprops=dict(marker="o", markersize=4, alpha=0.5))
            ax.set_title(f"Box Plot of {col}", fontsize=13, fontweight="bold")
            ax.set_xlabel(col, fontsize=11)
            ax.tick_params(labelsize=9)
            plt.tight_layout()

            results.append({
                "column": col,
                "image_base64": self._fig_to_base64(fig),
            })

        logger.info("Generated %d box plots.", len(results))
        return results

    # ------------------------------------------------------------------
    # Plotting — correlation heatmap
    # ------------------------------------------------------------------

    def plot_correlation_heatmap(
        self,
        max_features: int = 15,
    ) -> dict[str, str] | None:
        """Generate an annotated correlation heatmap.

        Returns ``{"image_base64": str}`` or ``None`` if fewer than 2
        numeric features are available.
        """
        corr = self.get_correlation_matrix(max_features=max_features)
        if corr is None:
            return None

        fig, ax = plt.subplots(figsize=(10, 8))
        mask = np.triu(np.ones_like(corr, dtype=bool), k=1)
        sns.heatmap(
            corr,
            mask=mask,
            annot=True,
            fmt=".2f",
            cmap="RdBu_r",
            center=0,
            square=True,
            linewidths=0.5,
            ax=ax,
            annot_kws={"size": 7},
            cbar_kws={"shrink": 0.8},
        )
        ax.set_title(
            "Pearson Correlation Heatmap",
            fontsize=14,
            fontweight="bold",
            pad=15,
        )
        ax.tick_params(labelsize=8)
        plt.tight_layout()

        logger.info("Generated correlation heatmap for %d features.", corr.shape[0])
        return {"image_base64": self._fig_to_base64(fig)}

    # ------------------------------------------------------------------
    # Plotting — categorical distributions
    # ------------------------------------------------------------------

    def plot_categorical_distributions(
        self,
        max_cols: int = 6,
        max_categories: int = 10,
    ) -> list[dict[str, str]]:
        """Generate bar charts for the top categories of each categorical column.

        Parameters
        ----------
        max_cols : int
            Maximum number of categorical columns to chart.
        max_categories : int
            Maximum number of top categories shown per column.

        Returns a list of dicts ``{"column": str, "image_base64": str}``.
        """
        cat_cols = self.df.select_dtypes(include=["object", "category", "string"]).columns
        cat_cols = [c for c in cat_cols if c not in self.identifier_columns][:max_cols]
        results: list[dict[str, str]] = []

        for col in cat_cols:
            series = self.df[col].dropna()
            if series.empty:
                continue

            top_values = series.value_counts().head(max_categories)
            if top_values.empty:
                continue

            fig, ax = plt.subplots(figsize=(8, 5))
            n_colors = min(len(top_values), max_categories)
            color_palette = sns.color_palette("husl", n_colors=n_colors)
            sns.barplot(
                x=top_values.values,
                y=top_values.index,
                ax=ax,
                hue=top_values.index,
                palette=color_palette,
                edgecolor="white",
                legend=False,
            )
            ax.set_title(f"Top Categories: {col}", fontsize=13, fontweight="bold")
            ax.set_xlabel("Count", fontsize=11)
            ax.set_ylabel(col, fontsize=11)
            ax.tick_params(labelsize=9)
            plt.tight_layout()

            results.append({
                "column": col,
                "image_base64": self._fig_to_base64(fig),
            })

        logger.info("Generated %d categorical distribution plots.", len(results))
        return results

    # ------------------------------------------------------------------
    # AI chart summary helper
    # ------------------------------------------------------------------

    @staticmethod
    def generate_ai_chart_summary(
        chart_type: str,
        column: str,
        stats: dict[str, Any],
    ) -> str:
        """Return a concise summary string describing a chart for AI elaboration.

        Parameters
        ----------
        chart_type : str
            One of ``"distribution"``, ``"boxplot"``, ``"categorical"``.
        column : str
            Column name the chart represents.
        stats : dict
            Key-value pairs of statistics relevant to the chart (e.g.
            ``mean``, ``std``, ``skewness``, ``unique_count``, etc.).

        Returns
        -------
        str
            A human-readable summary string.
        """
        safe_stats = {k: v for k, v in stats.items() if not (isinstance(v, float) and np.isnan(v))}
        parts: list[str] = []

        if chart_type == "distribution":
            mean = safe_stats.get("mean")
            std = safe_stats.get("std")
            skewness = safe_stats.get("skewness")
            kurtosis = safe_stats.get("kurtosis")
            min_val = safe_stats.get("min")
            max_val = safe_stats.get("max")

            parts.append(f"The distribution of '{column}' has a mean of {mean:.2f}" if mean is not None else f"The distribution of '{column}'")
            if std is not None:
                parts.append(f"a standard deviation of {std:.2f}")
            if min_val is not None and max_val is not None:
                parts.append(f"ranging from {min_val:.2f} to {max_val:.2f}")
            if skewness is not None:
                if abs(skewness) < 0.5:
                    skew_desc = "approximately symmetric"
                elif skewness > 0:
                    skew_desc = "right-skewed (positively skewed)"
                else:
                    skew_desc = "left-skewed (negatively skewed)"
                parts.append(f"and is {skew_desc} (skewness = {skewness:.3f})")
            if kurtosis is not None:
                if kurtosis > 1:
                    parts.append(f"It has heavier tails than a normal distribution (excess kurtosis = {kurtosis:.3f}), indicating potential outliers.")
                elif kurtosis < -1:
                    parts.append(f"It has lighter tails than a normal distribution (excess kurtosis = {kurtosis:.3f}), indicating a relatively uniform spread.")
                else:
                    parts.append(f"It has near-normal tail weight (excess kurtosis = {kurtosis:.3f}).")

        elif chart_type == "boxplot":
            median = safe_stats.get("50%")
            q1 = safe_stats.get("25%")
            q3 = safe_stats.get("75%")
            iqr = (q3 - q1) if q1 is not None and q3 is not None else None
            min_val = safe_stats.get("min")
            max_val = safe_stats.get("max")

            parts.append(f"The box plot of '{column}' shows")
            if median is not None:
                parts.append(f"a median of {median:.2f}")
            if q1 is not None and q3 is not None:
                parts.append(f"with an interquartile range (IQR) of {q1:.2f} to {q3:.2f}")
            if iqr is not None:
                parts.append(f"(IQR = {iqr:.2f})")
            if min_val is not None and max_val is not None:
                parts.append(f"The observed range extends from {min_val:.2f} to {max_val:.2f}.")
            else:
                parts.append(".")

        elif chart_type == "categorical":
            unique = safe_stats.get("unique_count")
            top_val = safe_stats.get("top_value")
            top_count = safe_stats.get("top_count")
            missing_pct = safe_stats.get("missing_percent")

            parts.append(f"The categorical distribution of '{column}'")
            if unique is not None:
                parts.append(f"contains {unique} unique categories")
            if top_val is not None and top_count is not None:
                parts.append(f"with the most frequent value being '{top_val}' ({top_count} occurrences)")
            if missing_pct is not None and missing_pct > 0:
                parts.append(f"and {missing_pct:.1f}% missing values")
            parts.append(".")

        else:
            parts.append(f"Chart of type '{chart_type}' for column '{column}'.")

        return " ".join(parts)


# ===================================================================
# Standalone narrative generator
# ===================================================================

def generate_eda_narrative(
    numeric_stats: pd.DataFrame,
    correlation_df: pd.DataFrame | None,
    missing_df: pd.DataFrame | None,
    total_rows: int,
) -> str:
    """Generate a comprehensive text narrative summarising overall EDA findings.

    The narrative covers:

    * Overview of numeric feature distributions (skewness patterns).
    * Notable correlations (strong positive / negative pairs).
    * Missing data patterns.
    * Data quality concerns (high skew, zero-variance columns, etc.).

    Parameters
    ----------
    numeric_stats : pd.DataFrame
        Output of :meth:`EDAEngine.get_numeric_stats`.  Expected to have
        a ``skewness`` and ``kurtosis`` column.
    correlation_df : pd.DataFrame | None
        Pearson correlation matrix (or ``None`` if unavailable).
    missing_df : pd.DataFrame | None
        Missing-data summary DataFrame with columns ``Column``,
        ``Missing_Count``, ``Missing_Percent`` (or ``None``).
    total_rows : int
        Total number of rows in the original dataset.

    Returns
    -------
    str
        Multi-line narrative suitable for display or further AI elaboration.
    """
    lines: list[str] = []
    lines.append("## Exploratory Data Analysis — Narrative Summary\n")

    # --- 1. Dataset size overview ---
    lines.append(f"The dataset contains **{total_rows:,}** rows.")

    # --- 2. Numeric feature distributions ---
    if numeric_stats is not None and not numeric_stats.empty:
        n_numeric = len(numeric_stats)
        lines.append(f"\n### Numeric Feature Distributions ({n_numeric} features)\n")

        # Skewness analysis
        skew_vals = numeric_stats["skewness"].dropna()
        right_skewed = (skew_vals > 0.5).sum()
        left_skewed = (skew_vals < -0.5).sum()
        symmetric = ((skew_vals >= -0.5) & (skew_vals <= 0.5)).sum()

        lines.append(f"- **Symmetric (|skew| < 0.5):** {int(symmetric)} features")
        lines.append(f"- **Right-skewed (skew > 0.5):** {int(right_skewed)} features")
        lines.append(f"- **Left-skewed (skew < -0.5):** {int(left_skewed)} features")

        # Flag extreme skewness
        extreme_right = skew_vals[skew_vals > 2.0]
        extreme_left = skew_vals[skew_vals < -2.0]
        if len(extreme_right) > 0:
            cols_str = ", ".join(extreme_right.index.tolist()[:10])
            lines.append(
                f"\n  ⚠️ **Highly right-skewed features** (skew > 2): {cols_str}. "
                f"These may benefit from log or Box-Cox transformations."
            )
        if len(extreme_left) > 0:
            cols_str = ", ".join(extreme_left.index.tolist()[:10])
            lines.append(
                f"\n  ⚠️ **Highly left-skewed features** (skew < -2): {cols_str}. "
                f"Consider transformation to reduce asymmetry."
            )

        # Zero-variance / near-zero-variance warning
        std_vals = numeric_stats["std"].dropna()
        zero_var = std_vals[std_vals < 1e-10]
        if len(zero_var) > 0:
            cols_str = ", ".join(zero_var.index.tolist())
            lines.append(
                f"\n  ⚠️ **Zero / near-zero variance features:** {cols_str}. "
                f"These carry no useful information for modelling."
            )

        # Kurtosis: heavy tails
        kurt_vals = numeric_stats["kurtosis"].dropna()
        heavy_tailed = kurt_vals[kurt_vals > 3.0]
        if len(heavy_tailed) > 0:
            cols_str = ", ".join(heavy_tailed.index.tolist()[:10])
            lines.append(
                f"\n  ℹ️ **Heavy-tailed features** (excess kurtosis > 3): {cols_str}. "
                f"These have more extreme outliers than a normal distribution."
            )

    else:
        lines.append("\n### Numeric Feature Distributions\n")
        lines.append("No numeric features were available for distribution analysis.")

    # --- 3. Notable correlations ---
    if correlation_df is not None and correlation_df.shape[0] >= 2:
        lines.append("\n### Notable Correlations\n")

        # Extract upper-triangle pairs
        n_feat = correlation_df.shape[0]
        strong_pos: list[tuple[str, str, float]] = []
        strong_neg: list[tuple[str, str, float]] = []
        moderate_pos: list[tuple[str, str, float]] = []
        moderate_neg: list[tuple[str, str, float]] = []

        for i in range(n_feat):
            for j in range(i + 1, n_feat):
                col_i = correlation_df.index[i]
                col_j = correlation_df.columns[j]
                val = correlation_df.iloc[i, j]
                if pd.isna(val):
                    continue
                pair = (col_i, col_j, round(float(val), 3))
                if val >= 0.7:
                    strong_pos.append(pair)
                elif val <= -0.7:
                    strong_neg.append(pair)
                elif val >= 0.4:
                    moderate_pos.append(pair)
                elif val <= -0.4:
                    moderate_neg.append(pair)

        if strong_pos:
            strong_pos.sort(key=lambda x: x[2], reverse=True)
            lines.append("**Strong positive correlations (r ≥ 0.7):**")
            for col_i, col_j, val in strong_pos[:8]:
                lines.append(f"  - {col_i} ↔ {col_j}: r = {val}")
            if len(strong_pos) > 8:
                lines.append(f"  - …and {len(strong_pos) - 8} more.")

        if strong_neg:
            strong_neg.sort(key=lambda x: x[2])
            lines.append("\n**Strong negative correlations (r ≤ -0.7):**")
            for col_i, col_j, val in strong_neg[:8]:
                lines.append(f"  - {col_i} ↔ {col_j}: r = {val}")
            if len(strong_neg) > 8:
                lines.append(f"  - …and {len(strong_neg) - 8} more.")

        if moderate_pos and not strong_pos:
            moderate_pos.sort(key=lambda x: x[2], reverse=True)
            lines.append("**Moderate positive correlations (0.4 ≤ r < 0.7):**")
            for col_i, col_j, val in moderate_pos[:8]:
                lines.append(f"  - {col_i} ↔ {col_j}: r = {val}")
            if len(moderate_pos) > 8:
                lines.append(f"  - …and {len(moderate_pos) - 8} more.")

        if moderate_neg and not strong_neg:
            moderate_neg.sort(key=lambda x: x[2])
            lines.append("\n**Moderate negative correlations (-0.7 < r ≤ -0.4):**")
            for col_i, col_j, val in moderate_neg[:8]:
                lines.append(f"  - {col_i} ↔ {col_j}: r = {val}")
            if len(moderate_neg) > 8:
                lines.append(f"  - …and {len(moderate_neg) - 8} more.")

        if not strong_pos and not strong_neg and not moderate_pos and not moderate_neg:
            lines.append("No strong or moderate correlations (|r| ≥ 0.4) were detected between features.")

        if len(strong_pos) + len(strong_neg) > 0:
            lines.append(
                "\n> **Note:** Highly correlated features may cause multicollinearity in linear models. "
                "Consider PCA or feature selection if needed."
            )

    else:
        lines.append("\n### Notable Correlations\n")
        lines.append("Insufficient numeric features for correlation analysis (need ≥ 2).")

    # --- 4. Missing data patterns ---
    if missing_df is not None and not missing_df.empty:
        n_missing_cols = len(missing_df)
        lines.append(f"\n### Missing Data ({n_missing_cols} columns affected)\n")

        # Severity buckets
        critical = missing_df[missing_df["Missing_Percent"] >= 50]
        moderate = missing_df[(missing_df["Missing_Percent"] >= 10) & (missing_df["Missing_Percent"] < 50)]
        minor = missing_df[missing_df["Missing_Percent"] < 10]

        if len(critical) > 0:
            lines.append(f"**⚠️ Critical (> 50% missing) — {len(critical)} column(s):**")
            for _, row in critical.iterrows():
                lines.append(
                    f"  - {row['Column']}: {row['Missing_Percent']}% missing "
                    f"({int(row['Missing_Count']):,} values)"
                )

        if len(moderate) > 0:
            lines.append(f"\n**Moderate (10–50% missing) — {len(moderate)} column(s):**")
            for _, row in moderate.iterrows():
                lines.append(
                    f"  - {row['Column']}: {row['Missing_Percent']}% missing "
                    f"({int(row['Missing_Count']):,} values)"
                )

        if len(minor) > 0:
            lines.append(f"\n**Minor (< 10% missing) — {len(minor)} column(s):**")
            for _, row in minor.iterrows():
                lines.append(
                    f"  - {row['Column']}: {row['Missing_Percent']}% missing "
                    f"({int(row['Missing_Count']):,} values)"
                )

        if len(critical) > 0:
            lines.append(
                "\n> **Recommendation:** Columns with > 50% missing data should be reviewed carefully. "
                "Dropping them or using advanced imputation (e.g., model-based) may be appropriate."
            )

    else:
        lines.append("\n### Missing Data\n")
        lines.append("No missing values detected — the dataset is complete.")

    # --- 5. Data quality summary ---
    lines.append("\n### Data Quality Summary\n")
    quality_flags: list[str] = []

    if numeric_stats is not None and not numeric_stats.empty:
        missing_in_stats = numeric_stats["missing_percent"]
        cols_with_missing = (missing_in_stats > 0).sum()
        if cols_with_missing > 0:
            quality_flags.append(f"{int(cols_with_missing)} numeric columns have missing values")

        skew_vals = numeric_stats["skewness"].dropna()
        if (abs(skew_vals) > 2.0).any():
            quality_flags.append("some features have extreme skewness (|skew| > 2)")

        std_vals = numeric_stats["std"].dropna()
        if (std_vals < 1e-10).any():
            quality_flags.append("zero-variance columns detected")

        kurt_vals = numeric_stats["kurtosis"].dropna()
        if (kurt_vals > 5.0).any():
            quality_flags.append("features with very heavy tails (kurtosis > 5)")

    if correlation_df is not None:
        n_feat = correlation_df.shape[0]
        multicollinear = 0
        for i in range(n_feat):
            for j in range(i + 1, n_feat):
                val = correlation_df.iloc[i, j]
                if not pd.isna(val) and abs(val) >= 0.9:
                    multicollinear += 1
        if multicollinear > 0:
            quality_flags.append(f"{multicollinear} feature pair(s) are highly collinear (|r| ≥ 0.9)")

    if missing_df is not None and not missing_df.empty:
        critical = missing_df[missing_df["Missing_Percent"] >= 50]
        if len(critical) > 0:
            quality_flags.append(f"{len(critical)} column(s) have > 50% missing data")

    if quality_flags:
        lines.append("The following data quality concerns were identified:")
        for flag in quality_flags:
            lines.append(f"  - ⚠️ {flag}")
    else:
        lines.append("No significant data quality concerns were identified. The dataset appears well-structured.")

    return "\n".join(lines)
