"""Data Understanding Module — Universal data profiling for arbitrary tabular datasets."""

import pandas as pd
import numpy as np
import io
import logging
from typing import Any

from modules.utils import setup_logging, format_bytes, detect_column_roles, detect_date_columns, is_identifier_column

logger = setup_logging()


class DataProfiler:
    """Provides comprehensive, dataset-agnostic profiling of a pandas DataFrame."""

    def __init__(self, df: pd.DataFrame) -> None:
        self.df = df.copy()
        self._shape = df.shape
        self._memory_bytes = int(df.memory_usage(deep=True).sum())
        self._column_roles: dict[str, str] | None = None
        self._date_cols: list[str] | None = None
        self._id_cols: list[str] | None = None

    def get_shape(self) -> tuple[int, int]:
        """Return (rows, columns)."""
        return self._shape

    def get_memory_usage(self) -> dict[str, Any]:
        """Return total memory, formatted string, and top-10 columns by memory."""
        per_col = self.df.memory_usage(deep=True)
        top_cols = per_col.sort_values(ascending=False).head(10)
        top_list = [
            {"column": col, "memory_bytes": int(mem), "memory_formatted": format_bytes(int(mem))}
            for col, mem in top_cols.items()
        ]
        return {
            "total_bytes": self._memory_bytes,
            "total_formatted": format_bytes(self._memory_bytes),
            "per_column_top10": top_list,
        }

    def get_duplicate_count(self) -> int:
        """Count of exact duplicate rows."""
        return int(self.df.duplicated().sum())

    def get_missing_summary(self) -> pd.DataFrame:
        """DataFrame with Column, Missing_Count, Missing_Percent, Dtype. Sorted desc."""
        total = len(self.df)
        missing = self.df.isnull().sum()
        missing = missing[missing > 0].sort_values(ascending=False)
        if missing.empty:
            return pd.DataFrame(columns=["Column", "Missing_Count", "Missing_Percent", "Dtype"])
        records = []
        for col, cnt in missing.items():
            records.append({
                "Column": col,
                "Missing_Count": int(cnt),
                "Missing_Percent": round(cnt / total * 100, 2),
                "Dtype": str(self.df[col].dtype),
            })
        return pd.DataFrame(records)

    def get_dtype_summary(self) -> pd.DataFrame:
        """DataFrame with Column, Dtype, Unique_Count, Sample_Values."""
        records = []
        for col in self.df.columns:
            unique_count = self.df[col].nunique()
            samples = self.df[col].dropna().unique()[:3]
            sample_str = ", ".join(str(v) for v in samples)
            records.append({
                "Column": col,
                "Dtype": str(self.df[col].dtype),
                "Unique_Count": int(unique_count),
                "Sample_Values": sample_str,
            })
        return pd.DataFrame(records)

    def get_column_roles(self) -> dict[str, str]:
        """Classify each column: identifier, numeric, categorical, boolean, datetime."""
        if self._column_roles is None:
            self._column_roles = detect_column_roles(self.df)
            logger.info("Column roles detected: %s", dict(self._column_roles))
        return self._column_roles

    def get_date_columns(self) -> list[str]:
        """Detect date-like columns."""
        if self._date_cols is None:
            self._date_cols = detect_date_columns(self.df)
            logger.info("Date columns detected: %s", self._date_cols)
        return self._date_cols

    def get_identifier_columns(self) -> list[str]:
        """Columns likely to be identifiers (IDs, codes)."""
        if self._id_cols is None:
            self._id_cols = [
                col for col in self.df.columns
                if is_identifier_column(self.df[col])
            ]
            logger.info("Identifier columns detected: %s", self._id_cols)
        return self._id_cols

    def get_info_capture(self) -> str:
        """Capture df.info() output as string."""
        buffer = io.StringIO()
        self.df.info(buf=buffer)
        return buffer.getvalue()

    def get_full_profile(self) -> dict[str, Any]:
        """Return comprehensive profile dict."""
        roles = self.get_column_roles()
        role_dist: dict[str, int] = {}
        for role in roles.values():
            role_dist[role] = role_dist.get(role, 0) + 1

        return {
            "shape": self.get_shape(),
            "rows": self._shape[0],
            "columns": self._shape[1],
            "memory": self.get_memory_usage(),
            "duplicate_count": self.get_duplicate_count(),
            "missing_summary": self.get_missing_summary(),
            "dtype_summary": self.get_dtype_summary(),
            "column_roles": roles,
            "role_distribution": role_dist,
            "date_columns": self.get_date_columns(),
            "identifier_columns": self.get_identifier_columns(),
            "info_capture": self.get_info_capture(),
            "column_names": list(self.df.columns),
        }


def generate_profile_summary(profile: dict[str, Any]) -> str:
    """Generate a human-readable text summary from the profile dict."""
    lines: list[str] = []

    rows, cols = profile.get("shape", (0, 0))
    lines.append(f"## Dataset Profile Summary")
    lines.append(f"**Shape:** {rows:,} rows × {cols} columns")

    mem = profile.get("memory", {})
    lines.append(f"**Memory Usage:** {mem.get('total_formatted', 'N/A')}")

    # Dtypes distribution
    role_dist = profile.get("role_distribution", {})
    if role_dist:
        role_str = ", ".join(f"{k}: {v}" for k, v in sorted(role_dist.items()))
        lines.append(f"**Column Roles:** {role_str}")

    # Missing values
    missing_df = profile.get("missing_summary")
    if missing_df is not None and not missing_df.empty:
        lines.append(f"\n**Missing Values ({len(missing_df)} columns affected):**")
        for _, row in missing_df.head(10).iterrows():
            lines.append(f"  - {row['Column']}: {row['Missing_Count']} ({row['Missing_Percent']}%)")
    else:
        lines.append("\n**Missing Values:** None — all columns are complete.")

    # Duplicates
    dup = profile.get("duplicate_count", 0)
    if dup > 0:
        lines.append(f"\n**⚠️ Duplicate Rows:** {dup} exact duplicates detected.")
    else:
        lines.append(f"\n**Duplicate Rows:** 0 — no exact duplicates found.")

    # Identifiers
    id_cols = profile.get("identifier_columns", [])
    if id_cols:
        lines.append(f"\n**Identifier Columns:** {', '.join(id_cols)}")

    # Date columns
    date_cols = profile.get("date_columns", [])
    if date_cols:
        lines.append(f"\n**Date Columns Detected:** {', '.join(date_cols)}")

    # Dtype summary top entries
    dtype_df = profile.get("dtype_summary")
    if dtype_df is not None and not dtype_df.empty:
        lines.append(f"\n**Column Types (first 15):**")
        for _, row in dtype_df.head(15).iterrows():
            lines.append(f"  - {row['Column']} [{row['Dtype']}] — {row['Unique_Count']} unique — samples: {row['Sample_Values']}")

    return "\n".join(lines)
