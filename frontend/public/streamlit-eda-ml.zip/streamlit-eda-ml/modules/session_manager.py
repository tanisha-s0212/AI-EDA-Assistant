"""
session_manager.py

Manages Streamlit session state for the AI-Assisted EDA & ML Platform.
This module is dataset-agnostic and provides a centralized interface for
reading, writing, initializing, and resetting session state across the
entire application.

All session state keys are defined as module-level constants so that every
other module references a single source of truth.
"""

from __future__ import annotations

import logging
from typing import Any

import streamlit as st

# ---------------------------------------------------------------------------
# Session-state key constants
# ---------------------------------------------------------------------------
DATASET_KEY: str = "raw_dataset"
"""Pandas DataFrame of the most recently uploaded raw dataset."""

CLEANED_KEY: str = "cleaned_dataset"
"""Pandas DataFrame after data-cleaning operations."""

CLEANING_LOGS_KEY: str = "cleaning_logs"
"""List[str] of human-readable cleaning operation log entries."""

CLEANING_SUMMARY_KEY: str = "cleaning_summary"
"""Dict summarising what was cleaned (e.g. columns dropped, imputed, etc.)."""

AI_STRATEGY_KEY: str = "ai_feature_strategy"
"""Dict / object returned by the AI provider describing feature-engineering
strategy recommendations for the active dataset."""

ML_PLAN_KEY: str = "ml_plan"
"""Dict / object describing the ML modelling plan (algorithm selection,
hyper-parameter ranges, evaluation metrics, etc.)."""

ML_RESULTS_KEY: str = "ml_results"
"""Dict / object containing the results of the last ML training run."""

SELECTED_FEATURES_KEY: str = "selected_features"
"""List[str] of column names the user (or AI) selected for modelling."""

UPLOADED_MODEL_KEY: str = "uploaded_model_package"
"""Dict / object wrapping an externally uploaded model + its metadata."""

PREDICTION_HISTORY_KEY: str = "prediction_history"
"""List[Dict] of individual prediction requests and their outputs."""

ACTIVE_DATASET_KEY: str = "active_dataset_key"
"""Unique identifier (e.g. file hash or name) of the currently active
dataset.  Used to detect dataset switches."""

FILE_HASH_KEY: str = "file_hash"
"""SHA-256 (or similar) hash of the uploaded file for change detection."""

ORIGINAL_COLUMNS_KEY: str = "original_columns"
"""List[str] of column names as they appeared in the raw uploaded dataset."""

ENGINEERED_COLUMNS_KEY: str = "engineered_columns"
"""List[str] of column names created during feature engineering."""

AI_FAILED_PROVIDERS_KEY: str = "ai_failed_providers"
"""Set[str] of AI provider identifiers that have recently failed, so the
application can skip them on subsequent retries."""

# ---------------------------------------------------------------------------
# Internal grouping helpers
# ---------------------------------------------------------------------------

# Keys that are tightly coupled to the *current* dataset and must be
# cleared whenever the user uploads a new file or switches datasets.
_DATASET_BOUND_KEYS: list[str] = [
    DATASET_KEY,
    CLEANED_KEY,
    CLEANING_LOGS_KEY,
    CLEANING_SUMMARY_KEY,
    AI_STRATEGY_KEY,
    SELECTED_FEATURES_KEY,
    ACTIVE_DATASET_KEY,
    FILE_HASH_KEY,
    ORIGINAL_COLUMNS_KEY,
    ENGINEERED_COLUMNS_KEY,
]

# Keys that are related to ML modelling (may span across cleaning stages
# but should be reset when the user wants to start a fresh ML workflow).
_ML_BOUND_KEYS: list[str] = [
    ML_PLAN_KEY,
    ML_RESULTS_KEY,
    UPLOADED_MODEL_KEY,
    PREDICTION_HISTORY_KEY,
]

# The full list of every key this module owns.
_ALL_MANAGED_KEYS: list[str] = [
    *_DATASET_BOUND_KEYS,
    *_ML_BOUND_KEYS,
    AI_FAILED_PROVIDERS_KEY,
]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def init_session_state() -> None:
    """Ensure every managed key exists in ``st.session_state`` with a safe
    default value.

    This function is idempotent — calling it multiple times will not
    overwrite existing values.  It should be invoked once near the top of
    the Streamlit app script so that downstream modules can safely read
    session state without worrying about ``KeyError``.
    """
    defaults: dict[str, Any] = {
        DATASET_KEY: None,
        CLEANED_KEY: None,
        CLEANING_LOGS_KEY: [],
        CLEANING_SUMMARY_KEY: {},
        AI_STRATEGY_KEY: None,
        ML_PLAN_KEY: None,
        ML_RESULTS_KEY: None,
        SELECTED_FEATURES_KEY: [],
        UPLOADED_MODEL_KEY: None,
        PREDICTION_HISTORY_KEY: [],
        ACTIVE_DATASET_KEY: None,
        FILE_HASH_KEY: None,
        ORIGINAL_COLUMNS_KEY: [],
        ENGINEERED_COLUMNS_KEY: [],
        AI_FAILED_PROVIDERS_KEY: set(),
    }

    for key, default_value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = default_value
            logger.debug("Initialised session state key '%s' with default %r", key, default_value)


def reset_dataset_state(exclude_keys: list[str] | None = None) -> None:
    """Clear **all** dataset-specific session state so the app is ready for a
    brand-new dataset.

    Parameters
    ----------
    exclude_keys:
        Optional list of key names to *preserve* even though they would
        normally be reset.  A common use-case is passing
        ``[AI_FAILED_PROVIDERS_KEY]`` so that provider-failure tracking
        survives across dataset switches.

    Notes
    -----
    This is the **critical** reset path — every key that depends on the
    contents or schema of the previous dataset must be cleared here,
    otherwise stale data from one dataset will bleed into the next.
    """
    exclude = set(exclude_keys) if exclude_keys else set()

    # We reset both dataset-bound AND ML-bound keys because a new dataset
    # invalidates any previously trained model or prediction history.
    keys_to_reset: list[str] = [
        *_DATASET_BOUND_KEYS,
        *_ML_BOUND_KEYS,
    ]

    for key in keys_to_reset:
        if key in exclude:
            logger.debug("Skipping reset of excluded key '%s'", key)
            continue

        # Determine the appropriate default so the key remains usable.
        default: Any = _default_for_key(key)

        st.session_state[key] = default
        logger.info("Reset session state key '%s' -> %r", key, default)


def reset_ml_state() -> None:
    """Reset only the ML-related session state keys.

    Use this when the user wants to re-run the ML pipeline (e.g. choose a
    different target variable or algorithm) **without** discarding the
    current dataset and cleaning results.
    """
    for key in _ML_BOUND_KEYS:
        default: Any = _default_for_key(key)
        st.session_state[key] = default
        logger.info("Reset ML state key '%s' -> %r", key, default)


def get_state(key: str) -> Any:
    """Safely retrieve a value from ``st.session_state``.

    Parameters
    ----------
    key:
        The session state key to look up.

    Returns
    -------
    Any
        The stored value, or ``None`` if the key does not exist.
    """
    return st.session_state.get(key)


def set_state(key: str, value: Any) -> None:
    """Safely write a value into ``st.session_state``.

    Parameters
    ----------
    key:
        The session state key to set.
    value:
        The value to store.
    """
    st.session_state[key] = value
    logger.debug("set_state('%s', <%s>)", key, type(value).__name__)


def has_state(key: str) -> bool:
    """Check whether *key* is present in ``st.session_state``.

    Parameters
    ----------
    key:
        The session state key to check.

    Returns
    -------
    bool
        ``True`` if the key exists (even if its value is ``None`` or an
        empty container), ``False`` otherwise.
    """
    return key in st.session_state


def get_all_dataset_keys() -> list[str]:
    """Return every session state key that is bound to the current dataset.

    These are the keys that **must** be reset when the user uploads a new
    file or switches to a different dataset.

    Returns
    -------
    list[str]
        A new list containing the dataset-bound key constants.
    """
    return list(_DATASET_BOUND_KEYS)


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _default_for_key(key: str) -> Any:
    """Return the appropriate default value for a managed key.

    This mirrors the defaults in :func:`init_session_state` so that reset
    operations restore keys to the same initial state.
    """
    _defaults: dict[str, Any] = {
        DATASET_KEY: None,
        CLEANED_KEY: None,
        CLEANING_LOGS_KEY: [],
        CLEANING_SUMMARY_KEY: {},
        AI_STRATEGY_KEY: None,
        ML_PLAN_KEY: None,
        ML_RESULTS_KEY: None,
        SELECTED_FEATURES_KEY: [],
        UPLOADED_MODEL_KEY: None,
        PREDICTION_HISTORY_KEY: [],
        ACTIVE_DATASET_KEY: None,
        FILE_HASH_KEY: None,
        ORIGINAL_COLUMNS_KEY: [],
        ENGINEERED_COLUMNS_KEY: [],
        AI_FAILED_PROVIDERS_KEY: set(),
    }
    return _defaults.get(key)
