"""
file_loader.py — Universal file ingestion module for the AI-Assisted EDA & ML Platform.

Handles loading of CSV, Excel, Parquet, and ZIP archives into pandas DataFrames.
All loaders are dataset-agnostic and return standardized results suitable for
downstream EDA and ML pipelines.
"""

import pandas as pd
import io
import zipfile
import csv
import logging
from pathlib import Path
from typing import Any

from modules.utils import compute_file_hash, safe_standardize_columns, drop_empty_columns, setup_logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Supported file extensions
# ---------------------------------------------------------------------------
SUPPORTED_EXTENSIONS = {".csv", ".xlsx", ".xls", ".parquet", ".zip"}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_file_hash(uploaded_file) -> str:
    """Compute a deterministic hash for an uploaded Streamlit file.

    Reads the file bytes and delegates to ``compute_file_hash`` from the
    shared utilities module.

    Parameters
    ----------
    uploaded_file : st.runtime.uploaded_file_manager.UploadedFile
        The file object provided by ``st.file_uploader``.

    Returns
    -------
    str
        Hex-encoded hash string identifying the file contents.
    """
    try:
        file_bytes = uploaded_file.read()
        # Reset the stream so callers can still read the file later
        uploaded_file.seek(0)
        return compute_file_hash(file_bytes)
    except Exception as exc:
        logger.error("Failed to compute hash for file '%s': %s", uploaded_file.name, exc)
        raise RuntimeError(f"Could not compute hash for '{uploaded_file.name}': {exc}") from exc


def load_uploaded_file(uploaded_file) -> dict[str, pd.DataFrame]:
    """Load an uploaded Streamlit file into a dict of DataFrames.

    Inspects the file extension and routes to the appropriate internal loader.
    For ZIP archives every compatible file inside is extracted and loaded.

    Parameters
    ----------
    uploaded_file : st.runtime.uploaded_file_manager.UploadedFile
        File object from ``st.file_uploader``.

    Returns
    -------
    dict[str, pd.DataFrame]
        Mapping of *filename* (or *sheet_name* for Excel) to a DataFrame.

    Raises
    ------
    ValueError
        If the file extension is not supported.
    RuntimeError
        If loading fails for an unexpected reason.
    """
    if uploaded_file is None:
        raise ValueError("No file was uploaded.")

    filename = uploaded_file.name
    ext = Path(filename).suffix.lower()

    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file extension '{ext}' for '{filename}'. "
            f"Supported extensions: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )

    try:
        file_bytes = uploaded_file.read()
        uploaded_file.seek(0)  # leave the stream in a usable state
    except Exception as exc:
        logger.error("Failed to read bytes from uploaded file '%s': %s", filename, exc)
        raise RuntimeError(f"Could not read uploaded file '{filename}': {exc}") from exc

    logger.info("Loading file '%s' (ext=%s, size=%d bytes)", filename, ext, len(file_bytes))

    try:
        if ext == ".csv":
            df = _load_csv(file_bytes, filename)
            return {filename: df}
        elif ext in (".xlsx", ".xls"):
            return _load_excel(file_bytes, filename)
        elif ext == ".parquet":
            df = _load_parquet(file_bytes, filename)
            return {filename: df}
        elif ext == ".zip":
            return _load_zip(file_bytes, filename)
    except ValueError:
        # Re-raise validation / supported-extension errors as-is
        raise
    except Exception as exc:
        logger.error("Error loading file '%s': %s", filename, exc, exc_info=True)
        raise RuntimeError(f"Failed to load '{filename}': {exc}") from exc


def prepare_dataset(
    df: pd.DataFrame,
    source_name: str = "",
) -> tuple[pd.DataFrame, list[str]]:
    """Standardize column names and drop empty columns.

    Applies :func:`safe_standardize_columns` followed by
    :func:`drop_empty_columns` so the returned DataFrame is ready for
    downstream analysis.

    Parameters
    ----------
    df : pd.DataFrame
        Raw DataFrame to clean.
    source_name : str, optional
        Human-readable label used in log messages (e.g. the originating
        filename).

    Returns
    -------
    tuple[pd.DataFrame, list[str]]
        A 2-tuple of *(cleaned_df, original_column_names)* where
        ``original_column_names`` is the list of column names *before*
        standardization.
    """
    label = source_name or "<unnamed>"
    original_columns = list(df.columns)

    logger.info(
        "Preparing dataset '%s' — %d rows × %d columns",
        label,
        len(df),
        len(original_columns),
    )

    df = safe_standardize_columns(df)
    df = drop_empty_columns(df)

    logger.info(
        "Dataset '%s' after preparation — %d rows × %d columns (dropped %d columns)",
        label,
        len(df),
        len(df.columns),
        len(original_columns) - len(df.columns),
    )

    return df, original_columns


# ---------------------------------------------------------------------------
# Internal loaders
# ---------------------------------------------------------------------------

def _load_csv(file_bytes: bytes, filename: str) -> pd.DataFrame:
    """Read CSV bytes trying multiple encodings and delimiters.

    Iterates through a curated list of encodings and delimiters, falling back
    to ``csv.Sniffer`` for delimiter detection when the primary attempts fail.
    ``pd.read_csv`` warnings are suppressed throughout.

    Parameters
    ----------
    file_bytes : bytes
        Raw file content.
    filename : str
        Original filename (used for logging).

    Returns
    -------
    pd.DataFrame

    Raises
    ------
    RuntimeError
        If no valid encoding / delimiter combination succeeds.
    """
    import warnings

    encodings = ["utf-8", "latin-1", "cp1252", "iso-8859-1"]
    delimiters = [",", ";", "\t", "|"]

    # First pass: try each encoding with each delimiter
    for encoding in encodings:
        for delimiter in delimiters:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df = pd.read_csv(
                        io.BytesIO(file_bytes),
                        encoding=encoding,
                        sep=delimiter,
                        dtype="object",  # load everything as string to avoid dtype casting failures
                        on_bad_lines="skip",
                    )
                # Heuristic: if we ended up with a single column the delimiter is probably wrong
                if len(df.columns) < 2:
                    continue
                logger.info(
                    "CSV '%s' loaded successfully (encoding=%s, delimiter=%r, rows=%d, cols=%d)",
                    filename,
                    encoding,
                    delimiter,
                    len(df),
                    len(df.columns),
                )
                # Second pass with inferred dtypes now that we know encoding + delimiter
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df = pd.read_csv(
                        io.BytesIO(file_bytes),
                        encoding=encoding,
                        sep=delimiter,
                        on_bad_lines="skip",
                    )
                return df
            except Exception:
                continue

    # Second pass: use csv.Sniffer to detect the delimiter
    try:
        sample = file_bytes[:65536]  # read first 64 KB for sniffing
        for encoding in encodings:
            try:
                text = sample.decode(encoding)
            except (UnicodeDecodeError, LookupError):
                continue
            try:
                sniffer = csv.Sniffer()
                dialect = sniffer.sniff(text)
                delimiter = dialect.delimiter
            except csv.Error:
                continue

            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df = pd.read_csv(
                        io.BytesIO(file_bytes),
                        encoding=encoding,
                        sep=delimiter,
                        on_bad_lines="skip",
                    )
                if len(df.columns) < 2:
                    continue
                logger.info(
                    "CSV '%s' loaded with sniffer (encoding=%s, delimiter=%r, rows=%d, cols=%d)",
                    filename,
                    encoding,
                    delimiter,
                    len(df),
                    len(df.columns),
                )
                return df
            except Exception:
                continue
    except Exception as exc:
        logger.warning("CSV sniffer approach failed for '%s': %s", filename, exc)

    raise RuntimeError(
        f"Could not parse CSV file '{filename}'. "
        f"Tried encodings {encodings} with delimiters {delimiters} and csv.Sniffer fallback."
    )


def _load_excel(file_bytes: bytes, filename: str) -> dict[str, pd.DataFrame]:
    """Read all sheets from an Excel workbook.

    Uses the ``openpyxl`` engine.  If the workbook contains a single sheet the
    result is still a one-entry dict keyed by the sheet name.

    Parameters
    ----------
    file_bytes : bytes
        Raw file content.
    filename : str
        Original filename (used for logging).

    Returns
    -------
    dict[str, pd.DataFrame]

    Raises
    ------
    RuntimeError
        If the workbook cannot be parsed.
    """
    import warnings

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # Read all sheet names first (sheet_name=None returns an ordered dict)
            sheet_data = pd.read_excel(
                io.BytesIO(file_bytes),
                engine="openpyxl",
                sheet_name=None,
            )

        result: dict[str, pd.DataFrame] = {}
        for sheet_name, df in sheet_data.items():
            result[sheet_name] = df
            logger.info(
                "Excel '%s' — sheet '%s': %d rows × %d columns",
                filename,
                sheet_name,
                len(df),
                len(df.columns),
            )

        logger.info(
            "Excel '%s' loaded — %d sheet(s) total", filename, len(result)
        )
        return result

    except Exception as exc:
        logger.error("Failed to load Excel file '%s': %s", filename, exc, exc_info=True)
        raise RuntimeError(f"Could not read Excel file '{filename}': {exc}") from exc


def _load_parquet(file_bytes: bytes, filename: str) -> pd.DataFrame:
    """Read a Parquet file from raw bytes.

    Uses **polars** (if installed) for faster ingestion, with a pandas
    fallback.  Both return a :class:`pd.DataFrame` so downstream code is
    unaffected by the engine choice.

    Parameters
    ----------
    file_bytes : bytes
        Raw file content.
    filename : str
        Original filename (used for logging).

    Returns
    -------
    pd.DataFrame

    Raises
    ------
    RuntimeError
        If the parquet data cannot be parsed.
    """
    try:
        # Try polars first for faster ingestion
        try:
            import polars as pl
            pl_df = pl.read_parquet(io.BytesIO(file_bytes))
            df = pl_df.to_pandas()
            logger.info(
                "Parquet '%s' loaded via polars — %d rows × %d columns",
                filename, len(df), len(df.columns),
            )
            return df
        except ImportError:
            pass  # polars not installed — fall through to pandas
        except Exception:
            pass  # polars failed — fall through to pandas

        # Pandas fallback
        df = pd.read_parquet(io.BytesIO(file_bytes))
        logger.info(
            "Parquet '%s' loaded via pandas — %d rows × %d columns",
            filename,
            len(df),
            len(df.columns),
        )
        return df
    except Exception as exc:
        logger.error("Failed to load Parquet file '%s': %s", filename, exc, exc_info=True)
        raise RuntimeError(f"Could not read Parquet file '{filename}': {exc}") from exc


def _load_zip(file_bytes: bytes, filename: str) -> dict[str, pd.DataFrame]:
    """Extract a ZIP archive and load every compatible file found inside.

    Only ``.csv``, ``.xlsx``, ``.xls``, and ``.parquet`` files are processed.
    Unsupported entries are skipped with a warning.

    Parameters
    ----------
    file_bytes : bytes
        Raw ZIP file content.
    filename : str
        Original filename (used for logging).

    Returns
    -------
    dict[str, pd.DataFrame]
        Mapping of *internal_filename* → DataFrame for every successfully
        loaded entry.

    Raises
    ------
    RuntimeError
        If the archive cannot be opened or contains no loadable files.
    """
    try:
        archive = zipfile.ZipFile(io.BytesIO(file_bytes))
    except zipfile.BadZipFile as exc:
        logger.error("File '%s' is not a valid ZIP archive: %s", filename, exc)
        raise RuntimeError(f"'{filename}' is not a valid ZIP archive: {exc}") from exc
    except Exception as exc:
        logger.error("Error opening ZIP '%s': %s", filename, exc)
        raise RuntimeError(f"Could not open ZIP file '{filename}': {exc}") from exc

    loadable_extensions = {".csv", ".xlsx", ".xls", ".parquet"}
    results: dict[str, pd.DataFrame] = {}
    skipped: list[str] = []

    # Sort names so results are deterministic
    for entry_name in sorted(archive.namelist()):
        # Skip directories and hidden files (e.g. __MACOSX/)
        if entry_name.endswith("/"):
            continue
        if "/." in entry_name or entry_name.startswith("."):
            skipped.append(entry_name)
            logger.debug("Skipping hidden/system entry '%s' in ZIP '%s'", entry_name, filename)
            continue

        entry_ext = Path(entry_name).suffix.lower()
        if entry_ext not in loadable_extensions:
            skipped.append(entry_name)
            logger.info(
                "Skipping unsupported file '%s' (ext=%s) in ZIP '%s'",
                entry_name,
                entry_ext,
                filename,
            )
            continue

        try:
            entry_bytes = archive.read(entry_name)
        except Exception as exc:
            logger.warning("Could not read '%s' from ZIP '%s': %s", entry_name, filename, exc)
            continue

        try:
            if entry_ext == ".csv":
                df = _load_csv(entry_bytes, entry_name)
                results[entry_name] = df
            elif entry_ext in (".xlsx", ".xls"):
                sheets = _load_excel(entry_bytes, entry_name)
                # Prefix keys with the zip-internal path to avoid collisions
                for sheet_name, sheet_df in sheets.items():
                    key = f"{entry_name}::{sheet_name}"
                    results[key] = sheet_df
            elif entry_ext == ".parquet":
                df = _load_parquet(entry_bytes, entry_name)
                results[entry_name] = df
        except Exception as exc:
            logger.warning(
                "Failed to load '%s' from ZIP '%s': %s",
                entry_name,
                filename,
                exc,
            )

    archive.close()

    if not results:
        raise RuntimeError(
            f"ZIP archive '{filename}' contained no loadable files. "
            f"Skipped entries: {skipped}"
        )

    if skipped:
        logger.info(
            "ZIP '%s' — loaded %d file(s), skipped %d unsupported entry/entries: %s",
            filename,
            len(results),
            len(skipped),
            skipped,
        )
    else:
        logger.info(
            "ZIP '%s' — loaded %d file(s), none skipped", filename, len(results)
        )

    return results


# ---------------------------------------------------------------------------
# Merge helper
# ---------------------------------------------------------------------------

def _try_merge_datasets(
    datasets: dict[str, pd.DataFrame],
    filename: str,
) -> pd.DataFrame:
    """Attempt to merge multiple DataFrames into one.

    If **all** DataFrames share exactly the same columns (same names and
    order), they are vertically concatenated and two metadata columns are
    added:

    * ``Source_File`` — the originating filename.
    * ``Source_Sheet`` — the sheet or entry key within the file.

    If the columns are incompatible the function keeps the datasets separate
    and returns the *first* DataFrame in insertion order.

    Parameters
    ----------
    datasets : dict[str, pd.DataFrame]
        Mapping of name → DataFrame (e.g. sheet names or ZIP entry keys).
    filename : str
        Name of the source file (used for the ``Source_File`` column and
        log messages).

    Returns
    -------
    pd.DataFrame
        Either the merged DataFrame or the first individual DataFrame.
    """
    if not datasets:
        raise ValueError("datasets dict is empty — nothing to merge.")

    if len(datasets) == 1:
        # Nothing to merge; still tag with metadata
        only_key = next(iter(datasets))
        df = datasets[only_key].copy()
        df["Source_File"] = filename
        df["Source_Sheet"] = only_key
        logger.info(
            "Single dataset '%s' in '%s' — returned as-is with metadata columns",
            only_key,
            filename,
        )
        return df

    # Check column compatibility
    keys = list(datasets.keys())
    reference_columns = list(datasets[keys[0]].columns)

    all_compatible = True
    for key in keys[1:]:
        if list(datasets[key].columns) != reference_columns:
            all_compatible = False
            break

    if all_compatible:
        frames: list[pd.DataFrame] = []
        for key, df in datasets.items():
            tagged = df.copy()
            tagged["Source_File"] = filename
            tagged["Source_Sheet"] = key
            frames.append(tagged)

        merged = pd.concat(frames, ignore_index=True)
        logger.info(
            "Merged %d compatible datasets from '%s' — %d rows × %d columns",
            len(datasets),
            filename,
            len(merged),
            len(merged.columns),
        )
        return merged

    # Incompatible columns — return the first dataset
    first_key = keys[0]
    first_df = datasets[first_key].copy()
    first_df["Source_File"] = filename
    first_df["Source_Sheet"] = first_key

    logger.warning(
        "Datasets in '%s' have incompatible columns and cannot be merged. "
        "Returning only the first dataset ('%s'). Full key list: %s",
        filename,
        first_key,
        keys,
    )
    return first_df
