"""
ML Engine module for the AI-Assisted EDA & ML Platform.

This module provides a dataset-agnostic ML pipeline that handles feature
preparation, data splitting, model training, evaluation, feature importance
extraction, walk-forward backtesting, and model serialisation.  It is designed
to work with any tabular dataset and automatically detects whether the target
variable represents a regression or classification problem.
"""

import logging
import time
import warnings
from typing import Any, Optional

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import (
    HistGradientBoostingClassifier,
    HistGradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from modules.utils import is_identifier_column, is_leakage_risk, setup_logging

# ---------------------------------------------------------------------------
# Logging & warning suppression
# ---------------------------------------------------------------------------

_logger: logging.Logger = setup_logging()

# Suppress convergence and irrelevant sklearn warnings during training.
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn")
warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_LEAKAGE_R2_THRESHOLD: float = 0.99
_LEAKAGE_ACCURACY_THRESHOLD: float = 0.99
_AUTO_CLASSIFICATION_UNIQUE_LIMIT: int = 20
_AUTO_CLASSIFICATION_RATIO: float = 2.0


class MLPipeline:
    """Dataset-agnostic machine-learning pipeline.

    Encapsulates the full workflow from raw feature preparation through to
    model evaluation and persistence.  Supports both regression and
    classification tasks, with optional time-aware (chronological) splitting
    and walk-forward backtesting.

    Parameters
    ----------
    problem_type : str, optional
        One of ``"auto"``, ``"regression"``, or ``"classification"``.  When
        ``"auto"`` the type is inferred from the target column at training
        time.  Default ``"auto"``.
    random_state : int, optional
        Seed for reproducible randomness.  Default ``42``.
    """

    def __init__(self, problem_type: str = "auto", random_state: int = 42) -> None:
        self.problem_type: str = problem_type
        self.random_state: int = random_state
        np.random.seed(random_state)
        _logger.info(
            "MLPipeline initialised (problem_type=%s, random_state=%d).",
            problem_type,
            random_state,
        )

    # ------------------------------------------------------------------
    # Problem-type detection
    # ------------------------------------------------------------------

    def _detect_problem_type(self, y: pd.Series | np.ndarray) -> str:
        """Infer whether the target represents a classification problem.

        Classification is assumed when the number of unique values is small
        (``< _AUTO_CLASSIFICATION_UNIQUE_LIMIT``) *and* the row count is at
        least ``_AUTO_CLASSIFICATION_RATIO`` times the number of unique
        values.

        Parameters
        ----------
        y : pd.Series | np.ndarray
            Target variable.

        Returns
        -------
        str
            ``"classification"`` or ``"regression"``.
        """
        if isinstance(y, pd.Series):
            unique_count = y.nunique(dropna=True)
            total_count = len(y.dropna())
        else:
            unique_count = len(np.unique(y[~np.isnan(y)]))
            total_count = int(np.sum(~np.isnan(y)))

        if (
            unique_count < _AUTO_CLASSIFICATION_UNIQUE_LIMIT
            and total_count >= _AUTO_CLASSIFICATION_RATIO * unique_count
        ):
            _logger.info(
                "Auto-detected problem type as 'classification' "
                "(unique=%d, total=%d).",
                unique_count,
                total_count,
            )
            return "classification"

        _logger.info("Auto-detected problem type as 'regression'.")
        return "regression"

    # ------------------------------------------------------------------
    # Feature preparation
    # ------------------------------------------------------------------

    def prepare_features(
        self,
        df: pd.DataFrame,
        target_column: str,
        selected_features: list[str],
        exclude_features: list[str],
        date_columns: Optional[list[str]] = None,
        has_date_split: bool = False,
    ) -> dict[str, Any]:
        """Prepare the feature matrix ``X`` and target vector ``y``.

        Steps performed:

        1. Filter *selected_features* by removing *exclude_features* and any
           features flagged as identifier or leakage-risk columns.
        2. Separate features into numeric, categorical, and boolean groups.
        3. Convert boolean features to integer (0 / 1).
        4. Convert date columns to ordinal numeric values.
        5. Build a :class:`~sklearn.compose.ColumnTransformer` that imputes
           and scales numeric features and one-hot encodes categorical
           features.
        6. Fit and transform the training data.

        Parameters
        ----------
        df : pd.DataFrame
            Input dataset.
        target_column : str
            Name of the target / label column.
        selected_features : list[str]
            Candidate feature column names.
        exclude_features : list[str]
            Column names to exclude from modelling.
        date_columns : list[str] | None, optional
            Date column names to convert to numeric.
        has_date_split : bool, optional
            Whether a chronological split is planned (informational).

        Returns
        -------
        dict[str, Any]
            Dictionary containing:

            - ``X`` – transformed feature matrix (numpy array).
            - ``y`` – target vector (numpy array).
            - ``preprocessor`` – fitted :class:`ColumnTransformer`.
            - ``numeric_features`` – list of numeric column names.
            - ``categorical_features`` – list of categorical column names.
            - ``feature_names_after_transform`` – feature names after encoding.
        """
        _logger.info("Preparing features (target='%s', %d candidates).", target_column, len(selected_features))

        working_df = df.copy()
        date_columns = date_columns or []

        # --- Filter features ---
        exclude_set = set(exclude_features) | {target_column}
        features = [f for f in selected_features if f not in exclude_set and f in working_df.columns]

        # Remove identifier / leakage-risk features.
        safe_features: list[str] = []
        for feat in features:
            if is_identifier_column(working_df[feat]):
                _logger.info("Excluding identifier column '%s'.", feat)
                continue
            if is_leakage_risk(feat, target_column):
                _logger.warning("Excluding leakage-risk column '%s'.", feat)
                continue
            safe_features.append(feat)

        features = safe_features
        _logger.info("Features after filtering: %d.", len(features))

        if not features:
            raise ValueError("No features remaining after filtering. Check selected/excluded columns.")

        # --- Classify columns ---
        numeric_features: list[str] = []
        categorical_features: list[str] = []
        boolean_features: list[str] = []
        date_feature_set = set(date_columns)

        for feat in features:
            if feat in date_feature_set:
                numeric_features.append(feat)
            elif pd.api.types.is_bool_dtype(working_df[feat]):
                boolean_features.append(feat)
            elif pd.api.types.is_numeric_dtype(working_df[feat]):
                numeric_features.append(feat)
            else:
                categorical_features.append(feat)

        _logger.info(
            "Column types — numeric: %d, categorical: %d, boolean: %d.",
            len(numeric_features),
            len(categorical_features),
            len(boolean_features),
        )

        # --- Convert boolean features to int ---
        for feat in boolean_features:
            working_df[feat] = working_df[feat].astype(int)
            # After conversion, treat as numeric for the pipeline.
            numeric_features.append(feat)

        # --- Convert date features to ordinal numeric ---
        for feat in date_columns:
            if feat in working_df.columns:
                col = working_df[feat]
                if pd.api.types.is_datetime64_any_dtype(col):
                    working_df[feat] = col.astype("int64") / 1e9
                elif pd.api.types.is_object_dtype(col):
                    try:
                        converted = pd.to_datetime(col, errors="coerce")
                        working_df[feat] = converted.astype("int64") / 1e9
                    except Exception as exc:
                        _logger.warning(
                            "Could not convert date column '%s' to numeric: %s. Dropping.",
                            feat,
                            exc,
                        )
                        numeric_features = [f for f in numeric_features if f != feat]
                        continue
                _logger.debug("Converted date column '%s' to ordinal numeric.", feat)

        # --- Target ---
        y = working_df[target_column].values
        X_raw = working_df[features]

        # --- Build preprocessor ---
        transformers: list[tuple[str, Any, list[str]]] = []

        if numeric_features:
            numeric_transformer = Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="median")),
                    ("scaler", StandardScaler()),
                ]
            )
            transformers.append(("num", numeric_transformer, numeric_features))

        if categorical_features:
            categorical_transformer = Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="constant", fill_value="__missing__")),
                    ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=True)),
                ]
            )
            transformers.append(("cat", categorical_transformer, categorical_features))

        if not transformers:
            raise ValueError("No numeric or categorical features available for preprocessing.")

        preprocessor = ColumnTransformer(transformers=transformers, remainder="drop")
        X = preprocessor.fit_transform(X_raw)

        # --- Resolve feature names after transform ---
        feature_names_after_transform: list[str] = self._get_feature_names_out(preprocessor, features)

        _logger.info("Feature matrix shape: %s.", X.shape)

        return {
            "X": X,
            "y": y,
            "preprocessor": preprocessor,
            "numeric_features": numeric_features,
            "categorical_features": categorical_features,
            "feature_names_after_transform": feature_names_after_transform,
        }

    @staticmethod
    def _get_feature_names_out(
        preprocessor: ColumnTransformer,
        original_features: list[str],
    ) -> list[str]:
        """Extract human-readable feature names from a fitted ColumnTransformer.

        Parameters
        ----------
        preprocessor : ColumnTransformer
            Fitted preprocessor.
        original_features : list[str]
            Feature names fed into the preprocessor.

        Returns
        -------
        list[str]
            Feature names after transformation.
        """
        names: list[str] = []

        for name, transformer, cols in preprocessor.transformers_:
            if name == "remainder":
                continue
            if hasattr(transformer, "named_steps"):
                last_step = transformer.named_steps[list(transformer.named_steps.keys())[-1]]
            else:
                last_step = transformer

            if hasattr(last_step, "get_feature_names_out"):
                try:
                    out = last_step.get_feature_names_out(cols)
                    names.extend(str(f) for f in out)
                except Exception:
                    names.extend(cols)
            else:
                names.extend(cols)

        return names

    # ------------------------------------------------------------------
    # Data splitting
    # ------------------------------------------------------------------

    def split_data(
        self,
        X: np.ndarray | pd.DataFrame,
        y: np.ndarray | pd.Series,
        test_size: float = 0.2,
        stratify: bool = False,
        date_column: Optional[str] = None,
        dates: Optional[np.ndarray] = None,
    ) -> dict[str, Any]:
        """Split data into training and test sets.

        Supports two splitting strategies:

        * **Time-based** — when *dates* are provided, the data are sorted
          chronologically and the last *test_size* fraction is used as the
          test set.
        * **Random** — standard :func:`sklearn.model_selection.train_test_split`.

        For classification tasks with fewer than 100 unique target values the
        split is automatically stratified (unless *stratify* is explicitly
        ``False``).

        Parameters
        ----------
        X : np.ndarray | pd.DataFrame
            Feature matrix.
        y : np.ndarray | pd.Series
            Target vector.
        test_size : float, optional
            Fraction of data for the test set.  Default ``0.2``.
        stratify : bool, optional
            Whether to stratify the split.  Default ``False``.
        date_column : str | None, optional
            Name of the date column (informational / for logging).
        dates : np.ndarray | None, optional
            Array of datetime values for chronological splitting.

        Returns
        -------
        dict[str, Any]
            ``{X_train, X_test, y_train, y_test}``.
        """
        _logger.info("Splitting data (test_size=%.2f).", test_size)

        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(y, pd.Series):
            y = y.values

        # --- Time-based split ---
        if dates is not None and len(dates) == len(y):
            dates = np.asarray(dates)
            sort_idx = np.argsort(dates)
            X = X[sort_idx]
            y = y[sort_idx]
            split_idx = int(len(y) * (1 - test_size))

            X_train, X_test = X[:split_idx], X[split_idx:]
            y_train, y_test = y[:split_idx], y[split_idx:]
            _logger.info(
                "Time-based split: train=%d, test=%d (date_col='%s').",
                len(y_train),
                len(y_test),
                date_column or "N/A",
            )
        else:
            # Determine whether to stratify.
            should_stratify = stratify
            if stratify:
                unique_vals = np.unique(y[~np.isnan(y)] if np.issubdtype(y.dtype, np.floating) else y)
                if len(unique_vals) < 100:
                    should_stratify = True
                else:
                    should_stratify = False
                    _logger.debug(
                        "Stratification disabled: >100 unique target values (%d).",
                        len(unique_vals),
                    )

            stratify_arg = y if should_stratify else None
            X_train, X_test, y_train, y_test = train_test_split(
                X,
                y,
                test_size=test_size,
                random_state=self.random_state,
                stratify=stratify_arg,
            )
            _logger.info(
                "Random split: train=%d, test=%d (stratified=%s).",
                len(y_train),
                len(y_test),
                should_stratify,
            )

        return {
            "X_train": X_train,
            "X_test": X_test,
            "y_train": y_train,
            "y_test": y_test,
        }

    # ------------------------------------------------------------------
    # Model training
    # ------------------------------------------------------------------

    def train_models(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        problem_type: str,
    ) -> dict[str, Any]:
        """Train a suite of baseline models.

        Regression models
        -----------------
        * Ridge
        * RandomForestRegressor
        * HistGradientBoostingRegressor

        Classification models
        ----------------------
        * LogisticRegression
        * RandomForestClassifier
        * HistGradientBoostingClassifier

        Parameters
        ----------
        X_train : np.ndarray
            Training feature matrix.
        y_train : np.ndarray
            Training target vector.
        problem_type : str
            ``"regression"`` or ``"classification"``.

        Returns
        -------
        dict[str, Any]
            Mapping of model name to ``{"model": fitted_model, "train_time_ms": float}``.
        """
        _logger.info("Training %s models.", problem_type)

        if problem_type == "regression":
            model_defs: list[tuple[str, Any]] = [
                ("Ridge", Ridge(random_state=self.random_state)),
                ("RandomForest", RandomForestRegressor(
                    n_estimators=100,
                    random_state=self.random_state,
                    n_jobs=-1,
                )),
                ("HistGradientBoosting", HistGradientBoostingRegressor(
                    random_state=self.random_state,
                )),
            ]
        else:
            model_defs = [
                ("LogisticRegression", LogisticRegression(
                    max_iter=1000,
                    random_state=self.random_state,
                    n_jobs=-1,
                )),
                ("RandomForest", RandomForestClassifier(
                    n_estimators=100,
                    random_state=self.random_state,
                    n_jobs=-1,
                )),
                ("HistGradientBoosting", HistGradientBoostingClassifier(
                    random_state=self.random_state,
                )),
            ]

        trained: dict[str, Any] = {}

        for name, model in model_defs:
            t0 = time.perf_counter()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                model.fit(X_train, y_train)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            trained[name] = {"model": model, "train_time_ms": round(elapsed_ms, 1)}
            _logger.info("  %-28s trained in %.1f ms.", name, elapsed_ms)

        return trained

    # ------------------------------------------------------------------
    # Model evaluation
    # ------------------------------------------------------------------

    def evaluate_models(
        self,
        models_dict: dict[str, dict],
        X_test: np.ndarray,
        y_test: np.ndarray,
        problem_type: str,
    ) -> dict[str, dict]:
        """Evaluate trained models on the test set.

        For regression the metrics are **R²**, **RMSE**, and **MAE**.  For
        classification the metrics are **Accuracy** and **weighted F1**.  If a
        regression model achieves R² > 0.99 or a classification model exceeds
        99 % accuracy, a ``leakage_warning`` flag is added.

        Parameters
        ----------
        models_dict : dict[str, dict]
            Output of :meth:`train_models`.
        X_test : np.ndarray
            Test feature matrix.
        y_test : np.ndarray
            Test target vector.
        problem_type : str
            ``"regression"`` or ``"classification"``.

        Returns
        -------
        dict[str, dict]
            Mapping of model name to a metrics dictionary.
        """
        _logger.info("Evaluating %s models.", problem_type)

        results: dict[str, dict] = {}

        for name, info in models_dict.items():
            model = info["model"]
            y_pred = model.predict(X_test)

            if problem_type == "regression":
                r2 = r2_score(y_test, y_pred)
                rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
                mae = mean_absolute_error(y_test, y_pred)
                metrics: dict[str, Any] = {
                    "R2": round(r2, 4),
                    "RMSE": round(rmse, 4),
                    "MAE": round(mae, 4),
                }
                if r2 > _LEAKAGE_R2_THRESHOLD:
                    metrics["leakage_warning"] = (
                        f"Very high R² ({r2:.4f}) — possible data leakage or trivial task."
                    )
                    _logger.warning("Leakage warning for %s: R²=%.4f.", name, r2)
            else:
                acc = accuracy_score(y_test, y_pred)
                f1 = f1_score(y_test, y_pred, average="weighted", zero_division=0)
                metrics = {
                    "Accuracy": round(acc, 4),
                    "F1_weighted": round(f1, 4),
                }
                if acc > _LEAKAGE_ACCURACY_THRESHOLD:
                    metrics["leakage_warning"] = (
                        f"Very high accuracy ({acc:.4f}) — possible data leakage or trivial task."
                    )
                    _logger.warning("Leakage warning for %s: accuracy=%.4f.", name, acc)

            results[name] = metrics
            _logger.info("  %-28s %s", name, metrics)

        return results

    # ------------------------------------------------------------------
    # Feature importance
    # ------------------------------------------------------------------

    def get_feature_importance(
        self,
        model: Any,
        preprocessor: Any,
        feature_names: list[str],
        problem_type: str,
        top_n: int = 15,
    ) -> pd.DataFrame:
        """Extract and rank feature importances from a trained model.

        Tree-based models expose ``feature_importances_``; linear models
        expose ``coef_`` (absolute values are used so that magnitude is
        comparable).

        Parameters
        ----------
        model : Any
            Fitted scikit-learn model.
        preprocessor : Any
            Fitted :class:`ColumnTransformer` (used to retrieve output
            feature names).
        feature_names : list[str]
            Original feature names before encoding.
        problem_type : str
            ``"regression"`` or ``"classification"``.
        top_n : int, optional
            Number of top features to return.  Default ``15``.

        Returns
        -------
        pd.DataFrame
            DataFrame with columns ``Feature`` and ``Importance``, sorted in
            descending order of importance.
        """
        _logger.info("Extracting feature importance (top_n=%d).", top_n)

        # --- Obtain importance values ---
        if hasattr(model, "feature_importances_"):
            importances = np.abs(model.feature_importances_)
        elif hasattr(model, "coef_"):
            coef = model.coef_
            # For binary classification, coef_ is 1-D; for multi-class, 2-D.
            if coef.ndim > 1:
                importances = np.mean(np.abs(coef), axis=0)
            else:
                importances = np.abs(coef)
        else:
            _logger.warning("Model has no feature_importances_ or coef_ attribute.")
            return pd.DataFrame(columns=["Feature", "Importance"])

        # --- Resolve output feature names from the preprocessor ---
        out_names = self._get_feature_names_out(preprocessor, feature_names)

        if len(importances) != len(out_names):
            _logger.warning(
                "Importance length (%d) != feature name length (%d). "
                "Using generic names.",
                len(importances),
                len(out_names),
            )
            out_names = [f"feature_{i}" for i in range(len(importances))]

        df = pd.DataFrame({"Feature": out_names, "Importance": importances})
        df = df.sort_values("Importance", ascending=False).head(top_n).reset_index(drop=True)

        _logger.info("Top feature: %s (%.4f).", df.iloc[0]["Feature"], df.iloc[0]["Importance"])
        return df

    # ------------------------------------------------------------------
    # Full pipeline
    # ------------------------------------------------------------------

    def run_full_pipeline(
        self,
        df: pd.DataFrame,
        target_column: str,
        selected_features: list[str],
        exclude_features: list[str],
        problem_type: str = "auto",
        date_columns: Optional[list[str]] = None,
        has_date_split: bool = False,
    ) -> dict[str, Any]:
        """Execute the complete ML pipeline from raw data to evaluation.

        Workflow
        --------
        1. :meth:`prepare_features`
        2. :meth:`split_data`
        3. :meth:`train_models`
        4. :meth:`evaluate_models`
        5. :meth:`get_feature_importance` for the best model

        If *problem_type* is ``"auto"`` the type is inferred from the target
        using :meth:`_detect_problem_type`.

        Parameters
        ----------
        df : pd.DataFrame
            Input dataset.
        target_column : str
            Target column name.
        selected_features : list[str]
            Candidate feature columns.
        exclude_features : list[str]
            Columns to exclude.
        problem_type : str, optional
            ``"auto"``, ``"regression"``, or ``"classification"``.
        date_columns : list[str] | None, optional
            Date columns for temporal features or splitting.
        has_date_split : bool, optional
            Whether to use time-based splitting.

        Returns
        -------
        dict[str, Any]
            Comprehensive results dictionary containing prepared data,
            split data, trained models, evaluation metrics, and feature
            importances for the best model.
        """
        _logger.info("=" * 60)
        _logger.info("Starting full ML pipeline.")
        _logger.info("=" * 60)

        # --- Prepare features ---
        prep = self.prepare_features(
            df=df,
            target_column=target_column,
            selected_features=selected_features,
            exclude_features=exclude_features,
            date_columns=date_columns,
            has_date_split=has_date_split,
        )

        X = prep["X"]
        y = prep["y"]

        # --- Detect problem type ---
        if problem_type == "auto":
            problem_type = self._detect_problem_type(pd.Series(y))

        _logger.info("Problem type: %s.", problem_type)

        # --- Split data ---
        date_col_for_split: Optional[str] = None
        dates_arr: Optional[np.ndarray] = None

        if has_date_split and date_columns and date_columns[0] in df.columns:
            date_col_for_split = date_columns[0]
            date_series = df[date_columns[0]]
            if pd.api.types.is_datetime64_any_dtype(date_series):
                dates_arr = date_series.values
            else:
                try:
                    dates_arr = pd.to_datetime(date_series, errors="coerce").values
                except Exception:
                    dates_arr = None

        split = self.split_data(
            X=X,
            y=y,
            test_size=0.2,
            stratify=(problem_type == "classification"),
            date_column=date_col_for_split,
            dates=dates_arr,
        )

        # --- Train ---
        models = self.train_models(split["X_train"], split["y_train"], problem_type)

        # --- Evaluate ---
        evaluation = self.evaluate_models(models, split["X_test"], split["y_test"], problem_type)

        # --- Best model ---
        if problem_type == "regression":
            best_name = max(evaluation, key=lambda k: evaluation[k].get("R2", -np.inf))
        else:
            best_name = max(evaluation, key=lambda k: evaluation[k].get("Accuracy", -np.inf))

        best_model = models[best_name]["model"]
        _logger.info("Best model: %s.", best_name)

        # --- Feature importance ---
        importance_df = self.get_feature_importance(
            model=best_model,
            preprocessor=prep["preprocessor"],
            feature_names=prep["feature_names_after_transform"],
            problem_type=problem_type,
            top_n=15,
        )

        result: dict[str, Any] = {
            "problem_type": problem_type,
            "preprocessor": prep["preprocessor"],
            "numeric_features": prep["numeric_features"],
            "categorical_features": prep["categorical_features"],
            "feature_names": prep["feature_names_after_transform"],
            "X_train": split["X_train"],
            "X_test": split["X_test"],
            "y_train": split["y_train"],
            "y_test": split["y_test"],
            "models": models,
            "evaluation": evaluation,
            "best_model_name": best_name,
            "best_model": best_model,
            "feature_importance": importance_df,
        }

        _logger.info("Full pipeline completed. Best model: %s.", best_name)
        return result

    # ------------------------------------------------------------------
    # Walk-forward backtesting
    # ------------------------------------------------------------------

    def run_backtest(
        self,
        df: pd.DataFrame,
        target_column: str,
        selected_features: list[str],
        exclude_features: list[str],
        preprocessor: Any,
        model: Any,
        problem_type: str,
        date_column: Optional[str] = None,
        n_splits: int = 5,
    ) -> dict[str, Any]:
        """Run walk-forward (expanding-window) or random holdout backtesting.

        When a *date_column* is provided the data are sorted chronologically
        and an expanding-window scheme is used: each fold adds more training
        data and the test window is the next chronological chunk.  Otherwise,
        random holdout splits are performed.

        Parameters
        ----------
        df : pd.DataFrame
            Full dataset.
        target_column : str
            Target column name.
        selected_features : list[str]
            Feature column names.
        exclude_features : list[str]
            Columns to exclude.
        preprocessor : Any
            Fitted :class:`ColumnTransformer`.
        model : Any
            A *template* model (will be re-fitted on each fold; it is cloned
            via ``sklearn.base.clone`` where available, otherwise a fresh
            instance is constructed).
        problem_type : str
            ``"regression"`` or ``"classification"``.
        date_column : str | None, optional
            Column to use for chronological ordering.
        n_splits : int, optional
            Number of backtest folds.  Default ``5``.

        Returns
        -------
        dict[str, Any]
            ``{"fold_results": list[dict], "mean_metrics": dict, "std_metrics": dict}``.
        """
        _logger.info(
            "Running backtest (n_splits=%d, date_col=%s).",
            n_splits,
            date_column or "None",
        )

        # --- Prepare features ---
        prep = self.prepare_features(
            df=df,
            target_column=target_column,
            selected_features=selected_features,
            exclude_features=exclude_features,
            date_columns=[date_column] if date_column else None,
        )

        X = prep["X"]
        y = prep["y"]
        n_samples = len(y)

        fold_results: list[dict[str, Any]] = []

        if date_column and date_column in df.columns:
            # --- Time-based expanding window ---
            date_series = df[date_column]
            if pd.api.types.is_datetime64_any_dtype(date_series):
                dates = date_series.values
            else:
                dates = pd.to_datetime(date_series, errors="coerce").values

            sort_idx = np.argsort(dates)
            X = X[sort_idx]
            y = y[sort_idx]

            fold_size = n_samples // (n_splits + 1)
            for fold_idx in range(n_splits):
                train_end = fold_size * (fold_idx + 1)
                test_end = min(fold_size * (fold_idx + 2), n_samples)

                if test_end <= train_end or train_end < 1:
                    continue

                X_tr, X_te = X[:train_end], X[train_end:test_end]
                y_tr, y_te = y[:train_end], y[train_end:test_end]

                fold_metrics = self._fit_and_score_fold(model, X_tr, y_tr, X_te, y_te, problem_type)
                fold_metrics["fold"] = fold_idx + 1
                fold_metrics["train_size"] = len(y_tr)
                fold_metrics["test_size"] = len(y_te)
                fold_results.append(fold_metrics)
        else:
            # --- Random holdout ---
            for fold_idx in range(n_splits):
                split = self.split_data(X, y, test_size=0.2, stratify=(problem_type == "classification"))
                fold_metrics = self._fit_and_score_fold(
                    model,
                    split["X_train"],
                    split["y_train"],
                    split["X_test"],
                    split["y_test"],
                    problem_type,
                )
                fold_metrics["fold"] = fold_idx + 1
                fold_metrics["train_size"] = len(split["y_train"])
                fold_metrics["test_size"] = len(split["y_test"])
                fold_results.append(fold_metrics)

        if not fold_results:
            _logger.warning("No backtest folds produced (dataset too small?).")
            return {"fold_results": [], "mean_metrics": {}, "std_metrics": {}}

        # --- Aggregate ---
        metric_keys = [k for k in fold_results[0] if k not in ("fold", "train_size", "test_size")]
        mean_metrics: dict[str, float] = {}
        std_metrics: dict[str, float] = {}

        for key in metric_keys:
            values = [f[key] for f in fold_results]
            mean_metrics[key] = round(float(np.mean(values)), 4)
            std_metrics[key] = round(float(np.std(values)), 4)

        _logger.info("Backtest mean metrics: %s.", mean_metrics)
        _logger.info("Backtest std  metrics: %s.", std_metrics)

        return {
            "fold_results": fold_results,
            "mean_metrics": mean_metrics,
            "std_metrics": std_metrics,
        }

    def _fit_and_score_fold(
        self,
        model_template: Any,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_test: np.ndarray,
        y_test: np.ndarray,
        problem_type: str,
    ) -> dict[str, float]:
        """Clone a model, fit it, and compute metrics for a single fold.

        Parameters
        ----------
        model_template : Any
            Model to clone.
        X_train, y_train, X_test, y_test : np.ndarray
            Fold data.
        problem_type : str
            ``"regression"`` or ``"classification"``.

        Returns
        -------
        dict[str, float]
            Metric name → value.
        """
        try:
            from sklearn.base import clone
            fold_model = clone(model_template)
        except Exception:
            # Fallback: re-instantiate via the class.
            fold_model = model_template.__class__(**model_template.get_params())

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            fold_model.fit(X_train, y_train)

        y_pred = fold_model.predict(X_test)

        if problem_type == "regression":
            r2 = r2_score(y_test, y_pred)
            rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
            mae = mean_absolute_error(y_test, y_pred)
            return {"R2": round(r2, 4), "RMSE": round(rmse, 4), "MAE": round(mae, 4)}
        else:
            acc = accuracy_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred, average="weighted", zero_division=0)
            return {"Accuracy": round(acc, 4), "F1_weighted": round(f1, 4)}

    # ------------------------------------------------------------------
    # Model persistence
    # ------------------------------------------------------------------

    def save_model_package(
        self,
        model: Any,
        preprocessor: Any,
        feature_list: list[str],
        target: str,
        problem_type: str,
        numeric_features: list[str],
        categorical_features: list[str],
        date_columns: list[str],
        metrics: dict,
        feature_importance: pd.DataFrame,
        filepath: str,
    ) -> str:
        """Persist a trained model together with all required metadata.

        The resulting ``.joblib`` file contains everything needed to make
        predictions on new data: the model, the fitted preprocessor, the
        expected feature list, and evaluation metrics.

        Parameters
        ----------
        model : Any
            Fitted scikit-learn model.
        preprocessor : Any
            Fitted :class:`ColumnTransformer`.
        feature_list : list[str]
            Ordered list of feature names expected by the preprocessor.
        target : str
            Name of the target column.
        problem_type : str
            ``"regression"`` or ``"classification"``.
        numeric_features : list[str]
            Numeric feature names.
        categorical_features : list[str]
            Categorical feature names.
        date_columns : list[str]
            Date column names.
        metrics : dict
            Evaluation metrics for the model.
        feature_importance : pd.DataFrame
            Feature importance table.
        filepath : str
            Destination file path (typically ending in ``.joblib``).

        Returns
        -------
        str
            The *filepath* that was written.
        """
        package: dict[str, Any] = {
            "model": model,
            "preprocessor": preprocessor,
            "feature_list": feature_list,
            "target": target,
            "problem_type": problem_type,
            "numeric_features": numeric_features,
            "categorical_features": categorical_features,
            "date_columns": date_columns or [],
            "metrics": metrics,
            "feature_importance": feature_importance,
        }

        joblib.dump(package, filepath, compress=3)
        _logger.info("Model package saved to '%s'.", filepath)
        return filepath

    @staticmethod
    def load_model_package(filepath: str) -> dict:
        """Load a previously saved model package.

        Parameters
        ----------
        filepath : str
            Path to the ``.joblib`` file produced by :meth:`save_model_package`.

        Returns
        -------
        dict
            Dictionary with keys ``model``, ``preprocessor``, ``feature_list``,
            ``target``, ``problem_type``, ``numeric_features``,
            ``categorical_features``, ``date_columns``, ``metrics``, and
            ``feature_importance``.
        """
        package = joblib.load(filepath)
        _logger.info("Model package loaded from '%s'.", filepath)
        return package
