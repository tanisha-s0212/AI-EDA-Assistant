"""Prediction Engine — Universal prediction from trained model packages."""

import pandas as pd
import numpy as np
import logging
from typing import Any

from modules.utils import setup_logging

logger = setup_logging()


class PredictionEngine:
    """Handles predictions on new data using a saved model package."""

    def __init__(self, model_package: dict) -> None:
        """Load model package components.

        Args:
            model_package: Dict containing model, preprocessor, feature_list,
                          target, problem_type, numeric_features,
                          categorical_features, date_columns, metrics, etc.
        """
        self.model = model_package.get("model")
        self.preprocessor = model_package.get("preprocessor")
        self.feature_list: list[str] = model_package.get("feature_list", [])
        self.target: str = model_package.get("target", "")
        self.problem_type: str = model_package.get("problem_type", "regression")
        self.numeric_features: list[str] = model_package.get("numeric_features", [])
        self.categorical_features: list[str] = model_package.get("categorical_features", [])
        self.date_columns: list[str] = model_package.get("date_columns", [])
        self.metrics: dict = model_package.get("metrics", {})
        self.feature_importance = model_package.get("feature_importance")
        self.class_labels: list[str] | None = model_package.get("class_labels")

        # Store min/max for numeric features if available
        self._numeric_ranges: dict[str, tuple[float, float]] = {}
        numeric_meta = model_package.get("numeric_ranges", {})
        for col, bounds in numeric_meta.items():
            if isinstance(bounds, (list, tuple)) and len(bounds) == 2:
                self._numeric_ranges[col] = (float(bounds[0]), float(bounds[1]))

    def generate_input_form_schema(self) -> list[dict]:
        """Generate form schema dynamically from feature metadata.

        Returns:
            List of dicts with name, dtype, role, options, min, max.
        """
        schema: list[dict] = []

        for feature in self.feature_list:
            role = "categorical"
            dtype = "str"
            options: list[str] | None = None
            min_val: float | None = None
            max_val: float | None = None

            if feature in self.numeric_features:
                role = "numeric"
                dtype = "float"
                if feature in self._numeric_ranges:
                    min_val = self._numeric_ranges[feature][0]
                    max_val = self._numeric_ranges[feature][1]
            elif feature in self.date_columns:
                role = "date"
                dtype = "date"
            elif feature in self.categorical_features:
                role = "categorical"
                dtype = "str"
                # Try to extract categories from one-hot encoder
                options = self._extract_categories_for_feature(feature)

            schema.append({
                "name": feature,
                "dtype": dtype,
                "role": role,
                "options": options,
                "min": min_val,
                "max": max_val,
            })

        return schema

    def _extract_categories_for_feature(self, feature: str) -> list[str] | None:
        """Extract unique categories for a feature from the fitted preprocessor."""
        try:
            if self.preprocessor is None:
                return None
            # Access the categorical transformer
            transformers = getattr(self.preprocessor, "transformers_", [])
            for name, trans, cols in transformers:
                if hasattr(trans, "categories_") and feature in cols:
                    idx = cols.index(feature)
                    cats = trans.categories_[idx]
                    # Filter out __missing__ placeholder
                    valid = [str(c) for c in cats if str(c) != "__missing__"]
                    return valid if valid else None
        except Exception as e:
            logger.debug("Could not extract categories for %s: %s", feature, e)
        return None

    def prepare_single_input(self, inputs: dict) -> pd.DataFrame:
        """Convert user inputs dict to model-ready DataFrame.

        Args:
            inputs: Dict of feature_name -> value from user form.

        Returns:
            Single-row DataFrame with correct column order and types.
        """
        row: dict[str, Any] = {}

        for feature in self.feature_list:
            value = inputs.get(feature)

            if feature in self.numeric_features:
                row[feature] = self._coerce_numeric(value)
            elif feature in self.date_columns:
                row[feature] = self._normalize_date(value)
            else:
                row[feature] = self._coerce_categorical(value)

        df = pd.DataFrame([row], columns=self.feature_list)
        logger.debug("Prepared single input with features: %s", list(df.columns))
        return df

    def predict(self, inputs: dict) -> dict[str, Any]:
        """Run prediction on a single input.

        Args:
            inputs: Dict of feature_name -> value.

        Returns:
            Dict with prediction, prediction_label (if classification),
            and confidence.
        """
        try:
            df = self.prepare_single_input(inputs)

            # Transform features
            if self.preprocessor is not None:
                X = self.preprocessor.transform(df)
            else:
                X = df.values

            # Predict
            raw_prediction = self.model.predict(X)[0]
            confidence: float | None = None

            # Handle classification specifics
            prediction_label: str | None = None
            if self.problem_type == "classification":
                if self.class_labels is not None and raw_prediction < len(self.class_labels):
                    prediction_label = str(self.class_labels[raw_prediction])
                else:
                    prediction_label = str(raw_prediction)

                # Try to get probability for confidence
                if hasattr(self.model, "predict_proba"):
                    try:
                        probas = self.model.predict_proba(X)[0]
                        confidence = float(np.max(probas))
                    except Exception:
                        pass
            else:
                prediction_label = None

            return {
                "prediction": float(raw_prediction) if isinstance(raw_prediction, (np.floating, float)) else raw_prediction,
                "prediction_label": prediction_label,
                "confidence": confidence,
                "success": True,
            }

        except Exception as e:
            logger.error("Prediction failed: %s", e, exc_info=True)
            return {
                "prediction": None,
                "prediction_label": None,
                "confidence": None,
                "success": False,
                "error": str(e),
            }

    def predict_batch(self, df: pd.DataFrame) -> pd.DataFrame:
        """Batch predictions on a DataFrame.

        Args:
            df: DataFrame containing feature columns.

        Returns:
            DataFrame with added 'prediction' column.
        """
        try:
            # Ensure all feature columns present
            missing_features = [f for f in self.feature_list if f not in df.columns]
            if missing_features:
                logger.warning("Missing features in batch input: %s", missing_features)
                for f in missing_features:
                    if f in self.numeric_features:
                        df[f] = 0.0
                    else:
                        df[f] = "missing"

            # Select and order features
            input_df = df[self.feature_list].copy()

            # Coerce types
            for col in self.numeric_features:
                if col in input_df.columns:
                    input_df[col] = pd.to_numeric(input_df[col], errors="coerce").fillna(0.0)

            for col in self.date_columns:
                if col in input_df.columns:
                    input_df[col] = input_df[col].apply(lambda x: self._normalize_date(x))

            for col in self.categorical_features:
                if col in input_df.columns:
                    input_df[col] = input_df[col].astype(str).fillna("missing")

            # Transform
            if self.preprocessor is not None:
                X = self.preprocessor.transform(input_df)
            else:
                X = input_df.values

            # Predict
            predictions = self.model.predict(X)
            result_df = df.copy()
            result_df["prediction"] = predictions

            if self.problem_type == "classification" and self.class_labels is not None:
                result_df["prediction_label"] = [
                    self.class_labels[int(p)] if int(p) < len(self.class_labels) else str(p)
                    for p in predictions
                ]

            logger.info("Batch prediction completed: %d rows", len(result_df))
            return result_df

        except Exception as e:
            logger.error("Batch prediction failed: %s", e, exc_info=True)
            raise

    def get_model_info(self) -> dict[str, Any]:
        """Return model package summary."""
        return {
            "target": self.target,
            "problem_type": self.problem_type,
            "metrics": self.metrics,
            "feature_count": len(self.feature_list),
            "numeric_features": len(self.numeric_features),
            "categorical_features": len(self.categorical_features),
            "date_features": len(self.date_columns),
            "feature_importance": self.feature_importance is not None,
        }

    def _coerce_numeric(self, value: Any) -> float:
        """Safely convert value to float. Return 0.0 on failure."""
        if value is None or value == "":
            return 0.0
        try:
            result = float(value)
            if np.isnan(result) or np.isinf(result):
                return 0.0
            return result
        except (ValueError, TypeError):
            return 0.0

    def _coerce_categorical(self, value: Any) -> str:
        """Safely convert value to string. Return 'missing' on empty."""
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return "missing"
        result = str(value).strip()
        return result if result else "missing"

    def _normalize_date(self, value: Any) -> float:
        """Convert date string/timestamp to numeric for model input."""
        if value is None or value == "":
            return 0.0
        try:
            if isinstance(value, (int, float)):
                return float(value)
            dt = pd.to_datetime(value, errors="coerce")
            if pd.notna(dt):
                return float(dt.timestamp())
        except Exception:
            pass
        return 0.0
