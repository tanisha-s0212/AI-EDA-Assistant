"""
Universal utility module for the AI-Assisted EDA & ML Platform.

This module provides dataset-agnostic helper functions for logging,
data cleaning, column detection, memory management, and file hashing.
No domain-specific or hardcoded business logic is included.
"""

import hashlib
import logging
import re
from datetime import datetime
from typing import Any

import pandas as pd

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MEMORY_THRESHOLD_MB: int = 200

# Date formats used by detect_date_columns when attempting to parse values.
_COMMON_DATE_FORMATS: list[str] = [
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%d-%m-%Y",
    "%d/%m/%Y",
    "%m-%d-%Y",
    "%m/%d/%Y",
    "%Y-%m-%d %H:%M:%S",
    "%Y/%m/%d %H:%M:%S",
    "%d-%m-%Y %H:%M:%S",
    "%d/%m/%Y %H:%M:%S",
    "%m-%d-%Y %H:%M:%S",
    "%m/%d/%Y %H:%M:%S",
    "%Y%m%d",
    "%d%b%Y",
    "%b %d, %Y",
    "%B %d, %Y",
    "%d %b %Y",
    "%d %B %Y",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M:%S.%f",
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%dT%H:%M:%S%z",
]

# Regex patterns that frequently appear in date-like strings.
_DATE_STRING_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}"),          # YYYY-MM-DD or YYYY/MM/DD
    re.compile(r"^\d{1,2}[-/]\d{1,2}[-/]\d{4}"),          # DD-MM-YYYY or MM-DD-YYYY
    re.compile(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}[ T]\d"),    # date + time
    re.compile(r"^\d{1,2}[-/]\d{1,2}[-/]\d{4}[ T]\d"),    # date + time (DMY/MDY)
    re.compile(r"^\d{8}$"),                                # YYYYMMDD compact
]

# Substrings commonly found in identifier column names (case-insensitive).
_ID_NAME_HINTS: list[str] = ["id", "code", "no", "num", "number", "key", "uuid", "identifier"]

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def setup_logging(level: int = logging.INFO) -> logging.Logger:
    """Configure and return a structured logger instance.

    Sets up a console handler with a standard format so that all modules
    in the application can produce consistent log output.

    Parameters
    ----------
    level : int, optional
        Logging level (default: ``logging.INFO``).

    Returns
    -------
    logging.Logger
        Configured logger named ``"eda_ml"``.
    """
    logger = logging.getLogger("eda_ml")

    # Avoid adding duplicate handlers when called multiple times.
    if not logger.handlers:
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    logger.setLevel(level)
    return logger


# Obtain a module-level logger immediately so other functions can use it.
_logger: logging.Logger = logging.getLogger("eda_ml")

# ---------------------------------------------------------------------------
# Column name helpers
# ---------------------------------------------------------------------------

def safe_standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Standardise column names for safe programmatic access.

    The transformation pipeline applied to each column name is:

    1. Convert to ``str`` (handles numeric column names gracefully).
    2. Strip leading/trailing whitespace.
    3. Replace internal whitespace with underscores.
    4. Lowercase the name.
    5. Remove every character that is *not* alphanumeric or an underscore.

    If duplicate names arise after standardisation they are suffixed with
    ``_dup_N`` where *N* starts at 1 and increments for each subsequent
    duplicate.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.

    Returns
    -------
    pd.DataFrame
        A **new** DataFrame (the original is copied) with cleaned columns.
    """
    df = df.copy()

    raw_names = [str(col) for col in df.columns]

    # Step 1-5: normalise each name.
    normalised: list[str] = []
    for name in raw_names:
        name = name.strip()                       # strip whitespace
        name = re.sub(r"\s+", "_", name)          # spaces -> underscores
        name = name.lower()
        name = re.sub(r"[^a-z0-9_]", "", name)   # remove special chars
        # Avoid leading/trailing underscores produced by edge cases.
        name = name.strip("_")
        # Collapse consecutive underscores.
        name = re.sub(r"_+", "_", name)
        normalised.append(name if name else "col")

    # Resolve duplicates.
    seen: dict[str, int] = {}
    final_names: list[str] = []
    for name in normalised:
        if name not in seen:
            seen[name] = 0
            final_names.append(name)
        else:
            seen[name] += 1
            unique_name = f"{name}_dup_{seen[name]}"
            # In the extremely unlikely event the suffixed name also exists,
            # keep incrementing until we find an unused name.
            while unique_name in seen:
                seen[name] += 1
                unique_name = f"{name}_dup_{seen[name]}"
            seen[unique_name] = 0
            final_names.append(unique_name)

    df.columns = final_names
    _logger.debug("Standardised %d column names.", len(df.columns))
    return df


def drop_empty_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Drop columns that are entirely ``NaN`` / ``None``.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.

    Returns
    -------
    pd.DataFrame
        DataFrame with fully-empty columns removed.
    """
    before = len(df.columns)
    df = df.dropna(axis=1, how="all")
    # Also drop columns where every value is pd.NA (nullable integer / string).
    all_na_mask = df.columns[df.isna().all()]
    if len(all_na_mask) > 0:
        df = df.drop(columns=all_na_mask)
    dropped = before - len(df.columns)
    if dropped > 0:
        _logger.info("Dropped %d entirely-empty column(s).", dropped)
    return df


# ---------------------------------------------------------------------------
# File hashing
# ---------------------------------------------------------------------------

def compute_file_hash(file_bytes: bytes, algorithm: str = "sha256") -> str:
    """Compute the cryptographic hash of raw file bytes.

    Parameters
    ----------
    file_bytes : bytes
        Raw content of the uploaded file.
    algorithm : str, optional
        Hashing algorithm supported by :mod:`hashlib` (default ``"sha256"``).

    Returns
    -------
    str
        Hexadecimal digest string.

    Raises
    ------
    ValueError
        If *algorithm* is not available in :mod:`hashlib`.
    """
    try:
        hasher = hashlib.new(algorithm)
    except ValueError as exc:
        raise ValueError(
            f"Unsupported hash algorithm '{algorithm}'. "
            f"Available: {', '.join(sorted(hashlib.algorithms_available))}"
        ) from exc

    hasher.update(file_bytes)
    digest = hasher.hexdigest()
    _logger.debug("Computed %s hash: %s …", algorithm, digest[:16])
    return digest


# ---------------------------------------------------------------------------
# Date detection
# ---------------------------------------------------------------------------

def detect_date_columns(df: pd.DataFrame, sample_size: int = 1000) -> list[str]:
    """Identify columns that likely represent dates or timestamps.

    Detection strategy (applied per column):

    * If the column dtype is already ``datetime64``, it is included.
    * For object/string columns, a sample of up to *sample_size* non-null
      values is tested against a library of common date formats and regex
      patterns.  If ≥ 80 % of sampled values parse successfully, the column
      is classified as a date column.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    sample_size : int, optional
        Maximum number of rows to sample per column (default ``1000``).

    Returns
    -------
    list[str]
        Names of columns detected as date-like.
    """
    date_cols: list[str] = []

    for col in df.columns:
        # Fast path: already datetime.
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            date_cols.append(col)
            continue

        # Only attempt parsing on object / string columns.
        if not pd.api.types.is_object_dtype(df[col]):
            continue

        series = df[col].dropna()
        if series.empty:
            continue

        # Work with a sample for performance.
        sample = series.head(sample_size)

        # Check regex patterns first (cheap).
        pattern_hits = 0
        for val in sample:
            val_str = str(val).strip()
            for pat in _DATE_STRING_PATTERNS:
                if pat.match(val_str):
                    pattern_hits += 1
                    break

        pattern_ratio = pattern_hits / len(sample)

        # If regex alone is very confident, accept.
        if pattern_ratio >= 0.95:
            date_cols.append(col)
            _logger.debug("Column '%s' detected as date (regex, %.0f%%).", col, pattern_ratio * 100)
            continue

        # Try actual datetime parsing.
        parse_hits = 0
        for val in sample:
            val_str = str(val).strip()
            parsed = False
            for fmt in _COMMON_DATE_FORMATS:
                try:
                    datetime.strptime(val_str, fmt)
                    parsed = True
                    break
                except (ValueError, TypeError):
                    continue
            if parsed:
                parse_hits += 1

        parse_ratio = parse_hits / len(sample)
        if parse_ratio >= 0.80:
            date_cols.append(col)
            _logger.debug(
                "Column '%s' detected as date (parse, %.0f%%).", col, parse_ratio * 100
            )

    if date_cols:
        _logger.info("Detected %d date column(s): %s", len(date_cols), date_cols)
    return date_cols


# ---------------------------------------------------------------------------
# Column role classification
# ---------------------------------------------------------------------------

def is_identifier_column(series: pd.Series) -> bool:
    """Determine whether a column is likely an identifier / key column.

    A column is classified as an identifier when **any** of the following
    hold:

    * The cardinality ratio (unique values / total non-null values) exceeds
      ``0.9`` **and** the column name contains common ID-related substrings.
    * The cardinality ratio exceeds ``0.95`` regardless of the column name
      (very high uniqueness is a strong signal).
    * The cardinality ratio exceeds ``0.9`` and the column is string-typed
      with high uniqueness.

    Parameters
    ----------
    series : pd.Series
        The column to evaluate.

    Returns
    -------
    bool
        ``True`` if the column looks like an identifier.
    """
    total = len(series.dropna())
    if total == 0:
        return False

    unique_count = series.nunique(dropna=True)
    cardinality_ratio = unique_count / total

    # Name-based hints.
    name_lower = str(series.name).lower()
    has_id_hint = any(hint in name_lower for hint in _ID_NAME_HINTS)

    # High uniqueness + name suggests ID.
    if cardinality_ratio > 0.9 and has_id_hint:
        return True

    # Very high uniqueness is strong regardless of name.
    if cardinality_ratio > 0.95:
        return True

    # String column with high uniqueness and moderate ID hint.
    is_string = pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)
    if cardinality_ratio > 0.9 and is_string and has_id_hint:
        return True

    return False


def detect_column_roles(df: pd.DataFrame) -> dict[str, str]:
    """Heuristically classify every column into a semantic *role*.

    Roles
    -----
    * ``"identifier"`` — high-cardinality key column.
    * ``"boolean"`` — ``bool`` dtype or binary (2 unique values).
    * ``"datetime"`` — ``datetime64`` dtype or date-like string column.
    * ``"numeric"`` — numeric dtype with reasonable cardinality.
    * ``"categorical"`` — object / string with moderate cardinality.

    The classification priority is:
    ``identifier > boolean > datetime > numeric > categorical``.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.

    Returns
    -------
    dict[str, str]
        Mapping of column name → role label.
    """
    roles: dict[str, str] = {}
    date_cols = set(detect_date_columns(df))

    for col in df.columns:
        series = df[col]

        # --- identifier (checked first) ---
        if is_identifier_column(series):
            roles[col] = "identifier"
            continue

        # --- boolean ---
        if pd.api.types.is_bool_dtype(series):
            roles[col] = "boolean"
            continue
        # Binary numeric or string (exactly 2 unique non-null values).
        non_null = series.dropna()
        if len(non_null) > 0 and non_null.nunique() == 2:
            unique_vals = set(non_null.unique())
            # Ensure they look boolean-ish (not just any two values).
            bool_like = unique_vals <= {0, 1, "0", "1", True, False, "true", "false",
                                         "yes", "no", "y", "n", "t", "f"}
            if bool_like or (pd.api.types.is_numeric_dtype(series) and non_null.nunique() == 2):
                roles[col] = "boolean"
                continue

        # --- datetime ---
        if pd.api.types.is_datetime64_any_dtype(series) or col in date_cols:
            roles[col] = "datetime"
            continue

        # --- numeric ---
        if pd.api.types.is_numeric_dtype(series):
            roles[col] = "numeric"
            continue

        # --- categorical (fallback for object / string) ---
        roles[col] = "categorical"

    _logger.info("Column roles: %s", roles)
    return roles


# ---------------------------------------------------------------------------
# Data leakage detection
# ---------------------------------------------------------------------------

def is_leakage_risk(column_name: str, target_name: str | None = None) -> bool:
    """Flag columns that may cause data leakage.

    A column is considered a leakage risk when:

    * *target_name* is provided **and** the column name contains the target
      name as a substring (e.g. target ``"survived"`` → column
      ``"survived_prob"``).
    * The column name suggests a derived / computed value that mirrors the
      target concept (suffixes like ``_calc``, ``_computed``, ``_pred``,
      ``_score``, ``_prob``, ``_estimated``).
    * The column name has the pattern ``total_X`` or ``X_total`` when the
      target name is ``X``.

    Parameters
    ----------
    column_name : str
        Name of the candidate predictor column.
    target_name : str | None, optional
        Name of the target / label column, if known.

    Returns
    -------
    bool
        ``True`` if leakage is suspected.
    """
    col_lower = column_name.lower().strip()

    # --- Target substring match ---
    if target_name is not None:
        target_lower = target_name.lower().strip()
        # Direct substring containment (but not the column itself).
        if target_lower and target_lower in col_lower and col_lower != target_lower:
            _logger.debug(
                "Leakage risk: column '%s' contains target '%s'.",
                column_name,
                target_name,
            )
            return True

    # --- Derived-value suffixes ---
    _leakage_suffixes = (
        "_calc",
        "_computed",
        "_pred",
        "_prediction",
        "_score",
        "_prob",
        "_probability",
        "_estimated",
        "_derived",
        "_proxy",
    )
    for suffix in _leakage_suffixes:
        if col_lower.endswith(suffix):
            # If the column name without the suffix matches the target, flag it.
            root = col_lower[: -len(suffix)].rstrip("_")
            if target_name is not None and root == target_name.lower().strip():
                _logger.debug(
                    "Leakage risk: column '%s' has leakage suffix '%s' with root matching target.",
                    column_name,
                    suffix,
                )
                return True

    # --- total_X / X_total pattern ---
    if target_name is not None:
        target_lower = target_name.lower().strip()
        if target_lower:
            patterns = [
                f"total_{target_lower}",
                f"{target_lower}_total",
                f"sum_{target_lower}",
                f"{target_lower}_sum",
            ]
            if col_lower in patterns:
                _logger.debug(
                    "Leakage risk: column '%s' matches aggregation pattern for target '%s'.",
                    column_name,
                    target_name,
                )
                return True

    return False


# ---------------------------------------------------------------------------
# Human-readable byte formatting
# ---------------------------------------------------------------------------

def format_bytes(size_bytes: int) -> str:
    """Convert a byte count into a compact human-readable string.

    Parameters
    ----------
    size_bytes : int
        Size in bytes.  Must be non-negative.

    Returns
    -------
    str
        Formatted string such as ``"1.23 MB"`` or ``"456 B"``.

    Raises
    ------
    ValueError
        If *size_bytes* is negative.
    """
    if size_bytes < 0:
        raise ValueError("size_bytes must be non-negative")

    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(size_bytes) < 1024.0 or unit == "TB":
            if unit == "B":
                return f"{int(size_bytes)} {unit}"
            return f"{size_bytes:,.2f} {unit}"
        size_bytes /= 1024.0

    # Fallback (should never be reached).
    return f"{size_bytes:,.2f} PB"
